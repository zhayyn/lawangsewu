<div class="w3-container-fluid">
	<div class="w3-row">
		<table class="w3-table-responsive">
			<tr><td>Nama Aplikasi:</td><td>Arita 2.0</td></tr>
			<tr><td>Pengembang:</td><td>Pengadilan Agama Semarang</td></tr>
		</table>
	</div>
</div>
		<!-- <div class="carousel"> -->
			<!-- <div class="item"> -->
				<div class="w3-container">
					<div class="carousel-caption">
						<h3><span><?php echo $app_name_singkat;?> adalah aplikasi <?php echo $app_name_full;?></span></h3>
						<div style="font-weight:bold;">
						<ul>
						<li>Setingan Blangko dan Variabel hanya dikelola oleh Admin Pengadilan Agama.</li>
						</ul>
						</div>
									
					</div>
											
				</div>
			<!-- </div> -->
		<!-- </div> -->