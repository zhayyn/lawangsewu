<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/cetak.css"/>
<h3 align="center">
    REKAPITULASI PENERIMANAN NEGARA BUKAN PAJAK
    <br>
    Tanggal <?php echo $tanggal;?>
    <br>
    Nomor <?php echo $nomorLaporan;?>
</h3>
<br> 
<div style="width:100%">
    <table class="bordered" style="width:100%;"> 
        <col  width="5%" />
        <col  width="20%" />
        <col  width="60%" />
        <col  width="15%" />
        <thead>
            <tr>
                <th>NO</th>
                <th>NOMOR PERKARA</th>
                <th>JENIS TRANSAKSI</th>
                <th>JUMLAH</th>                    
            </tr>   
            <tr>
                <?php for ($i=1; $i <5 ; $i++) { ?>
                    <td class="tengah"><?php echo $i;?></td>
                <?php }?>
            </tr>
        </thead>
        <?php
        $no=0;
        if(isset($get)){
            $total = 0;
            foreach ($get->result() as $row ) { ?>
                <tr>
                    <td class="tengah"><?php echo ++$no;?></td>
                    <td><?php echo $row->nomor_perkara;?></td>
                    <td><?php echo $row->jenis_transaksi;?></td>
                    <td class="rata_kanan"><?php echo set_rupiah($row->jumlah_transaksi);?></td>
                </tr>
                <?php
                $total += $row->jumlah_transaksi; 
            }?>
            <tr>
                <td colspan="3" class="tengah"><b>JUMLAH</b></td>
                <td class="rata_kanan"><?php echo set_rupiah($total);?></td>
            </tr>
        <?php } ?>
    </table>
    <br>
    <b>REKAPITULASI</b>
    <table class="bordered" style="width:100%;"> 
        <col  width="10%" />
        <col  width="40%" />
        <col  width="20%" />
        <col  width="10%" />
        <col  width="20%" />
        <thead>
            <tr>
                <td>Kode Transaksi</td>
                <td>Jenis Transaksi</td>
                <td>Tarif</td>
                <td>Volume</td>
                <td>Jumlah</td>
            </tr>
        </thead>
        <?php 
            foreach ($getRekapTanggal->result_array() as $row ) { 
                extract($row)
                ?>
                <tr>
                    <td><?php echo $kode_transaksi;?></td>
                    <td><?php echo $jenis_transaksi;?></td>
                    <td class="rata_kanan"><?php echo set_rupiah($tarif);?></td>
                    <td class="no"><?php echo $volume;?></td>
                    <td class="rata_kanan"><?php echo set_rupiah($jumlah_transaksi);?></td>
                </tr>
                <?php
                $total += $row->jumlah_transaksi; 
            }?>
        ?>
    </table>
    <br>
    <table style="width:100%;">
        <col  width="30%" />
        <col  width="40%" />
        <col  width="30%" />
        <tr>
            <td></td>
            <td></td>
            <td class="tengah"><?php echo $nama_kota.', '.convertKeTglIndo(date('Y-m-d'));?></td>
        </tr>
        <tr>
            <td class="tengah">Bendahara Penerimaan</td>
            <td></td>
            <td class="tengah">Kasir</td>
        </tr>
        <tr>
            <td colspan=3><br><br><br></td>
        </tr>
        <tr>
            <td class="tengah"><?php echo $bendahara_penerima;?></td>
            <td></td>
            <td class="tengah"><?php echo $kasir;?></td>
        </tr>
    </table>
</div>