<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pengaduan extends CI_Controller {

	function __construct() {
		parent::__construct();	
		$this->load->helper(array('form', 'url','captcha'));	

		define('URL_API_SESSION','http://192.168.88.9:8088/session');
		define('URL_API_KIRIM', 'http://192.168.88.9:8088/send-message');
		define('URL_API_KIRIM_MEDIA', 'http://192.168.88.9:8088/send-media');
		define('URL_TERIMA', 'http://192.168.88.10/wame/wame_c/masuk');		
		define('ACTIVE_TOKEN', 'e1191a9cf5e26c2f8e68d45ca66a4908');	

		if($this->session->userdata('user_id')==NULL OR $this->session->userdata('user_id')=="" OR 
			$this->session->userdata('jenis_user') == "3"
		){
			redirect('wame_c/main/login');
		}			
	}

	public function index() {
		$this->load->helper(array('url'));
		$data['judul'] = 'Pengaduan WA PA Semarang';
		$data['list_aduan'] = $this->wame_model->get_aduan();
		$data['list_aduan_selesai'] = $this->wame_model->get_aduan_done();
		$data['stat_pengaduan'] = $this->wame_model->get_stat_konsuladu();
		// $data['stat_pengaduan'] = $this->wame_model->get_stat(1);
		$data['lvluser'] = $this->session->userdata('jenis_user');
		$this->load->view("_menu", $data);		
		$this->load->view("adu", $data);
	}

	public function cek_adu()
	{
		$data = file_get_contents("php://input");
		$row = json_decode($data,true);

		$filter_dataadu = $row['filter'];
		$data['list_aduan'] = $this->wame_model->get_aduan($filter_dataadu);
		
		$this->load->view("adu", $data, TRUE);
		// $list_aduan = $p->row();
		// echo $list_aduan;
		// echo json_encode($list_aduan);
	}

	public function pindah_konsul(){
		$data = file_get_contents("php://input");
		$row = json_decode($data,true);
		$id_aduan = $row['id'];
		return $this->wame_model->move_to('aduan', 'konsultasi', $id_aduan);
	}

	public function pindah_umum(){
		$data = file_get_contents("php://input");
		$row = json_decode($data,true);
		$id_aduan = $row['id'];

		//KIRIM NOTIF KE KOOR UMUM
		$p = $this->wame_model->get_aduan_by_id($id_aduan);
		$dt = $p->row();
		$this->wame_model->notif_admin_informasi($dt->pengirim, $dt->pesan);

		return $this->wame_model->move_to('aduan', 'umum', $id_aduan);
	}	

	public function balas_adu(){
		// $data = file_get_contents("php://input");
		// $row = json_decode($data,true);

		// $id_aduan = $row['id'];
		// $pesan = $row['balasan'];
		// $dt['balasan'] = $pesan;
		// $dt['stat'] = 1;
		// $where = array('id' => $id_aduan);
		// $this->wame_model->update_data($where,'aduan',$dt);
		// echo $id_aduan.'='.$pesan;
		$tipe_pesan = 1;
		//PROSES UPLOAD FILE
		if(isset($_FILES['lampiran'])){
	        $tipe_pesan = 2;
	        $target_dir = $_SERVER['DOCUMENT_ROOT'].'/wame/lampiran/';
	        $namafile=$_FILES['lampiran']['name'];
	        $extension=pathinfo($namafile);
	        $extension=$extension['extension'];

	        $target_file = $target_dir . $_POST['id'].'_'.$namafile;
	        $fname = 'wame/lampiran/'. $_POST['id'].'_'.$namafile;
	        $filename =  $_POST['id'].'_'.$namafile;
			if (move_uploaded_file($_FILES["lampiran"]["tmp_name"], $target_file)) {
				$pesan = "The file ". htmlspecialchars( basename( $_FILES["lampiran"]["name"])). " has been uploaded.";
				$pesan = "Done, file wes keupload.";
			} else {
				$pesan = "Sorry, there was an error uploading your file.";
			}			
		}else{
			$tipe_pesan = 1;
			$filename = NULL;
		}

		$id_aduan = $_POST['id'];
		$pesan = $_POST['balasan'];
		$dt['balasan'] = $pesan;
		$dt['stat'] = 1;
		$dt['tipe_pesan'] = $tipe_pesan;
		$dt['fname'] = $filename;

		$where = array('id' => $id_aduan);
		$this->wame_model->update_data($where,'aduan',$dt);

		echo $id_aduan.'='.$pesan;	
	}

	public function set_selesai(){
		$data = file_get_contents("php://input");
		$row = json_decode($data,true);
		$id_aduan = $row['id'];

		$dt['stat'] = 2;
		$dt['dibalas'] = date("Y-m-d H:i:s");
		$where = array('id' => $id_aduan);
		$this->wame_model->update_data($where,'aduan',$dt);	
		echo 'Pengaduan selesai';		
	}

	public function get_adu_balas(){
		// $data = file_get_contents("php://input");
		// $row = json_decode($data,true);

		// $id_aduan = $row['id'];		
		// $data = $this->wame_model->get_aduan_balasan_by_id($id_aduan);
		// echo $data;
		$id_aduan = $this->input->post('id');
		$data = $this->wame_model->get_aduan_balasan_by_id($id_aduan);
		echo json_encode($data);
	}

	public function kirim_adu(){
		$data = file_get_contents("php://input");
		$row = json_decode($data,true);
		$id_aduan = $row['id'];

		$p = $this->wame_model->get_aduan_by_id($id_aduan);
		$data_umum = $p->row();

		if($data_umum->tipe_pesan == 2){
			//KIRIM PESAN MEDIA
			$hasil = $this->kirim_media($data_umum->pengirim, base_url().'lampiran/'.$data_umum->fname, $data_umum->prefiks.' '.$data_umum->balasan);
			echo 'ini pesan media';
		}else{
			$hasil = $this->kirim_pesan($data_umum->pengirim, $data_umum->prefiks.' '.$data_umum->balasan);
			echo 'ini pesan biasa';
		}
		$dt['stat'] = 2;
		$dt['dibalas'] = date("Y-m-d H:i:s");
		$where = array('id' => $id_aduan);
		$this->wame_model->update_data($where,'aduan',$dt);

		// $data = file_get_contents("php://input");
		// $row = json_decode($data,true);
		// $id_aduan = $row['id'];

		// $p = $this->wame_model->get_aduan_by_id($id_aduan);
		// $data_aduan = $p->row();

		// $hasil = $this->kirim_pesan($data_aduan->pengirim, $data_umum->prefiks.' '.$data_aduan->balasan);
		// // if($hasil == '1'){
		// 	$dt['stat'] = 2;
		// 	$where = array('id' => $id_aduan);
		// 	$this->wame_model->update_data($where,'aduan',$dt);
		// // }else{
		// // 	$dt['stat'] = 3;
		// // 	$where = array('id' => $id_aduan);
		// // 	$this->wame_model->update_data($where,'aduan',$dt);
		// // }
		echo $hasil;
	}

	public function kirim_pesan($tujuan, $pesan){

		$data = file_get_contents("php://input");
		$row = json_decode($data,true);

		$url2 = URL_API_KIRIM;
		$id = $this->wame_model->get_last_id_wapi();		

		$kirim2 = array(
			'token' => ACTIVE_TOKEN,
			'id'     => $id,
		   	'number'	=> $tujuan,
		   	'message'=> $pesan
		);

		$options2 = array(
		  'http' => array(
		    'method'  => 'POST',
		    'content' => json_encode( $kirim2 ),
		    'header'=>  "Content-Type: application/json\r\n" .
		                "Accept: application/json\r\n"
		    )
		);
		$context2  = stream_context_create( $options2 );
		$result2 = file_get_contents( $url2, false, $context2 );
		$response = json_decode( $result2 );	

		if($response->success == TRUE){
			$data_resp = array(
				"hasil_kode" => $response->success,
				"hasil_pesan" => $response->message
			);	
			echo '1';
		} else {
			$data_resp = array(
				"hasil_kode" => '0',
				"hasil_pesan" => 'GAGAL KIRIM'
			);
			echo '0';
		}
		// return $response->success;
	}	

	public function kirim_media($tujuan, $filename, $caption){
		$penerima = $tujuan;
		$pesan = $caption;
		$fname = $filename;

		$url2 = URL_API_KIRIM_MEDIA;
		$id = $this->wame_model->get_last_id_wapi();		

		$kirim2 = array(
			'token' => ACTIVE_TOKEN,
			'id'     => $id,
		   	'number'	=> $penerima,
		   	'caption'=> $pesan,
		   	'file'=> $fname
		);
		$options2 = array(
		  'http' => array(
		    'method'  => 'POST',
		    'content' => json_encode( $kirim2 ),
		    'header'=>  "Content-Type: application/json\r\n" .
		                "Accept: application/json\r\n"
		    )
		);
		$context2  = stream_context_create( $options2 );
		$result2 = file_get_contents( $url2, false, $context2 );
		$response = json_decode( $result2 );
		// return $response->success;
		if($response->success == TRUE){
			$data_resp = array(
				"hasil_kode" => $response->success,
				"hasil_pesan" => $response->message
			);	
			echo '1';
		} else {
			$data_resp = array(
				"hasil_kode" => '0',
				"hasil_pesan" => 'GAGAL KIRIM'
			);
			echo '0';
		}		
	}


}