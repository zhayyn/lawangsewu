  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<style>
	#rcorners1 {
		border-radius: 0px 50px 50px 0px;
		background: #73AD21;
		padding: 4px;
		width: 128px;
		height: 39px;
	}
	.rcorners2 {
		border-radius: 50px 50px 50px 50px;
		background: white;
		padding: 4px;
		width: 128px;
		height: 39px;
	}	
</style>

<?php 
	$bagian = 0;
	if($lvluser){
?>
    <div class="w3-top">
        <!-- Menu Utama layar normal (PC/desktop) -->
        <div class="w3-bar w3-white w3-left-align w3-card">
			<!-- <a class="dropbtn w3-bar-item w3-button w3-left w3-hide-small dropdown-toggle" onclick="myFunction()" href='' data-bs-toggle="dropdown"><i class="fa fa-sign-out"></i> Test</a> -->

			<a id="rcorners1" class="w3-bar-item w3-button w3-left w3-blue" href="<?php echo base_url('wame_c/main/home');?>"><i class="fa fa-home" aria-hidden="true"></i> Beranda</a>
			<a class="w3-bar-item w3-button w3-right w3-hide-small" href='<?php echo base_url().'wame_c/logout';?>'><i class="fa fa-sign-out"></i> Logout</a>
			<?php if($lvluser == 1){?>
			<div class="w3-dropdown-hover">
				<button class="w3-button rcorners2"><i class="fa fa-cogs" aria-hidden="true"></i> System</button>
				<div class="w3-dropdown-content w3-bar-block w3-card-4">
					<a class="w3-bar-item w3-button w3-hide-small rcorners2" href="<?php echo base_url('wame_c/main/sesi');?>"><i class="fa fa-cogs" aria-hidden="true"></i> WA API Sessions</a>
					<a class="w3-bar-item w3-button w3-left rcorners2" href="<?php echo base_url('ambil_c/index');?>" target="_blank"><i class="fa fa-cogs" aria-hidden="true"></i> Service Ambil Data</a>				
					<a class="w3-bar-item w3-button w3-left rcorners2" href="<?php echo base_url('kirim_c/index');?>" target="_blank"><i class="fa fa-cogs" aria-hidden="true"></i> Service Kirim Pesan</a>
					<a class="w3-bar-item w3-button w3-left rcorners2" href="http://192.168.88.10/antrianpasmg/prioritas" target="_blank"><i class="fa fa-cogs" aria-hidden="true"></i> Antrian Sidang Prioritas</a>
					<a class="w3-bar-item w3-button w3-left rcorners2" href="<?php echo base_url('blasting');?>" target="_blank"><i class="fa fa-cogs" aria-hidden="true"></i> Blasting Pagi Pegawai</a>
					<a class="w3-bar-item w3-button w3-left rcorners2" href="<?php echo base_url('pegawai');?>"><i class="fa fa-user" aria-hidden="true"></i> Pegawai</a>
					<a class="w3-bar-item w3-button w3-left rcorners2" href="http://192.168.88.10/monitoring_upaya_hukum/monitoring.php" target="_blank"><i class="fa fa-cogs" aria-hidden="true"></i> Monitoring Upaya Hukum</a>
				</div>
			</div>
			<?php } ?>			
			<?php if($lvluser == 2 || $lvluser == 1){?>
				<a class="w3-bar-item w3-button w3-left rcorners2" href="<?php echo base_url('pengaduan');?>"><i class="fa fa-commenting" aria-hidden="true"></i> Pengaduan</a>
			<?php } ?>
			<?php if($lvluser == 3 || $lvluser == 1){?>
				<a class="w3-bar-item w3-button w3-left rcorners2" href="<?php echo base_url('konsultasi');?>"><i class="fa fa-commenting" aria-hidden="true"></i> Konsultasi</a>
				<!-- <a class="btn btn-sm w3-red" href="<?php echo base_url('konsultasi_l');?>"><i class="fa fa-commenting-o" aria-hidden="true"></i> Konsultasi Langsung</a>	 -->
			<?php } ?>
			<?php if($lvluser == 4 || $lvluser == 1){
					if($bagian == 1){
			?>
				<a class="w3-bar-item w3-button w3-left rcorners2" href="<?php echo base_url('umum');?>"><i class="fa fa-commenting-o" aria-hidden="true"></i> Umum Sekretariat</a>
			<?php } ?>
				<a class="w3-bar-item w3-button w3-left rcorners2" href="<?php echo base_url('atk/admin');?>"><i class="fa fa-cubes" aria-hidden="true"></i> ATK Request</a>
				<a class="w3-bar-item w3-button w3-left rcorners2" href="<?php echo base_url('umum');?>"><i class="fa fa-commenting-o" aria-hidden="true"></i> Umum Sekretariat</a>	
			<?php } ?>			
			<a class="w3-bar-item w3-button w3-left rcorners2" href="<?php echo base_url('wame_c/main/gagal');?>" target="_self"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Notif Gagal</a>	

    	</div>
    </div>


    <div id="myTop" class="w3-container" style="padding-top: 8px;"> </div>
<?php
	} else{
		echo '';
	}
?>