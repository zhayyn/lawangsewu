<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Atk extends CI_Controller {

	function __construct() {
		parent::__construct();	
		$this->load->helper(array('form', 'url','captcha'));	
		$this->load->library('email');
		$this->load->library("cart");

		define('URL_API_SESSION','http://192.168.88.9:8088/session');
		define('URL_API_KIRIM', 'http://192.168.88.9:8088/send-message');
		define('URL_TERIMA', 'http://192.168.88.10/wame/wame_c/masuk');		
		define('ACTIVE_TOKEN', 'e1191a9cf5e26c2f8e68d45ca66a4908');


		if($this->session->userdata('user_id')==NULL OR $this->session->userdata('user_id')==""){
			// $this->login();
			// $this->main('login');
		}		
	}

	public function atk_req($ipeg, $itgl){
		$nama_pegawai = $this->wame_model->get_pegawai_by_id($ipeg);

		$data['id_pegawai_login'] = $ipeg;
		$data['judul'] = $nama_pegawai.' '.$itgl;
		$data['data_pegawai'] = $this->wame_model->get_pegawai_list();
		$data['atk_list_item'] = $this->wame_model->get_item_list();

		$this->load->library("cart");
		$this->load->view('atk_request', $data);		

	}

	public function permohonan(){

		if(isset($_GET['a'])){
			$kode = $this->input->get('a');
			$wer = json_decode(base64_decode($kode));
			$id_pegawai = $wer->idpeg;
			$itgl = $wer->tgl;

			if(date('Y-m-d') == $itgl){
				if($id_pegawai){
					$nama_pegawai = $this->wame_model->get_pegawai_by_id($id_pegawai);
					if(strlen($nama_pegawai) > 1){
						//pegawai ada
						$data['id_pegawai_login'] = $id_pegawai;
						$data['judul'] = $nama_pegawai.' '.$itgl;
						$data['data_pegawai'] = $this->wame_model->get_pegawai_list();
						$data['atk_list_item'] = $this->wame_model->get_item_list();

						$this->load->library("cart");
						$this->load->view('atk_request', $data);
						// $this->atk_req($id_pegawai, $itgl);
					}else{
						//pegawai tidak ditemukan/tidak aktif
						$data['judul'] = 'Permohonan ATK Pegawai';
						$data['err_code'] = 2;
						$this->load->view('atk_fail', $data);			
					}			
				}else{
					//pegawai tidak ditemukan/tidak aktif
					$data['judul'] = 'Permohonan ATK Pegawai';
					$data['err_code'] = 1;
					$this->load->view('atk_fail', $data);			
				}
			}else{
					$data['judul'] = 'Permohonan ATK Pegawai';
					$data['err_code'] = 3;
					$this->load->view('atk_fail', $data);				
			}
		}else{
				//pegawai tidak ditemukan/tidak aktif
				$data['judul'] = 'Permohonan ATK Pegawai';
				$data['err_code'] = 0;
				$this->load->view('atk_fail', $data);			
		}

		
	}

	public function index() {
				$data['judul'] = 'Permohonan ATK Pegawai';
				$data['err_code'] = 0;
				$this->load->view('atk_fail', $data);	
	}

	public function admin(){
		$data['judul'] = 'Admin Permintaan ATK';
		$data['data_atk_req'] = $this->wame_model->get_atk_req(0);
		$data['lvluser'] = $this->session->userdata('jenis_user');
		$data['bagian'] = $this->session->userdata('bagian');
		$this->load->view("_menu", $data);			
		$this->load->view('atk_admin', $data);		
	}

	function bersihkan(){
		$this->load->library("cart");
		$this->cart->destroy();	
		echo json_encode('Item berhasil dikosongkan!'); 				
	}

	function refresh_item(){
		$nc = array();
		foreach($this->cart->contents() as $items){
			if($items['qty'] != 0){
			   $nc[] = array('id' => $items['rowid'],
			                   'qty' => $items['qty'],
			                   'price' => $items['price'],
			                   'name' => $items['name']);
			}
		}
		echo json_encode($nc);
	}

	function req_sukses(){
		$this->load->view('atk_ok');
	}

	function req_fail(){
		$this->load->view('atk_fail');
	}
	
	function hapus(){
		$this->load->library("cart");
		
		$row_id = $this->input->post("pid");
		$itim = array(
			'rowid'  => $row_id,
			'qty'  => 0,
			'price' => 0
		);
		$this->cart->update($itim);
		echo json_encode('Item berhasil dihapus!');	
	}

	function add(){
		$this->load->library("cart");
		$data = array(   
			"id"  => rand(1,100),
			"name"  => $this->input->post("item"),
			"qty"  => $this->input->post("jml"),
			"price"  => $this->input->post("jml")
		);
		$this->cart->insert($data); //return rowid 
		echo json_encode('Item berhasil ditambahkan!');
	}

	public function filter_data(){
		$f = $this->input->post('filter');
		// $data['judul'] = 'Admin Permintaan ATK';
		$data = $this->wame_model->get_atk_req($f);
		// $data['lvluser'] = $this->session->userdata('jenis_user');
		// $this->load->view("_menu", $data);			
		// $this->load->view('atk_admin', $data);		
		echo json_encode($data);
	}

	public function simpan_status(){
		$tgl_pemenuhan = null;

		$id = $this->input->post('req_id');
		$stat = $this->input->post('stat');
		if($stat == 1){
			$tgl_pemenuhan = date('Y-m-d');
		}else{
			$tgl_pemenuhan = null;
		}

		$where = array(
				'id' => $id
			);
		$data = array(
				'stat' => $stat,
				'tgl_pemenuhan' => $tgl_pemenuhan
			);
		$hasil = $this->wame_model->update_data($where, 'atk_req', $data);
		echo json_encode($hasil);
	}

	public function simpan(){
		$this->load->library("cart");
		
		$id_peg = $this->input->post('id_peg');
		$peg = $this->input->post('nm_peg');
		$guna = $this->input->post('guna');
		

		$h = 0;
		$nid = $this->wame_model->simpan_atk_request($id_peg, $peg, $guna);
		$h = $nid['new_id'];
		if($h !== 0){
			//KIRIM NOTIF ADMIN ATK
			$hasilnya = 0;
			try {
			  $hasilnya = $this->wame_model->kirim_notif_admin_atk($nid['new_id']);
			} catch(Exception $e) {
			  $hasilnya = 0;
			}	
		}

		$this->cart->destroy();
		// $nid= 1;
		// var_dump($nid);
		echo json_encode($nid);
		// $this->bersihkan();
		// echo json_encode($nid);
	}

	public function show_detail_request(){
		$det_req = $this->wame_model->get_items_request_by_id($this->input->post('req_id'));
		echo json_encode($det_req);
	}

	public function cetak(){
		$pid = $this->input->post('req_id');
		$data['judul'] = 'Dokumen Pernyataan ATK';
		$data['data_atk_req'] = $this->wame_model->get_atk_req($pid);
		$data['det_items_req'] = $this->wame_model->get_items_request_by_id($pid);
		$this->load->view('cetak_atk', $data);
	}
}