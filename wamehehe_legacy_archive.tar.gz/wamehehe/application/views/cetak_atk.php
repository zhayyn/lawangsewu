<!DOCTYPE html>
<html>
  <style type="text/css">
    .tg  {border-collapse:collapse;border-spacing:0;}
    .tg td{
      border-bottom-width:1px;border-color:black;border-style:solid;border-top-width:1px;border-width:0px;
      font-family:Arial, sans-serif;font-size:11px;
      overflow:hidden;
      padding:4px 5px;word-break:normal;
    }
    .tg th{
      border-bottom-width:1px;border-color:black;border-style:solid;border-top-width:1px;border-width:0px;
      font-family:Arial, sans-serif;font-size:11px;
      font-weight:normal;overflow:hidden;
      padding:2px 5px;word-break:normal;
    }
    .tg .tg-z1fk{border-color:inherit;font-weight:bold;text-align:left;vertical-align:top}
    .tg .tg-8bgf{border-color:inherit;font-style:italic;text-align:center;vertical-align:top}
    .tg .tg-p1nr{border-color:inherit;font-size:11px;text-align:left;vertical-align:top}
    .tg .tg-8ot9{border-color:inherit;font-size:15px;text-align:center;vertical-align:top}
    .tg .tg-8kr0{border-color:inherit;font-style:italic;text-align:center;vertical-align:top}
    .tg .tg-c3ow{border-color:inherit;text-align:center;vertical-align:top}
    .tg .tg-0pky{border-color:inherit;text-align:left;vertical-align:top}
    .tg .tg-7btt{border-width:1px; border-color:black;font-weight:bold;text-align:center;vertical-align:top}
    .tg .tg-fymr{border-color:inherit;font-weight:bold;text-align:center;vertical-align:top}
    .tg .tg-j2vi{border-color:inherit;font-weight:bold;text-align:center;vertical-align:top}
    .tg .tg-pcvp{border-color:inherit;text-align:left;vertical-align:top}
    .tg .tg-ihkz{border-color:inherit;text-align:center;vertical-align:top}
    .tg .tg-ll{border-left:1px solid; border-color:black;}
    .tg .tg-lr{border-right:1px solid; border-color:black;}
    .tg .tg-lt{border-top:1px solid; border-color:black;}
    .tg .tg-lbx{border-bottom:4px solid; border-style: double; border-color:black;}
    .tg .tg-ltx{border-top:4px solid; border-color:black;}
    .tg .tg-lb{border-bottom:1px solid; border-color:black;}
    .logo{
      width: 72px;
      height: 72px;
    }
  </style>
<body>
  <?php
    
  error_reporting(E_ALL);
  // include "_sys_admin_session.php";
  $nama_halaman="Laporan";
  // include('_sys_config.php');
  // include('_fungsi.php');

    // $id=base64_decode($_GET["id"]); 
    // echo $id."<br>"; 
    // $sql="CALL v_permohonan('".$id."');";
    // $db = new Tampil(); 
    // $arrayData = $db->tampil_data($sql);     
    // if (count($arrayData)){ 
    //   foreach ($arrayData as $data) { 
    //     foreach($data as $key=>$value) {$$key=$value;}
    //   }
    // } else{
    //   echo "data kosong";
    // }
  ?>


  <table class="tg">
  <thead>
    <tr>
      <td class="tg-0pky tg-lbx" valign="right"><img class="logo" src="dp3a2.png" alt="Image" width="55" height="17"></th>
      <td class="tg-8ot9 tg-lbx" colspan="6"><span style="font-weight:bold">PEMERINTAH KOTA SEMARANG</span><br><span style="font-weight:bold">DINAS PEMBERDAYAAN PEREMPUAN</span><br><span style="font-weight:bold">DAN PERLINDUNGAN ANAK</span><br>Jl. Prof. Soedarto, SH No.116 Telp./Fax. 024-76402252 Semarang 50269</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td class="tg-0pky tg-ltx" colspan="7"></td>
    </tr>

    <tr>
      <td class="tg-8ot9" colspan="6"><b><strong>LAPORAN HASIL KONSELING<br>(Untuk Kepentingan Permohonan Dispensasi Kawin)</strong></b></td>
      <td class="tg-7btt">RAHASIA<br>Hanya untuk kepentingan <br>internal DP3A dan Pengadilan</td>
    </tr>
    <tr><td colspan="7"></td></tr> 

    <tr>
      <td class="tg-fymr">I.</td>
      <td class="tg-z1fk" colspan="6">Dasar Pelaksanaan Konseling</td>
    </tr>
    <tr>
      <td class="tg-fymr">II.</td>
      <td class="tg-z1fk" colspan="6">Tujuan Pelaksanaan Konseling</td>
    </tr>
    <tr>
      <td class="tg-fymr">III.</td>
      <td class="tg-z1fk" colspan="6">Identitas</td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-z1fk" colspan="6">a)&nbsp;&nbsp;Identitas Klien dan Calon Pasangan Klien</td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-7btt" colspan="3">Klien</td>
      <td class="tg-7btt" colspan="3">Calon Pasangan Klien</td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ll">Nama Lengkap</td>
      <td class="tg-0pky">:</td>
      <td class="tg-pcvp"><?php echo $P_nama;?></td>
      <td class="tg-ll">Nama Lengkap</td>
      <td class="tg-pcvp">:</td>
      <td class="tg-lr"><?php echo $T_nama;?></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ll">NIK</td>
      <td class="tg-0pky">:</td>
      <td class="tg-pcvp"><?php echo $P_nik;?></td>
      <td class="tg-ll">NIK</td>
      <td class="tg-pcvp">:</td>
      <td class="tg-lr"><?php echo $T_nik;?></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ll">Tempat/Tgl.Lahir</td>
      <td class="tg-0pky">:</td>
      <td class="tg-pcvp"><?php echo $P_bpd;?></td>
      <td class="tg-ll">Tempat/Tgl.Lahir</td>
      <td class="tg-pcvp">:</td>
      <td class="tg-lr"><?php echo $T_bpd;?></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ll">Usia</td>
      <td class="tg-0pky">:</td>
      <td class="tg-pcvp"><?php echo $P_umur;?></td>
      <td class="tg-ll">Usia</td>
      <td class="tg-pcvp">:</td>
      <td class="tg-lr"><?php echo $T_umur;?></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ll">Jenis Kelamin</td>
      <td class="tg-0pky">:</td>
      <td class="tg-pcvp"><?php echo $P_jk;?></td>
      <td class="tg-ll">Jenis Kelamin</td>
      <td class="tg-pcvp">:</td>
      <td class="tg-lr"><?php echo $T_jk;?></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ll">Agama</td>
      <td class="tg-0pky">:</td>
      <td class="tg-pcvp"><?php echo $P_agama;?></td>
      <td class="tg-ll">Agama</td>
      <td class="tg-pcvp">:</td>
      <td class="tg-lr"><?php echo $T_agama;?></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ll">Pendidikan</td>
      <td class="tg-0pky">:</td>
      <td class="tg-pcvp"><?php echo $P_pend;?></td>
      <td class="tg-ll">Pendidikan</td>
      <td class="tg-pcvp">:</td>
      <td class="tg-lr"><?php echo $T_pend;?></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ll" rowspan="2">Alamat Lengkap</td>
      <td class="tg-0pky" rowspan="2">:</td>
      <td class="tg-pcvp" rowspan="2"><?php echo $P_alamat;?></td>
      <td class="tg-ll" rowspan="2">Alamat Lengkap</td>
      <td class="tg-pcvp" rowspan="2">:</td>
      <td class="tg-lr" rowspan="2"><?php echo $T_alamat;?></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ll">No.Tlp</td>
      <td class="tg-0pky">:</td>
      <td class="tg-pcvp"><?php echo $P_nohp;?></td>
      <td class="tg-ll">No.Tlp</td>
      <td class="tg-pcvp">:</td>
      <td class="tg-lr"><?php echo $T_nohp;?></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ll">Tgl.Konseling</td>
      <td class="tg-p1nr">:</td>
      <td class="tg-pcvp"><?php echo $tgl_validasi_kons;?></td>
      <td class="tg-ll">Tgl.Konseling</td>
      <td class="tg-pcvp">:</td>
      <td class="tg-lr"><?php echo $tgl_validasi_kons;?></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-lt" colspan="6"><b>a)  Identitas Orangtua</b> </td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-7btt" colspan="3">Orangtua Klien</td>
      <td class="tg-7btt" colspan="3">Orangtua Calon<br>Pasangan Klien</td>
    </tr>  
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ll">Nama Lengkap</td>
      <td class="tg-0pky">:</td>
      <td class="tg-pcvp"><?php echo $OP_nama;?></td>
      <td class="tg-ll">Nama Lengkap</td>
      <td class="tg-pcvp">:</td>
      <td class="tg-lr"><?php echo $OT_nama;?></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ll">NIK</td>
      <td class="tg-0pky">:</td>
      <td class="tg-pcvp"><?php echo $OP_nik;?></td>
      <td class="tg-ll">NIK</td>
      <td class="tg-pcvp">:</td>
      <td class="tg-lr"><?php echo $OT_nik;?></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ll">Tempat/Tgl.Lahir</td>
      <td class="tg-0pky">:</td>
      <td class="tg-pcvp"><?php echo $OP_bpd;?></td>
      <td class="tg-ll">Tempat/Tgl.Lahir</td>
      <td class="tg-pcvp">:</td>
      <td class="tg-lr"><?php echo $OT_bpd;?></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ll">Usia</td>
      <td class="tg-0pky">:</td>
      <td class="tg-pcvp"><?php echo $OP_umur;?></td>
      <td class="tg-ll">Usia</td>
      <td class="tg-pcvp">:</td>
      <td class="tg-lr"><?php echo $OT_umur;?></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ll">Jenis Kelamin</td>
      <td class="tg-0pky">:</td>
      <td class="tg-pcvp"><?php echo $OP_jk;?></td>
      <td class="tg-ll">Jenis Kelamin</td>
      <td class="tg-pcvp">:</td>
      <td class="tg-lr"><?php echo $OT_jk;?></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ll">Agama</td>
      <td class="tg-0pky">:</td>
      <td class="tg-pcvp"><?php echo $OP_agama;?></td>
      <td class="tg-ll">Agama</td>
      <td class="tg-pcvp">:</td>
      <td class="tg-lr"><?php echo $OT_agama;?></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ll">Pendidikan</td>
      <td class="tg-0pky">:</td>
      <td class="tg-pcvp"><?php echo $OP_pend;?></td>
      <td class="tg-ll">Pendidikan</td>
      <td class="tg-pcvp">:</td>
      <td class="tg-lr"><?php echo $OT_pend;?></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ll">Pekerjaan</td>
      <td class="tg-0pky">:</td>
      <td class="tg-pcvp"><?php echo $OP_pekerjaan;?></td>
      <td class="tg-ll">Pekerjaan</td>
      <td class="tg-pcvp">:</td>
      <td class="tg-lr"><?php echo $OT_pekerjaan;?></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ll" rowspan="2">Alamat Lengkap</td>
      <td class="tg-0pky" rowspan="2">:</td>
      <td class="tg-pcvp" rowspan="2"><?php echo $OP_alamat;?></td>
      <td class="tg-ll" rowspan="2">Alamat Lengkap</td>
      <td class="tg-pcvp" rowspan="2">:</td>
      <td class="tg-lr" rowspan="2"><?php echo $OT_alamat;?></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ll tg-lb">No.Tlp</td>
      <td class="tg-0pky tg-lb">:</td>
      <td class="tg-pcvp tg-lb"><?php echo $OP_nohp;?></td>
      <td class="tg-ll tg-lb">No.Tlp</td>
      <td class="tg-pcvp tg-lb">:</td>
      <td class="tg-lr tg-lb"><?php echo $OT_nohp;?></td>
    </tr>
    <tr>
      <td class="tg-fymr">IV.</td>
      <td class="tg-z1fk">Permasalahan Klien</td>
      <td class="tg-0pky">:</td>
      <td class="tg-pcvp" colspan="4"></td>
    </tr>
    <tr>
      <td class="tg-fymr">V.</td>
      <td class="tg-z1fk">Potensi Klien</td>
      <td class="tg-0pky">:</td>
      <td class="tg-pcvp" colspan="4"></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-7btt" colspan="3">Kelebihan (Positif)</td>
      <td class="tg-7btt" colspan="3">Kekurangan (Negatif)</td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-7btt" colspan="3"><?php echo $potensi_pos_klien;?></td>
      <td class="tg-7btt" colspan="3"><?php echo $potensi_neg_klien;?></td>
    </tr>
    <tr>
      <td class="tg-fymr">VI.</td>
      <td class="tg-z1fk">Kesimpulan</td>
      <td class="tg-0pky">:</td>
      <td class="tg-pcvp" colspan="4"><?php echo $kesimpulan;?></td>
    </tr>
    <tr>
      <td class="tg-fymr">VII.</td>
      <td class="tg-z1fk">Rekomendasi</td>
      <td class="tg-0pky">:</td>
      <td class="tg-pcvp" colspan="4"><?php echo $rekomendasi;?></td>
    </tr>
    <tr>
      <td class="tg-0pky" colspan="7"></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-pcvp"></td>
      <td class="tg-0pky"></td>
      <td class="tg-pcvp" style="text-align: center">Barcode</td>
      <td class="tg-0pky"></td>
      <td class="tg-pcvp"></td>
      <td class="tg-0pky">Semarang, <?php echo date("d-M-Y", strtotime($tgl_dok));?></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-8kr0">Mengetahui<br>Plt. Kepala Dinas DP3A<br>Semarang</td>
      <td class="tg-c3ow" colspan="4" rowspan="4">
      <!-- Barcode&nbsp;&nbsp; -->
<?php
  //qr code
  $PNG_TEMP_DIR = dirname(__FILE__).DIRECTORY_SEPARATOR.'temp'.DIRECTORY_SEPARATOR;  
  $PNG_WEB_DIR = 'temp/'; 
  include "assets/plugin/phpqrcode/qrlib.php";  
  if (!file_exists($PNG_TEMP_DIR))
    mkdir($PNG_TEMP_DIR);
  $filename = $PNG_TEMP_DIR.$id.'.png';
  $errorCorrectionLevel = 'L';
  if (isset($_REQUEST['level']) && in_array($_REQUEST['level'], array('L','M','Q','H')))
    $errorCorrectionLevel = $_REQUEST['level'];    

  $matrixPointSize = 6;
  if (isset($_REQUEST['size']))
    $matrixPointSize = min(max((int)$_REQUEST['size'], 1), 10);
  if (isset($id)) { 
    if (trim($id) == '')
      die('data cannot be empty! <a href="?">back</a>');
    $filename = $PNG_TEMP_DIR.'kartu '.md5($id.'|'.$errorCorrectionLevel.'|'.$matrixPointSize).'.png';
    QRcode::png($id, $filename, $errorCorrectionLevel, $matrixPointSize, 2);    

  } else {
    QRcode::png('PHP QR Code :)', $filename, $errorCorrectionLevel, $matrixPointSize, 2);    
  }   
  $qr2 =$PNG_WEB_DIR.basename($filename); 
  $qr="{{\pict\pngblip ".bin2hex(file_get_contents($PNG_WEB_DIR.basename($filename)))."}}";

  echo '<img style="width:80px; height=80px;" src="'.$qr2.'" />';
?> 
    </td>
      <td class="tg-8bgf">Konselor</td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-pcvp"></td>
      <td class="tg-0pky" colspan="4" rowspan="1">
 

      </td>
      <td class="tg-0pky"></td>
    </tr>
    <tr>
      <td class="tg-0pky"><br></td>
    </tr>
    <tr>
      <td class="tg-0pky"></td>
      <td class="tg-ihkz"><b><u><?php echo $kadin;?></u></b></td>
      <td class="tg-c3ow"><b><u><?php echo $nama_konselor;?></u></b></td>
    </tr>

  </tbody>
  </table>


</body>
<script type="text/javascript"> 
  window.print();       
  setTimeout(function () { 
      document.location.href = "#";  
    }, 100);  
    
</script>
</html>