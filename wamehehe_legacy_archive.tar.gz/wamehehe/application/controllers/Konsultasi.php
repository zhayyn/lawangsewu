<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Konsultasi extends CI_Controller {

	function __construct() {
		parent::__construct();	
		$this->load->helper(array('form', 'url','captcha'));	

		define('URL_API_SESSION','http://192.168.88.9:8088/session');
		define('URL_API_KIRIM', 'http://192.168.88.9:8088/send-message');
		define('URL_API_KIRIM_MEDIA', 'http://192.168.88.9:8088/send-media');
		define('URL_TERIMA', 'http://192.168.88.10/wame/wame_c/masuk');		
		define('ACTIVE_TOKEN', 'e1191a9cf5e26c2f8e68d45ca66a4908');	

		if($this->session->userdata('user_id')==NULL OR $this->session->userdata('user_id')=="" OR
			$this->session->userdata('jenis_user') == "2"
			){
			redirect('wame_c/main/login');
		}			
	}

	public function index() {
		$this->load->helper(array('url'));
		$data['judul'] = 'Konsultasi WA PA Semarang';
		$data['list_konsul'] = $this->wame_model->get_konsul();
		$data['list_konsul_selesai'] = $this->wame_model->get_konsul_done();
		
		$data['list_live_konsul'] = $this->wame_model->get_live_konsul();
		$data['list_live_konsulfin'] = $this->wame_model->get_live_konsulfin();

		$data['stat_konsultasi'] = $this->wame_model->get_stat_konsuladu();
		$data['lvluser'] = $this->session->userdata('jenis_user');
		$this->load->view("_menu", $data);
		$this->load->view("konsul", $data);
	}	

	public function set_stat_panggilan(){
		$data = file_get_contents("php://input");
		$row = json_decode($data,true);

		$pid = $row['pid'];
		$pnowa = $row['pnowa'];
		$palasan = $row['palasan'];
		$pstat = $row['pstat'];		

		$p = $this->wame_model->set_stat_panggilan($pid, $pstat, $palasan);
		if($pstat == 2){ //TOLAK KIRIMI PESAN
			$pmsg = "
				*WA Notifikasi PA Semarang* _Assalamualaikum wr. wb._ Berdasarkan *Permohonan Konsultasi Langsung* Anda sebelumnya dengan ini kami sampaikan permintaan maaf karena kami tidak dapat memenuhi permintaan tersebut dengan alasan ".
					$palasan.". Terimakasih.
			";
			$psn = $this->kirim_pesan($pnowa, $pmsg);
		}
		echo 'Permohonan status diupdate';		
	}

	public function show_jenis_konsultasi(){
		$p = $this->wame_model->show_jenis_konsultasi();
		echo json_encode($p);
	}

	public function tambah_jenis_konsultasi(){
		$data = file_get_contents("php://input");
		$row = json_decode($data,true);
		$newj = $row['newj'];

		return 	$this->wame_model->tambah_jenis_konsultasi($newj);	
	}

	public function hapus_jenis_konsultasi(){
		$data = file_get_contents("php://input");
		$row = json_decode($data,true);
		$pid = $row['pid'];

		// echo 'Bajingan iki lhho id ne = '.$pid;
		return $this->wame_model->hapus_jenis_konsultasi($pid);
		// return "OK";
	}

	public function set_jam_panggilan(){
		$data = file_get_contents("php://input");
		$row = json_decode($data,true);
		$pid = $row['pid'];
		$pnowa = $row['pnowa'];
		$pmsg = $row['pmsg'];
		$pjcall = $row['pjcall'];

		$p = $this->wame_model->update_jam_panggilan($pjcall, $pid);

		$psn = $this->kirim_pesan($pnowa, $pmsg.' '.$pjcall.'. Harap ditunggu. Terimakasih.');
		// echo $pid.'='.$pjcall;
		echo 'Permohonan konsultasi dijadwalkan';
	}

	public function cek_konsul()
	{
		$data = file_get_contents("php://input");
		$row = json_decode($data,true);

		$filter_datakonsul = $row['filter'];
		$data['list_aduan'] = $this->wame_model->get_konsul($filter_datakonsul);
		// $data['live_konsul'] = $this->wame_model->get_live_konsul($filter_datakonsul);
		$this->load->view("konsul", $data, TRUE);
		// $list_aduan = $p->row();
		// echo $list_aduan;
		// echo json_encode($list_aduan);
	}

	public function pindah_pengaduan(){
		$data = file_get_contents("php://input");
		$row = json_decode($data,true);
		$id_konsul = $row['id'];
		return $this->wame_model->move_to('konsultasi', 'aduan', $id_konsul);
	}	

	public function pindah_umum(){
		$data = file_get_contents("php://input");
		$row = json_decode($data,true);
		$id_konsul = $row['id'];

		//KIRIM NOTIF KE KOOR UMUM
		$p = $this->wame_model->get_konsul_by_id($id_konsul);
		$dt = $p->row();
		$this->wame_model->notif_admin_informasi($dt->pengirim, $dt->pesan);

		return $this->wame_model->move_to('konsultasi', 'umum', $id_konsul);
	}	

	public function balas_konsul(){
		$tipe_pesan = 1;
		//PROSES UPLOAD FILE
		if(isset($_FILES['lampiran'])){
	        $tipe_pesan = 2;
	        $target_dir = $_SERVER['DOCUMENT_ROOT'].'/wame/lampiran/';
	        $namafile=$_FILES['lampiran']['name'];
	        $extension=pathinfo($namafile);
	        $extension=$extension['extension'];

	        $target_file = $target_dir . $_POST['id'].'_'.$namafile;
	        $fname = 'wame/lampiran/'. $_POST['id'].'_'.$namafile;
	        $filename =  $_POST['id'].'_'.$namafile;
			if (move_uploaded_file($_FILES["lampiran"]["tmp_name"], $target_file)) {
				$pesan = "The file ". htmlspecialchars( basename( $_FILES["lampiran"]["name"])). " has been uploaded.";
				$pesan = "Done, file wes keupload.";
			} else {
				$pesan = "Sorry, there was an error uploading your file.";
			}			
		}else{
			$tipe_pesan = 1;
			$filename = NULL;
		}

		$id_konsul = $_POST['id'];
		$pesan = $_POST['balasan'];
		$dt['balasan'] = $pesan;
		$dt['stat'] = 1;
		$dt['tipe_pesan'] = $tipe_pesan;
		$dt['fname'] = $filename;

		$where = array('id' => $id_konsul);
		$this->wame_model->update_data($where,'konsultasi',$dt);

		echo $id_konsul.'='.$pesan;			
	}

	public function get_konsul_balas(){
		$id_konsul = $this->input->post('id');
		$data = $this->wame_model->get_konsul_balasan_by_id($id_konsul);
		echo json_encode($data);		
	}

	public function set_selesai(){
		$data = file_get_contents("php://input");
		$row = json_decode($data,true);
		$id_konsul = $row['id'];

		$dt['stat'] = 2;
		$dt['dibalas'] = date("Y-m-d H:i:s");
		$where = array('id' => $id_konsul);
		$this->wame_model->update_data($where,'konsultasi',$dt);	
		echo 'Permohonan konsultasi selesai';		
	}	

	public function kirim_konsul(){
		$data = file_get_contents("php://input");
		$row = json_decode($data,true);
		$id_konsul = $row['id'];

		$p = $this->wame_model->get_konsul_by_id($id_konsul);
		$data_umum = $p->row();

		if($data_umum->tipe_pesan == 2){
			//KIRIM PESAN MEDIA
			$hasil = $this->kirim_media($data_umum->pengirim, base_url().'lampiran/'.$data_umum->fname, $data_umum->prefiks.' '.$data_umum->balasan);
			echo 'ini pesan media';
		}else{
			$hasil = $this->kirim_pesan($data_umum->pengirim, $data_umum->prefiks.' '.$data_umum->balasan. '. Terimakasih sudah melakukan konsultasi menggunakan Layanan SiNofita, jika Anda menginginkan untuk melakukan Konsultasi dan Informasi melalui panggilan langsung silahkan klik link berikut: https://reginfo.pa-semarang.go.id/req_konsul');
			echo 'ini pesan biasa';
		}
		$dt['stat'] = 2;
		$dt['dibalas'] = date("Y-m-d H:i:s");
		$where = array('id' => $id_konsul);
		$this->wame_model->update_data($where,'konsultasi',$dt);
		echo $hasil;		
	}

	public function kirim_pesan($tujuan, $pesan){

		$data = file_get_contents("php://input");
		$row = json_decode($data,true);

		$url2 = URL_API_KIRIM;
		$id = $this->wame_model->get_last_id_wapi();		

		$kirim2 = array(
			'token' => ACTIVE_TOKEN,
			'id'     => $id,
		   	'number'	=> $tujuan,
		   	'message'=> $pesan
		);

		$options2 = array(
		  'http' => array(
		    'method'  => 'POST',
		    'content' => json_encode( $kirim2 ),
		    'header'=>  "Content-Type: application/json\r\n" .
		                "Accept: application/json\r\n"
		    )
		);
		$context2  = stream_context_create( $options2 );
		$result2 = file_get_contents( $url2, false, $context2 );
		$response = json_decode( $result2 );	

		if($response->success == TRUE){
			$data_resp = array(
				"hasil_kode" => $response->success,
				"hasil_pesan" => $response->message
			);	
			echo '1';
		} else {
			$data_resp = array(
				"hasil_kode" => '0',
				"hasil_pesan" => 'GAGAL KIRIM'
			);
			echo '0';
		}
	}	

	public function kirim_media($tujuan, $filename, $caption){
		$penerima = $tujuan;
		$pesan = $caption;
		$fname = $filename;

		$url2 = URL_API_KIRIM_MEDIA;
		$id = $this->wame_model->get_last_id_wapi();		

		$kirim2 = array(
			'token' => ACTIVE_TOKEN,
			'id'     => $id,
		   	'number'	=> $penerima,
		   	'caption'=> $pesan,
		   	'file'=> $fname
		);
		$options2 = array(
		  'http' => array(
		    'method'  => 'POST',
		    'content' => json_encode( $kirim2 ),
		    'header'=>  "Content-Type: application/json\r\n" .
		                "Accept: application/json\r\n"
		    )
		);
		$context2  = stream_context_create( $options2 );
		$result2 = file_get_contents( $url2, false, $context2 );
		$response = json_decode( $result2 );

		if($response->success == TRUE){
			$data_resp = array(
				"hasil_kode" => $response->success,
				"hasil_pesan" => $response->message
			);	
			echo '1';
		} else {
			$data_resp = array(
				"hasil_kode" => '0',
				"hasil_pesan" => 'GAGAL KIRIM'
			);
			echo '0';
		}
	}	



}