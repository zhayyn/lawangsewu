<!-- Modal4 -->

<div class="modal fade in show" id="myModal" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
      Login
        <!-- <h1 align='center'>Login</h1> -->
      </div>
      <div class="modal-body">
          <center>
              <p><img src='<?php echo base_url()."assets/images/sinofita_logo.png";?>' alt='Mahkamah Agung' width='128px'></p>
          </center>
      <h1>sinofita</h1>
      <strong><i>Sistem Layanan Informasi, Notifikasi, Konsultasi dan Pengaduan</i></strong>
      <!-- <br>Selamat Datang di Inovasi Layanan Whatsapp terintegrasi Pengadilan Agama Semarang -->

      <?php
        $attributes = array('name' => 'login', 'id' => 'login_frm');
        echo form_open('wame_c/validation_credential',$attributes);
        echo "<div class='container' align='left'>";
            echo "Username:";
            $attributes = array('tabindex' => '1','class' => 'login', 'placeholder' => 'Username', 'name' => 'username','autofocus'   => 'autofocus', 'required'   => '');
            echo form_input($attributes);
            echo "</p><p>Password: ";
            $attributes = array('tabindex' => '2','class' => 'login', 'placeholder' => 'Password', 'name' => 'password','required'   => '');
            echo form_password($attributes);
            echo "</p>";           
            echo '<div class="container" align="center"><a class="btn btn-warning" href="'. base_url('wame_c/main/login').'"><i class="fa fa-sign-in"></i> Batal</a>&nbsp';
            $attributes = array('tabindex' => '3','class' => 'btn btn-primary', 'value' => '🔓 Login');
            echo form_submit($attributes);  
        echo "</div></div>";        

        if($error = $this->input->get('error')){
          ?>
          <div class="alert alert-danger" align="center">
            <strong>Login Gagal!</strong> <?php echo $error;?>
          </div>          
        <?php }?>
      </div>
      <div class="modal-footer">
        <!-- <h1 align='center'>Login Aplikasi</h1> -->
        Tidak punya akun? <strong><a href="<?php echo base_url('wame_c/main/home'); ?>">Lewat sini aja</a></strong>
      </div>      
    </div>
  </div>
</div>
    <!-- //Modal4 -->
