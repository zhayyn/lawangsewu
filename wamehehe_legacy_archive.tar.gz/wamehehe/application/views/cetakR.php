<html>
<head>
	<style type="text/css">
	table { 	
			font-family: Cambria,"Times New Roman",serif; 
			font-size: 22px;
			line-height: 100%;}
	h1 { font-family: Cambria,"Times New Roman",serif; }
	.alamat{
		font-family: Cambria,"Times New Roman",serif; 
		font-size:9px;
		line-height: 100%;
	}	
	.nomor{
		font-family: Cambria,"Times New Roman",serif; 
		font-size:100px;
		line-height: 100%;
	}
	.space
	{
		line-height: 50%
	}
   @page
   {
	margin-top:0; !important;
	margin :10px;
	size: 10cm 23cm;
   }	

	@media print 
	{
		.pagebreak {         
			clear: both;
        	page-break-after: always;
        }
	   @page
	   {
		margin-top:0; !important;
		margin :10px;
		size: 10cm 23cm;
	  }
	}
	
	</style>
</head>
<script>
	function printPage()
	{
		window.print();
		setTimeout(function () { window.close(); }, 100);
	}
</script>
<body onload="printPage()">
<div style="width: 100%;" class="container">
	<table width='100%' style="font-size:22px">
		<tr>
			<td align="center" width="10%">
				[LOGO]
			</td>
			<td align="center">
				<p><strong>MAHKAMAH AGUNG REPUBLIK INDONESIA<br>
				DIREKTORAT JENDERAL BADAN PERADILAN AGAMA<br>
				PENGADILAN TINGGI AGAMA SEMARANG<br>
				PENGADILAN AGAMA SEMARANG KELAS I A</strong></p>
				<span class="alamat">
					Jalan Urip Sumoharjo Nomor 5, Karanganyar, Kec.Tugu, Kota Semarang Jawa Tengah 50152<br>
					Telp. (024) 7606741 Fax. (024) 7622887. Website: https://pa-semarang.go.id<br>
					Email: sekretariat@pa-semarang.go.id, pasmg6@gmail.com
				</span>
			</td>
		</tr>
		<tr>
			<td colspan="2"><hr></td>
		</tr>

	</table>
	<br><br>
</div>
<div class="pagebreak"> </div>
</body>
</html>