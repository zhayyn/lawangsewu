<?php
	defined('BASEPATH') OR exit('No direct script access allowed');

	$tot_konsul_done = 0;
	$tot_konlive_done = 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>WAME KONSULTASI</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=yes">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="icon" href="./favicon.ico">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> -->


	<link href="<?php echo base_url('assets/font-awesome-4.7.0/css');?>/font-awesome.min.css" rel="stylesheet" type="text/css">

	<link rel="stylesheet" href="<?php echo base_url('assets/css');?>/w3-4.css">
	<link rel="stylesheet" href="<?php echo base_url('assets/css');?>/w3-theme-green.css"> 
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster&effect=shadow-multiple">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Allerta+Stencil">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href= "https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
  integrity= 
  "sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2"
  crossorigin="anonymous"> 

  <!-- Import jquery cdn -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
  integrity= 
  "sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
  crossorigin="anonymous"> 
  </script> 

  <script src= 
  "https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
  integrity= 
  "sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
  crossorigin="anonymous"> 
  </script> 

	<style type="text/css">
		/* Style the tab */
		.tab {
		  overflow: hidden;
		  border: 1px solid #ccc;
		  background-color: #f1f1f1;
		  width: 100%;
		}

		/* Style the buttons that are used to open the tab content */
		.tab button {
		  background-color: inherit;
		  float: left;
		  border: none;
		  outline: none;
		  cursor: pointer;
		  padding: 14px 16px;
		  transition: 0.3s;
		}

		/* Change background color of buttons on hover */
		.tab button:hover {
		  background-color: #ddd;
		}

		/* Create an active/current tablink class */
		.tab button.active {
		  background-color: #ccc;
		}

		/* Style the tab content */
		.tabcontent {
		  display: none;
		  padding: 6px 12px;
		  border: 1px solid #ccc;
		  border-top: none;
		  width: 100%;
		}	
	</style>
</head>
<body>

	<div id="loadingDiv" style="display:none"></div>
	<div class="w3-cell-row"  style="padding-top:24px"></div>

	<div class="w3-container-fluid">
		<!-- <div class="w3-container" align="center"> -->
			<!-- <div class="container"> -->
			<div class="panel">
			  <div class="panel-heading">
			  	<h1>KONSULTASI</h1>
			  	<button class="btn btn-sm btn-success" onClick="window.location.reload();"> <i class="fa fa-refresh"></i> Refresh Konsultasi</button>
			  	
			  	<button id="btjeniskonsul" class="btn btn-sm btn-primary"> <i class="fa fa-refresh"></i> Jenis Konsultasi</button>

				<table class="table table-sm" style="width : 40%;">
					<thead>
						<tr>
							<th align="left">ID</th>
							<th align="right">TOTAL</th>
							<th align="right">MASUK</th>
							<th align="right">BELUM_DIJAWAB</th>
							<th align="right">BELUM_DIKIRIM</th>
							<th align="right">SELESAI</th>
						</tr>
					</thead>
					<tbody>
					<?php
						if($stat_konsultasi){
							foreach ($stat_konsultasi as $j) {	
								if($j->did == 2){	
									$m = $j->belum_dijawab + $j->belum_dikirim;
									$sl = $j->selesai;	

									if($j->id == 'Konsultasi'){
										$tot_konsul_done = $j->selesai;											
									}else{
										$tot_konlive_done = $j->selesai;
									}

					?>
						<tr>
							<td align="left"><?php echo $j->id;?></td>
							<td align="right"><?php echo $j->tot;?></td>
							<td align="right"><?php echo $j->belum_dijawab + $j->belum_dikirim;?></td>
							<td align="right"><?php echo $j->belum_dijawab;?></td>
							<td align="right"><?php echo $j->belum_dikirim;?></td>
							<td align="right"><?php echo $j->selesai;?></td>
						</tr>
					<?php 					
								}
							}
						}else{
							echo "<tr><td colspan='5'>KOSONG</td></tr>";
						}
					?>
					</tbody>
				</table>
			  	<p>Berikut adalah daftar permintaan Konsultasi. Silahkan klik <strong>isi Balasan</strong> untuk mengisi balasan. Jangan lupa pencet <strong>Kirim</strong> untuk mengirimkan balasan melalui Whatsapp API</p>
			  </div>
			  <div class="panel-body">

					<div class="tab">
					  <button class="tablinks" id="tmasuk" onclick="openCity(event, 'masuk')"><i class="fa fa-envelope-open"></i><strong> Masuk <span class="w3-badge w3-red"><?php echo $m;?></span></strong></button>
					  <button class="tablinks" id="tselesai" onclick="openCity(event, 'selesai')"><i class="fa fa-check-circle" aria-hidden="true"></i><strong> Selesai <span class="w3-badge w3-green"><?php echo $tot_konsul_done;?></span></strong></button>
					  <button class="tablinks" id="tlivekon" onclick="openCity(event, 'livekon')"><i class="fa fa-bullhorn" aria-hidden="true"></i><strong> Live Konsul</strong></button>
					  <button class="tablinks" id="tlivekonfin" onclick="openCity(event, 'livekonfin')"><i class="fa fa-check-square" aria-hidden="true"></i><strong> Live Konsul Selesai <span class="w3-badge w3-green"><?php echo $tot_konlive_done;?></span></strong></button>
					</div>

					<div id="masuk" class="tabcontent">
		                <table id="tbrbi" class="table table-striped table-sm" style="font-size: 90%;">
		                    <thead>
		                        <tr>                            
		                            <th style="vertical-align:middle" width="30%"><i>DATA</i></th>
		                            <th style="vertical-align:middle" width="30%"><i>BALASAN</i></th>
		                            <th style="vertical-align:middle" width="10%"><i>AKSI</i></th>
		                        </tr>
		                    </thead>
		                    <tbody>
		                    <?php
		                    	$no = 1;
		                    	if($list_konsul){
		                    		foreach ($list_konsul as $h) {
		                    ?>
										<tr>
											
											
											<td align='left' width="40%">										
											    <div class="panel panel-primary">
											      <div class="panel-heading">
											      	<?php echo '[#'.$no++.'] <i class="fa fa-user"></i> '.$h->pengirim.
											      		'<br><i class="fa fa-commenting"></i> <i>'.$h->dibuat.'</i>';
											      	?>
											      </div>
											      <div class="panel-body"><?php echo $h->pesan;?></div>
											    </div>
											</td>
											<td align='center' width="40%">
												<?php if($h->balasan){?>
											    <div class="panel panel-success">
											      <div class="panel-heading"><?php echo '<i class="fa fa-user"></i> Pengadilan Agama Semarang<br><i class="fa fa-commenting"></i> <i>'.$h->dibuat.'</i>';?></div>
											      <div class="panel-body" align="left"><?php 
											      		echo $h->balasan;
														      		if(isset($h->fname)){
														      			echo '<br><br><a href="'.base_url().'lampiran/'.$h->fname.'" target="_blank"><i class="fa fa-paperclip" aria-hidden="true"></i>'.$h->fname.'</a>';
														      		}										      		
											      	?></div>
											    </div>
											    <?php }else{ ?>
											    	<span>balasan kosong</span>
											    <?php }?>
											</td>

											<td align='right' width="20%">
												<?php 
													if ($h->stat == 0){
														echo '<span class="badge bg-danger">Belum Dibalas</span>';
													}else if($h->stat == 1){
														echo '<span class="badge bg-warning">Belum Dikirim</span>';
													}else if($h->stat == 2){
														echo '<span class="badge bg-success">Terbalas</span>';
													}else{
														echo '<span class="badge bg-danger">Gagal Kirim Pesan</span>';
													}
												?>
												
												<hr>										
												<button class="btn btn-success btn-sm btn-block" onclick="balas(<?php echo $h->id;?>)"><i class="fa fa-pencil-square-o"></i> Isi Balasan</button>
												<button class="btn btn-danger btn-sm btn-block" onclick="kirim(<?php echo $h->id;?>)"><i class="fa fa-paper-plane-o"></i> Kirim</button>
												<hr>
												<button class="btn btn-danger btn-sm btn-block" onclick="pindah_pengaduan(<?php echo $h->id;?>)"><i class="fa fa-stack-overflow"></i> Pindah Pengaduan</button>
												<button class="btn btn-danger btn-sm btn-block" onclick="pindah_umum(<?php echo $h->id;?>)"><i class="fa fa-stack-overflow"></i> Pindah Sekretariat</button>
												<button class="btn btn-primary btn-sm " onclick="set_selesai(<?php echo $h->id;?>)"><i class="fa fa-check-square-o" aria-hidden="true"></i> Set Selesai</button>
											</td>									
										</tr>		                   
		                    <?php
		                    		}
		                    	}else{
		                    		?>
		                    		<tr><td colspan="7">DATA KOSONG</td></tr>
		                    	<?php 

		                    	}
		                    ?>
		                    </tbody>
		                </table>
					</div>
					<div id="selesai" class="tabcontent">
		                <table id="tbrbi" class="table table-striped table-sm" style="font-size: 90%;">
		                    <thead>
		                        <tr>                            
		                            <th style="vertical-align:middle" width="30%"><i>DATA</i></th>
		                            <th style="vertical-align:middle" width="30%"><i>BALASAN</i></th>
		                            <th style="vertical-align:middle" width="10%"><i>AKSI</i></th>
		                        </tr>
		                    </thead>
		                    <tbody>
		                    <?php
		                    	$no = 1;
		                    	if($list_konsul_selesai){
		                    		foreach ($list_konsul_selesai as $h) {
		                    ?>
										<tr>
											<td align='left' width="40%">										
											    <div class="panel panel-default class">
											      <div class="panel-heading">
											      	<?php echo '[#'.$no++.'] <i class="fa fa-user"></i> '.$h->pengirim.
											      		'<br><i class="fa fa-commenting"></i> <i>'.$h->dibuat.'</i>';
											      	?>
											      </div>
											      <div class="panel-body"><?php echo $h->pesan;?></div>
											    </div>
											</td>
											<td align='center' width="40%">
												<?php if($h->balasan){?>
											    <div class="panel panel-default class">
											      <div class="panel-heading"><?php echo '<i class="fa fa-user"></i> Pengadilan Agama Semarang<br><i class="fa fa-commenting"></i> <i>'.$h->dibuat.'</i>';?></div>
											      <div class="panel-body" align="left"><?php 
											      		echo $h->balasan;
														      		if(isset($h->fname)){
														      			echo '<br><br><a href="'.base_url().'lampiran/'.$h->fname.'" target="_blank"><i class="fa fa-paperclip" aria-hidden="true"></i>'.$h->fname.'</a>';
														      		}										      		
											      	?></div>
											    </div>
											    <?php }else{ ?>
											    	<span>balasan kosong</span>
											    <?php }?>
											</td>

											<td align='right' width="20%">
												<?php 
													if ($h->stat == 0){
														echo '<span class="badge bg-danger">Belum Dibalas</span>';
													}else if($h->stat == 1){
														echo '<span class="badge bg-warning">Belum Dikirim</span>';
													}else if($h->stat == 2){
														echo '<span class="badge bg-success">Terbalas</span>';
													}else{
														echo '<span class="badge bg-danger">Gagal Kirim Pesan</span>';
													}
												?>
											</td>									
										</tr>		                   
		                    <?php
		                    		}
		                    	}else{
		                    		?>
		                    		<tr><td colspan="7">DATA KOSONG</td></tr>
		                    	<?php 

		                    	}
		                    ?>
		                    </tbody>
		                </table>
					</div>
					<div id="livekon" class="tabcontent">
		                <table id="tbrby" class="table table-striped table-sm" style="font-size: 90%;">
		                    <thead>
		                        <tr>                            
		                            <th style="vertical-align:middle" width="30%"><i>DATA</i></th>
		                            <th style="vertical-align:middle" width="30%"><i>BALASAN</i></th>
		                            <th style="vertical-align:middle" width="10%"><i>AKSI</i></th>
		                        </tr>
		                    </thead>
		                    <tbody>
		                    <?php
		                    	$no = 1;
		                    	if($list_live_konsul){
		                    		foreach ($list_live_konsul as $h) {
		                    ?>
										<tr>
											<td align='left' width="40%">										
										      	<?php echo '[#'.$no++.'] <i class="fa fa-user"></i> '.$h->nowa.
										      		'<br><i class="fa fa-commenting"></i> <i>'.$h->tgl.'</i><br>'.
										      		'<b>'.$h->nama.'</b><br>'.
										      		'<span class="badge bg-danger">'.$h->uraian.'</span>';
										      	?>
											</td>
											<td align='center' width="40%">
												<a data-toggle="modal" class="btn btn-primary btn-block btn-xs edit-modal" 
													data-pid="<?php echo $h->id;?>" data-nowa="<?php echo $h->nowa;?>" data-prefiks="<?php echo $h->prefiks;?>" data-uraian="<?php echo $h->uraian;?>">
													<span><i class="fa fa-clock-o" aria-hidden="true"></i> Konfirmasi Jadwal Panggilan</span>
												</a>
											</td>

											<td align='center' width="20%">
												<a data-toggle="modal" class="btn btn-primary btn-block btn-xs edit-status" 
													data-pid="<?php echo $h->id;?>" data-nowa="<?php echo $h->nowa;?>" data-prefiks="<?php echo $h->prefiks;?>" data-uraian="<?php echo $h->uraian;?>">
												<?php 
													if ($h->stat == 0){
														echo '<span class="badge bg-danger"><i class="fa fa-envelope-o" aria-hidden="true"></i> Belum Diproses</span>';
													}else if($h->stat == 1){
														echo '<span class="badge bg-warning"><i class="fa fa-clock-o" aria-hidden="true"></i> Verifikasi OK: Jadwal Panggil</span>';
													}else if($h->stat == 3){
														echo '<span class="badge bg-success"><i class="fa fa-check-square" aria-hidden="true"></i> Selesai</span>';
													}else{
														echo '<span class="badge bg-secondary"><i class="fa fa-times-circle" aria-hidden="true"></i> Ditolak</span>';
													}
													if($h->jadwal_call){
														echo '<br><b>'.$h->jadwal_call.'</b>';
													}
												?>
												</a>
											</td>									
										</tr>		                   
		                    <?php
		                    		}
		                    	}else{
		                    		?>
		                    		<tr><td colspan="7">DATA KOSONG</td></tr>
		                    	<?php 

		                    	}
		                    ?>
		                    </tbody>
		                </table>						
					</div>
					<div id="livekonfin" class="tabcontent">
		                <table id="tbrby" class="table table-striped table-sm" style="font-size: 90%;">
		                    <thead>
		                        <tr>                            
		                            <th style="vertical-align:middle" width="30%"><i>DATA</i></th>
		                            <th style="vertical-align:middle" width="30%"><i>Status</i></th>
		                        </tr>
		                    </thead>
		                    <tbody>
		                    <?php
		                    	$no = 1;
		                    	if($list_live_konsulfin){
		                    		foreach ($list_live_konsulfin as $h) {
		                    ?>
										<tr>
											<td align='left' width="40%">										
										      	<?php echo '[#'.$no++.'] <i class="fa fa-user"></i> '.$h->nowa.
										      		'<br><i class="fa fa-commenting"></i> <i>'.$h->tgl.'</i><br>'.
										      		'<b>'.$h->nama.'</b><br>'.
										      		'<span class="badge bg-danger">'.$h->uraian.'</span>';
										      	?>
											</td>
											<td align='center' width="20%">
												<?php 
													echo "Status: ";
													if($h->stat == 3){
														echo '<span class="badge bg-success"><i class="fa fa-check-square" aria-hidden="true"></i> Selesai</span>';
													}else{
														echo '<span class="badge bg-secondary"><i class="fa fa-times-circle" aria-hidden="true"></i> Ditolak</span>';
													}
													if($h->jadwal_call){
														echo '<br>Panggilan: <b>'.$h->jadwal_call.'</b>';
													}
													if($h->alasan_tolak){
														echo '<br>Alasan Penolakan: <b>'.$h->alasan_tolak.'</b>';
													}
												?>
											</td>									
										</tr>		                   
		                    <?php
		                    		}
		                    	}else{
		                    		?>
		                    		<tr><td colspan="7">DATA KOSONG</td></tr>
		                    	<?php 

		                    	}
		                    ?>
		                    </tbody>
		                </table>
					</div>
			  </div>
			</div>
		<br><br>
	</div>

<div class="container">
<div id="modal_balas" class="modal" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h1>Balas Pesan <span id="idbalas"></span></h1>
                <!-- <button type="button" class="btn-close" data-bs-dismiss="modal_balas" onclick="document.getElementById('modal_balas').style.display='none'"></button> -->
            </div>
            <div class="modal-body">
            	<p><strong>Pertanyaan:</strong></p>
				<div class="w3-panel w3-leftbar w3-sand">
				  <p class="w3-xsmall w3-serif">
				  <i><span id="pertanyaan"></span></i></p>  
				</div>
                <form method="POST" enctype="multipart/form-data" id="fbalas">
                <!-- <form id="upl_form" class="" method="post" action="#" enctype="multipart/form-data"> -->
                    <input type="hidden" id="id_konsul" name="id_konsul">
                    
                    <label for="curr_dok">Balasan: </label><br>
                    <span id="prefix" name="prefix"></span><br>
                    <textarea form="fbalas" id="balasan" style="width: 100%;" rows="5"></textarea>
                    <label for="dok_relaas">Lampirkan dokumen: </label>
                    <input type="file" id="dok_relaas" name="dok_relaas">
                    <p>Lampiran sebelumnya: <span id="filelalu"></span></p>
                </form>                
            </div>
            <div class="modal-footer">
                <table width="100%">
                    <tr>
                        <td width="33%" align="left"><button type="button" onclick="document.getElementById('modal_balas').style.display='none'" class="btn btn-primary"><i class="fa fa-times"> Cancel</i></button><td>
                        <td width="33%"></td>
                        <!--<td width="25%"><button onclick="del_peler()" type="button" id="btn_peler_del" name="btn_peler_del" class="btn btn-danger">Hapus</button><td>-->
                        <td width="33%" align="right">
                            <!-- <button type="submit">Upload</button> -->
                            <button type="button" onclick="simpan_balas()" id="btn_dok" name="btn_dok" class="btn btn-success" value=""><i class="fa fa-floppy-o"> Simpan</i></button>
                        </td>    
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>
</div>

	<!-- MODAL JADWAL -->
    <div class="modal" id="addPesan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Penjadwalan Panggilan</h5>
                    <button type="button" class="close" data-dismiss="modal" onclick="document.getElementById('addPesan').style.display='none'" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body"> 
                    <form action="" id="form_pesan" method="post">
                        <input type="hidden" name="xnowa" id="xnowa">
                        <input type="hidden" name="xpid" id="xpid">
                        <input type="hidden" name="xmsg" id="xmsg">
                        <div>                          
                          <label id="inf_perkara">sdf</label>
                        </div>
                        <div class="form-group">
                            <label>Pesan Text ke Pihak:</label><br>
                            <span id="pref"></span>
                            <input type="datetime-local" id="jcall" name="jcall" required><br>
                            <p>Mohon untuk dapat menunggu hingga waktu yang telah ditentukan. Petugas kami akan segera menghubungi Anda di nomor ini. <br><strong>Terimakasih.</strong></p>
                        </div>                              
                    </form> 
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="document.getElementById('addPesan').style.display='none'">Tutup</button>
                    <button type="button" class="btn btn-primary" id="btn_peler"><i class="fa fa-paper-plane"></i> Kirim</button>
                </div>
            </div>
        </div>
    </div>


	<!-- MODAL STATUS -->
    <div class="modal" id="setStatus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Set Status Permohonan</h5>
                    <button type="button" class="close" data-dismiss="modal" onclick="document.getElementById('setStatus').style.display='none'" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body"> 
                	<form action="" id="form_pesan" method="post">
                		<input type="hidden" name="xpid" id="xpid">
                        <div>                          
                          <label id="inf_perkara">sdf</label>
                        </div>
                        <div class="form-group">
                        	<span id="prefstat"></span>
                        	<label>Status:</label><br>
                        	<select style="w3-input" id="stat_akhir" required>
                        		<option value="-1">Pilih status</option>
                        		<option value="2">Ditolak</option>
                        		<option value="3">Selesai</option>
                        	</select><br>
                        	<div id="divtolak" style="display: none;">
                        		<label>Alasan:</label><br>
                        		<textarea id="alasan_tolak" cols="50" rows="4"></textarea>
                        	</div>                            
                        </div>
                    </form>                                
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="document.getElementById('setStatus').style.display='none'">Tutup</button>
                    <button type="button" class="btn btn-primary" id="btn_stat"><i class="fa fa-paper-plane"></i> Ubah</button>
                </div>
            </div>
        </div>
    </div>
       
	<!-- MODAL JENIS KONSULTASI -->
    <div class="modal" id="modjenis" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog" role="dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Jenis Permohonan</h5>
                    <button type="button" class="close" data-dismiss="modal" onclick="document.getElementById('modjenis').style.display='none'" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                	<div class="w3-container">
	                	<form id="form_pesan" method="post">
	                		<input type="hidden" name="xpid" id="xpid">
	                        <div>                          
	                          <label id="inf_perkara">Jenis baru</label>
	                          <input type="text" id="ednewjenis" placeholder="Tulis jenis baru disini">
	                          <button id="bt_tambah_jenis" type="button" class="w3-btn w3-green btn btn-secondary" onclick="tambah_jenis()">Add</button>
	                        </div>
	                        
	                    </form>  
	                    <hr>
	                    <h3>Daftar Jenis Konsultasi</h3>
                		<table width="100%">
                			<thead>
                				<th>No</th>
                				<th>Jenis</th>
                				<th>Aksi</th>
                			</thead>
                			<tbody id="tbjenis">
                			</tbody>
                		</table>
                	</div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="document.getElementById('modjenis').style.display='none'">Tutup</button>
                </div>
            </div>
        </div>
    </div>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<!-- <script src="assets/plugin/jquery/jquery.js"></script>
<script src="assets/plugin/jquery-ui/jquery-ui.min.js"></script>
<script src="assets/plugin/jquery-ui/datepicker-id.js"></script> -->
</body>
<!--   Core JS Files   -->

<script>
	
	var bell = document.getElementById("bell"); 
	// var myVar = setInterval(my_ajax, 10000);
	var path = '../assets/audio/';
	var tingtong     = path + 'deng.mp3';
	var sound_call = [new Audio(tingtong)];

	document.getElementById("tmasuk").click();

	function setel_bell(){
		bell.play();
	}

	function openCity(evt, cityName) {
	  // Declare all variables
	  var i, tabcontent, tablinks;

	  // Get all elements with class="tabcontent" and hide them
	  tabcontent = document.getElementsByClassName("tabcontent");
	  for (i = 0; i < tabcontent.length; i++) {
	    tabcontent[i].style.display = "none";
	  }

	  // Get all elements with class="tablinks" and remove the class "active"
	  tablinks = document.getElementsByClassName("tablinks");
	  for (i = 0; i < tablinks.length; i++) {
	    tablinks[i].className = tablinks[i].className.replace(" active", "");
	  }

	  // Show the current tab, and add an "active" class to the button that opened the tab
	  document.getElementById(cityName).style.display = "block";
	  evt.currentTarget.className += " active";
	}	

	function pindah_pengaduan(id_konsul){
		var xhr = new XMLHttpRequest();
		var url='<?php echo base_url(); ?>konsultasi/pindah_pengaduan';
		xhr.open("POST", url, true);
		xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
		xhr.onreadystatechange = function(){
		  if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){
		  	// document.getElementById('balasan').value = xhr.responseText;
		    alert(xhr.responseText); location.reload();parseInt()
		  }
		};
		xhr.send(JSON.stringify({ id: id_konsul}));	
	}	

	function pindah_umum(id_konsul){
		var xhr = new XMLHttpRequest();
		var url='<?php echo base_url(); ?>konsultasi/pindah_umum';
		xhr.open("POST", url, true);
		xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
		xhr.onreadystatechange = function(){
		  if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){
		  	// document.getElementById('balasan').value = xhr.responseText;
		    alert(xhr.responseText); location.reload();parseInt()
		  }
		};
		xhr.send(JSON.stringify({ id: id_konsul}));	
	}	

	function balas(id_konsul){
		document.getElementById('id_konsul').value=id_konsul;		
        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>konsultasi/get_konsul_balas",
            dataType: 'json',
            data: {id: id_konsul},
            success: function(data) {
                $.each(data, function(index, value){  
				  	document.getElementById('pertanyaan').innerHTML = value.pesan;
				  	document.getElementById('prefix').innerHTML = value.prefiks;
				  	document.getElementById('balasan').value = value.balasan;
				  	if(value.fname){
				  		document.getElementById('filelalu').innerHTML = '<a href="<?php echo base_url();?>lampiran/'+value.fname+'" target="_blank">'+value.fname+'</a>';	
				  	}else{
				  		document.getElementById('filelalu').innerHTML = '<kosong>';
				  	}
                });                        
            },
                error: function(result) {
                alert('error');
            }
        });
		document.getElementById('modal_balas').style.display='block';		
	}

    async function simpan_balas() {
		var id_balas = document.getElementById('id_konsul').value;
		var pesan_balas = document.getElementById('balasan').value;
		var att0 = document.getElementById('dok_relaas').value;        

        let formData = new FormData(); 
        // formData.append("aksi",'update_relaas');
        formData.append("id", id_balas);
        formData.append("balasan", pesan_balas);
        formData.append("lampiran", dok_relaas.files[0]);
        await fetch('<?php echo base_url(); ?>konsultasi/balas_konsul',{
            method: "POST", 
            body: formData
        }); 
        alert('The file has been uploaded successfully.');
        document.getElementById('modal_balas').style.display='none';
        location.reload();
    }

	function tampil(filter_data){
		var xhr = new XMLHttpRequest();
		var url='<?php echo base_url(); ?>konsultasi/cek_konsul';
		xhr.open("POST", url, true);
		xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
		xhr.onreadystatechange = function(){
		  if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){	    
		    location.reload();parseInt()
		  }
		};
		xhr.send(JSON.stringify({ filter: filter_data}));		
	}

	function kirim(id_konsul){
		var xhr = new XMLHttpRequest();
		var url='<?php echo base_url(); ?>konsultasi/kirim_konsul';
		xhr.open("POST", url, true);
		xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
		xhr.onreadystatechange = function(){
		  if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){
		  	// if(xhr.responseText == '1'){
		  		alert('Pesan Terkirim ='+xhr.responseText)
		  	// } else{
		  	// 	alert('Pesan Gagal dikirim'); 
		  	// }
		    
		    location.reload();parseInt()
		  }
		};
		xhr.send(JSON.stringify({ id: id_konsul}));
	}

	function set_selesai(id_konsul){
		var xhr = new XMLHttpRequest();
		var url='<?php echo base_url(); ?>konsultasi/set_selesai';
		xhr.open("POST", url, true);
		xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
		xhr.onreadystatechange = function(){
		  if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){
		  		alert(xhr.responseText);
		    location.reload(); parseInt();
		  }
		};
		xhr.send(JSON.stringify({ id: id_konsul}));
	}

    $("#btn_peler").click(function(e) {
    	e.preventDefault();

        var pid = document.getElementById("xpid").value;
        var pnowa = document.getElementById("xnowa").value;
        var pmsg = document.getElementById("xmsg").value;
        var pjcall = document.getElementById("jcall").value;

        pjcall = pjcall.replace("T"," ");
        pjcall = pjcall+":00";

		var xhr = new XMLHttpRequest();
		var url='<?php echo base_url(); ?>konsultasi/set_jam_panggilan';
		xhr.open("POST", url, true);
		xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
		xhr.onreadystatechange = function(){
		  	if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){
		  		// alert(xhr.responseText);
		        document.getElementById("addPesan").style.display="none";
		        window.location.reload();
		  	}
		};
		xhr.send(JSON.stringify(
				{ 
	                pmsg: pmsg,
	                pnowa: pnowa,
	                pid: pid,
	                pjcall: pjcall
				}));
    });

    $("#btjeniskonsul").click(function(e){
    		e.preventDefault();
    		tampiljenis();
    		document.getElementById("modjenis").style.display="block";


    	}
    )

    function tambah_jenis(){
    	var nj = document.getElementById('ednewjenis').value;
    	if(nj){
			var xhr = new XMLHttpRequest();
			var url='<?php echo base_url(); ?>konsultasi/tambah_jenis_konsultasi';
			xhr.open("POST", url, true);
			xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
			xhr.onreadystatechange = function(){
			  	if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){
			  		alert(xhr.responseText);
			  		tampiljenis();
			  	}
			};
			xhr.send(JSON.stringify({newj: nj}));
    	}
    }

	function tampiljenis(){
            $.ajax({
                type: "POST",
                url: '<?php echo base_url()?>konsultasi/show_jenis_konsultasi',
                dataType: 'json',
                data: {},
                success: function(data) {
            		var event_data = '';
                	var i = 1;
                    $.each(data, function(index, value){       

	                    event_data += '<tr>';
	                    event_data += '<td align="center" width="40%">'+i+'</td>';
	                    event_data += '<td align="left" width="60%">'+value.uraian+'</td>';
	                    event_data += '<td align="right">'+
	                    					'<button class="w3-btn w3-round-large w3-red w3-sm" onClick="hapusjenis('+value.id+')">Del</button>'+
	                    			'</td></tr>';
	                    i++;
                    });    

	                document.getElementById('tbjenis').innerHTML="";
	                $("#tbjenis").append(event_data);
                },
                    error: function(result) {
                    alert('error');
                }
            });
	}

	function hapusjenis(xid){
		var xhr = new XMLHttpRequest();
		var url='<?php echo base_url(); ?>konsultasi/hapus_jenis_konsultasi';
		xhr.open("POST", url, true);
		xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
		xhr.onreadystatechange = function(){
		  	if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){
		  		alert(xhr.responseText);
		  		tampiljenis();
		  	}
		};
		xhr.send(JSON.stringify({pid: xid}));
	}

    $("#btn_stat").click(function(e) {
    	e.preventDefault();

        var pid = document.getElementById("xpid").value;
        var pnowa = document.getElementById("xnowa").value;
        var pstat = document.getElementById("stat_akhir").value;
        var palasan = document.getElementById("alasan_tolak").value;

        // if(pstat != "-1"){
		var xhr = new XMLHttpRequest();
		var url='<?php echo base_url(); ?>konsultasi/set_stat_panggilan';
		xhr.open("POST", url, true);
		xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
		xhr.onreadystatechange = function(){
		  	if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){
		  		// alert(xhr.responseText);
		        document.getElementById("addPesan").style.display="none";
		        window.location.reload();
		  	}
		};
		xhr.send(JSON.stringify(
				{ 
	                pstat: pstat,
	                pnowa: pnowa,
	                pid: pid,
	                palasan: palasan
				}));
		// }
    }); 

	$('#stat_akhir').change(function() {
		if($(this).val() == 2){
			document.getElementById("divtolak").style.display="block";
		}else{
			document.getElementById("divtolak").style.display="none";
		}
	});    	
	
    $(document).on("click", ".edit-modal", function () {
        var pid = $(this).data('pid');
        var nowa = $(this).data('nowa');
        var prefiks = $(this).data('prefiks');
        var uraian = $(this).data('uraian');

        $(".modal-body #inf_perkara").html( 
            "Nomor WA: <b>"+nowa+"</b><br>"+
            "Atas Nama: <b>"+uraian+"</b>" 
          );
        
        document.getElementById("xnowa").value=nowa;
        document.getElementById("xpid").value=pid;
        document.getElementById("xmsg").value=prefiks;
        document.getElementById("pref").textContent = prefiks;
        document.getElementById("addPesan").style.display="block";
    }); 

    $(document).on("click", ".edit-status", function () {
        var pid = $(this).data('pid');
        var nowa = $(this).data('nowa');
        var prefiks = $(this).data('prefiks');
        var uraian = $(this).data('uraian');

        $(".modal-body #inf_perkara").html( 
            "Nomor WA: <b>"+nowa+"</b><br>"+
            "Atas Nama: <b>"+uraian+"</b>" 
          );
        
        document.getElementById("xnowa").value=nowa;
        document.getElementById("xpid").value=pid;
        // document.getElementById("xmsg").value=prefiks;
        document.getElementById("prefstat").textContent = prefiks;
        document.getElementById("setStatus").style.display="block";
    }); 	

</script>
</html>