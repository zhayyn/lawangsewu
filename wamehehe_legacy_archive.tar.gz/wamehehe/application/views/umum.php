<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>WAME UMUM SEKRETARIAT</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=no">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="icon" href="./favicon.ico">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> -->


	<link href="<?php echo base_url('assets/font-awesome-4.7.0/css');?>/font-awesome.min.css" rel="stylesheet" type="text/css">

	<link rel="stylesheet" href="<?php echo base_url('assets/css');?>/w3-4.css">
	<link rel="stylesheet" href="<?php echo base_url('assets/css');?>/w3-theme-green.css"> 
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster&effect=shadow-multiple">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Allerta+Stencil">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">	

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href= "https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
  integrity= 
  "sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2"
  crossorigin="anonymous"> 

  <!-- Import jquery cdn -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
  integrity= 
  "sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
  crossorigin="anonymous"> 
  </script> 

  <script src= 
  "https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
  integrity= 
  "sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
  crossorigin="anonymous"> 
  </script>   
	<style>
	    .accordion {
	      background-color: #eee;
	      color: #444;
	      cursor: pointer;
	      padding: 12px;
	      width: 100%;
	      border: none;
	      text-align: left;
	      outline: none;
	      font-size: 15px;
	      transition: 0.4s;
	    }
	    
	    .active, .accordion:hover {
	      background-color: #ccc;
	    }
	    
	    .accordion:after {
	      content: '\002B';
	      color: #777;
	      font-weight: bold;
	      float: right;
	      margin-left: 5px;
	    }
	    
	    .active:after {
	      content: "\2212";
	    }
	    
	    .panel {
	      padding: 0 8px;
	      background-color: white;
	      max-height: 0;
	      overflow: hidden;
	      transition: max-height 0.2s ease-out;
	    }

	</style> 
</head>
<body>
<!--     <div class="w3-top">
        <div class="w3-bar w3-white w3-left-align w3-card">            
            <a href="<?php echo base_url();?>wame_c/main/home"         class="w3-bar-item w3-button w3-green"><i class="fa fa-home w3-margin-right"></i>Beranda</a>
            <a href="#" onclick="window.location.reload();" class="w3-bar-item w3-button w3-left"><i class="fa fa-refresh"></i> Refresh</a>
            <a href="<?php echo base_url().'wame_c/logout';?>" class="w3-bar-item w3-button w3-right"><i class="fa fa-user-circle-o w3-margin-right"></i>Logout</a>
        </div>
    </div> -->
	<div id="loadingDiv" style="display:none"></div>
	<div class="w3-cell-row"  style="padding-top:48px"></div>

	<div class="w3-container-fluid">
		<div class="w3-container" align="center">
			<div class="row">
				<div class="col-sm-2" align="center">
					<img src="<?php echo base_url()?>/assets/images/sinofita_logo.png" width="80">
				</div>
				<div class="col-sm-10" align="left">
					<table class="table table-sm" style="width : 50%;">
						<thead>
							<tr>
								<th align="left" width="25%">ID</th>
								<th align="right">TOTAL</th>
								<th align="right">MASUK</th>
								<th align="right">BELUM_DIJAWAB</th>
								<th align="right">BELUM_DIKIRIM</th>
								<th align="right">SELESAI</th>
							</tr>
						</thead>
						<tbody>
						<?php
							if($stat_umum){
								foreach ($stat_umum as $j) {	
									if($j->did == 3){		
						?>
							<tr>
								<td align="left"><?php echo $j->id;?></td>
								<td align="right"><?php echo $j->tot;?></td>
								<td align="right"><?php echo $j->belum_dijawab + $j->belum_dikirim;?></td>
								<td align="right"><?php echo $j->belum_dijawab;?></td>
								<td align="right"><?php echo $j->belum_dikirim;?></td>
								<td align="right"><?php echo $j->selesai;?></td>
							</tr>
						<?php 					
									}
								}
							}else{
								echo "<tr><td colspan='5'>KOSONG</td></tr>";
							}
						?>
						</tbody>
					</table>					
				</div>				
			</div>
			<div class="row" align="left">
				<div class="col-sm-12">
				  	<p>Berikut adalah daftar pertanyaan terkait Umum Kesekretariatan. Silahkan klik <strong>isi Balasan</strong> untuk mengisi balasan. Jangan lupa pencet <strong>Kirim</strong> untuk mengirimkan balasan melalui Whatsapp API</p>
				</div>
			</div>			

    		<button class="accordion" id="acc_masuk"><i class="fa fa-envelope-open"><strong> Masuk <span class="w3-badge w3-red"><?php echo $j->belum_dijawab + $j->belum_dikirim;?></span></strong></i></button>
				<div class="panel panel-default">
				  	<div class="panel-body">
		                <table id="tbrbi" class="table table-striped table-sm" style="font-size: 90%;">
		                    <thead>
		                        <tr>
		                            <th style="vertical-align:middle" width="30%"><i>DATA</i></th>
		                            <th style="vertical-align:middle" width="30%"><i>BALASAN</i></th>
		                            <th style="vertical-align:middle" width="10%"><i>AKSI</i></th>
		                        </tr>
		                    </thead>
		                    <tbody>
		                    <?php
		                    	$no = 1;
		                    	if($list_umum){
		                    		foreach ($list_umum as $h) {
		                    ?>
										<tr>
											<td align='left' width="40%">
												<div class="w3-card-2">
													<header class="w3-container w3-blue">
												      	<?php echo '[#'.$no++.'] <i class="fa fa-user"></i> '.$h->pengirim.
												      		' <i class="fa fa-commenting"></i> <i>'.$h->dibuat.'</i>';
												      	?>																														
													</header>
													<div class="w3-container">
														<?php echo $h->pesan;?>
													</div>
												</div>
											</td>
											<td align='center' width="40%">
												<?php if($h->balasan){?>
											    <div class="w3-card-2">
											      <header class="w3-container w3-blue" align="left"><?php echo '<i class="fa fa-user"></i> Pengadilan Agama Semarang <i class="fa fa-commenting"></i> <i>'.$h->dibuat.'</i>';?></header>
											      <div class="w3-container" align="left"><?php 
											      		// $pf = $_SERVER['DOCUMENT_ROOT'].;
											      		echo $h->balasan;
											      		if(isset($h->fname)){
											      			echo '<br><br><a href="'.base_url().'lampiran/'.$h->fname.'" target="_blank"><i class="fa fa-paperclip" aria-hidden="true"></i>'.$h->fname.'</a>';
											      		}
											      	?></div>
											    </div>
											    <?php }else{ ?>
											    	<span class="badge bg-danger">Balasan Kosong</span>
											    <?php }?>
											</td>
											<td align='right' width="20%">
												<?php 
													if ($h->stat == 0){
														echo '<span class="badge bg-danger">Belum Dibalas</span>';
													}else if($h->stat == 1){
														echo '<span class="badge bg-warning">Belum Dikirim</span>';
													}else if($h->stat == 2){
														echo '<span class="badge bg-success">Terbalas</span>';
													}else{
														echo '<span class="badge bg-danger">Gagal Kirim Pesan</span>';
													}
												?>
												<hr>										
												<button class="btn btn-success btn-sm" onclick="balas(<?php echo $h->id;?>)"><i class="fa fa-pencil-square-o"></i> Isi Balasan</button>
												<?php 
													if ($h->stat == 1){
														echo '<button class="btn btn-danger btn-sm" onclick="kirim('.$h->id.')"><i class="fa fa-paper-plane-o"></i> Kirim</button>';
													}
												?>
												<hr>
												<button class="btn btn-danger btn-sm " onclick="pindah_pengaduan(<?php echo $h->id;?>)"><i class="fa fa-stack-overflow"></i> Lempar Pengaduan</button>
												<button class="btn btn-danger btn-sm " onclick="pindah_konsultasi(<?php echo $h->id;?>)"><i class="fa fa-stack-overflow"></i> Lempar Konsultasi</button>
												<button class="btn btn-primary btn-sm " onclick="set_selesai(<?php echo $h->id;?>)"><i class="fa fa-check-square-o" aria-hidden="true"></i> Set Selesai</button>
											</td>									
										</tr>		                   
		                    <?php
		                    		}
		                    	}else{
		                    		?>
		                    		<tr><td colspan="7">DATA KOSONG</td></tr>
		                    	<?php 

		                    	}
		                    ?>
		                    </tbody>
		                </table>
		            </div>
			  	</div>

		     <button class="accordion" id="acc_selesai"><i class="fa fa-check-circle" aria-hidden="true"></i><strong> Selesai <span class="w3-badge w3-green"><?php echo $j->selesai;?></span></strong></button>
				<div class="panel panel-default">
				  	<div class="panel-body">
		                <table id="tbrbi" class="table table-striped table-sm" style="font-size: 90%;" style="width: 100%;">
		                    <thead>
		                        <tr>
		                            <th style="vertical-align:middle" width="40%"><i>DATA</i></th>
		                            <th style="vertical-align:middle" width="40%"><i>BALASAN</i></th>
		                            <th style="vertical-align:middle" width="20%"><i>STATUS</i></th>
		                        </tr>
		                    </thead>
		                    <tbody>
		                    <?php
		                    	$no = 1;
		                    	if($list_umum_selesai){
		                    		foreach ($list_umum_selesai as $h) {
		                    ?>
										<tr>
											<td align='left' width="40%">
												<div class="w3-card-2">
													<header class="w3-container w3-grey">
												      	<?php echo '[#'.$no++.'] <i class="fa fa-user"></i> '.$h->pengirim.
												      		' <i class="fa fa-commenting"></i> <i>'.$h->dibuat.'</i>';
												      	?>																														
													</header>
													<div class="w3-container">
														<?php echo $h->pesan;?>
													</div>
												</div>
											</td>
											<td align='center' width="40%">
												<?php if($h->balasan){?>
											    <div class="w3-card-2">
											    	<header class="w3-container w3-grey" align="left"><?php echo '<i class="fa fa-user"></i> Pengadilan Agama Semarang <i class="fa fa-commenting"></i> <i>'.$h->dibuat.'</i>';?>
											  		</header>
											      	<div class="w3-container" align="left"><?php 
											      		// $pf = $_SERVER['DOCUMENT_ROOT'].;
											      		echo $h->balasan;
											      		if(isset($h->fname)){
											      			echo '<br><br><a href="'.base_url().'lampiran/'.$h->fname.'" target="_blank"><i class="fa fa-paperclip" aria-hidden="true"></i>'.$h->fname.'</a>';
											      		}
											      	?>
											      		
											      	</div>
											    </div>
											    <?php }else{ ?>
											    	<span>balasan kosong</span>
											    <?php }?>
											</td>
											<td align='right' width="20%">
												<?php 
													if ($h->stat == 0){
														echo '<span class="badge bg-danger">Belum Dibalas</span>';
													}else if($h->stat == 1){
														echo '<span class="badge bg-warning">Belum Dikirim</span>';
													}else if($h->stat == 2){
														echo '<span class="badge bg-success">Terbalas</span>';
													}else{
														echo '<span class="badge bg-danger">Gagal Kirim Pesan</span>';
													}
												?>
											</td>									
										</tr>		                   
		                    <?php
		                    		}
		                    	}else{
		                    		?>
		                    		<tr><td colspan="7">DATA KOSONG</td></tr>
		                    	<?php 

		                    	}
		                    ?>
		                    </tbody>
		                </table>
		                <br><br>
		            </div>
			  	</div>	        
		</div>
		<br><br>
	</div>

<div class="container">
	<div id="modal_balas" class="modal" role="dialog">
	    <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
	        <div class="modal-content">
	            <div class="modal-header">
	                <h1>Balas Pesan <span id="idbalas"></span></h1>
	            </div>
	            <div class="modal-body">
	            	<p><strong>Pertanyaan:</strong></p>
					<div class="w3-panel w3-leftbar w3-sand">
					  <p class="w3-xsmall w3-serif">
					  <i><span id="pertanyaan"></span></i></p>  
					</div>
	                <form method="POST" enctype="multipart/form-data" id="fbalas">
	                    <input type="hidden" id="id_konsul" name="id_konsul">	                    
	                    <label for="curr_dok">Balasan: </label><br>
	                    <span id="prefix" name="prefix"></span><br>
	                    <textarea form="fbalas" id="balasan" style="width: 100%;" rows="5"></textarea>
	                    <label for="dok_relaas">Lampirkan dokumen: </label>
	                    <input type="file" id="dok_relaas" name="dok_relaas"> 
	                </form>                
	            </div>
	            <div class="modal-footer">
	                <table width="100%">
	                    <tr>
	                        <td width="33%" align="left"><button type="button" onclick="document.getElementById('modal_balas').style.display='none'" class="btn btn-primary"><i class="fa fa-times"> Cancel</i></button><td>
	                        <td width="33%"></td>
	                        <td width="33%" align="right">
	                            <button type="button" onclick="simpan_balas()" id="btn_dok" name="btn_dok" class="btn btn-success" value=""><i class="fa fa-floppy-o"> Simpan</i></button>
	                        </td>    
	                    </tr>
	                </table>
	            </div>
	        </div>
	    </div>
	</div>
</div>

<script
  src="https://code.jquery.com/jquery-3.7.1.js"
  integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4="
  crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
<script>
	
	var bell = document.getElementById("bell"); 
	// var myVar = setInterval(my_ajax, 10000);
	var path = '../assets/audio/';
	var tingtong     = path + 'deng.mp3';
	var sound_call = [new Audio(tingtong)];

    var acc = document.getElementsByClassName("accordion");
    var i;
    
    for (i = 0; i < acc.length; i++) {
      acc[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        if (panel.style.maxHeight) {
          panel.style.maxHeight = null;
        } else {
          panel.style.maxHeight = panel.scrollHeight + "px";
        } 
      });
    }
    acc[0].click();

	function setel_bell(){
		bell.play();
	}

	function pindah_pengaduan(id_konsul){
		var xhr = new XMLHttpRequest();
		var url='<?php echo base_url(); ?>umum/pindah_pengaduan';
		xhr.open("POST", url, true);
		xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
		xhr.onreadystatechange = function(){
		  if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){
		  	// document.getElementById('balasan').value = xhr.responseText;
		    alert(xhr.responseText); location.reload();parseInt()
		  }
		};
		xhr.send(JSON.stringify({ id: id_konsul}));	
	}

	function pindah_konsultasi(id_konsul){
		var xhr = new XMLHttpRequest();
		var url='<?php echo base_url(); ?>umum/pindah_konsultasi';
		xhr.open("POST", url, true);
		xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
		xhr.onreadystatechange = function(){
		  if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){
		  	// document.getElementById('balasan').value = xhr.responseText;
		    alert(xhr.responseText); location.reload();parseInt()
		  }
		};
		xhr.send(JSON.stringify({ id: id_konsul}));	
	}

	function balas(id_konsul){
		document.getElementById('id_konsul').value=id_konsul;		
        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>umum/get_umum_balas",
            dataType: 'json',
            data: {id: id_konsul},
            success: function(data) {
                $.each(data, function(index, value){  
				  	document.getElementById('pertanyaan').innerHTML = value.pesan;
				  	document.getElementById('prefix').innerHTML = value.prefiks;
				  	document.getElementById('balasan').value = value.balasan;
                });                        
            },
                error: function(result) {
                alert('error');
            }
        });
		document.getElementById('modal_balas').style.display='block';
	}

    async function simpan_balas() {
		var id_balas = document.getElementById('id_konsul').value;
		var pesan_balas = document.getElementById('balasan').value;
		var att0 = document.getElementById('dok_relaas').value;        

		// var acc = document.getElementsByClassName("accordion");

        let formData = new FormData(); 
        formData.append("id", id_balas);
        formData.append("balasan", pesan_balas);
        formData.append("lampiran", dok_relaas.files[0]);
        await fetch('<?php echo base_url(); ?>umum/balas_umum',{
            method: "POST", 
            body: formData
        }); 
        alert('The file has been uploaded successfully.');
        document.getElementById('modal_balas').style.display='none';
        location.reload();    
	    // acc[0].click();
    }	

	function tampil(filter_data){
		var xhr = new XMLHttpRequest();
		var url='<?php echo base_url(); ?>umum/cek_umum';
		xhr.open("POST", url, true);
		xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
		xhr.onreadystatechange = function(){
		  if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){	    
		    location.reload();parseInt()
		  }
		};
		xhr.send(JSON.stringify({ filter: filter_data}));		
	}

	function kirim(id_konsul){
		var xhr = new XMLHttpRequest();
		var url='<?php echo base_url(); ?>umum/kirim_umum';
		xhr.open("POST", url, true);
		xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
		xhr.onreadystatechange = function(){
		  if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){
		  		alert('Pesan Terkirim ='+xhr.responseText)
		    location.reload(); parseInt();
		  }
		};
		xhr.send(JSON.stringify({ id: id_konsul}));
	}

	function set_selesai(id_umum){
		var xhr = new XMLHttpRequest();
		var url='<?php echo base_url(); ?>umum/set_selesai';
		xhr.open("POST", url, true);
		xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
		xhr.onreadystatechange = function(){
		  if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){
		  		alert(xhr.responseText);
		    location.reload(); parseInt();
		  }
		};
		xhr.send(JSON.stringify({ id: id_umum}));
	}
	

	

</script>
</html>