<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Cetak extends CI_Controller {
	function __construct() {
		parent::__construct();	
		$this->load->helper(array('form', 'url','captcha'));	
	}

	public function index() {
		$this->load->helper(array('url'));
		$this->load->view('cetakR');
	}	
}