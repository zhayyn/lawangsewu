<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>QRcode Perkara</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=no">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="icon" href="./favicon.ico">
	<link href="<?php echo base_url('assets/css');?>/jquery-ui.css" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url('assets/css');?>/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url('assets/font-awesome-4.7.0/css');?>/font-awesome.min.css" rel="stylesheet" type="text/css">
	<script src="<?php echo base_url('assets/js');?>/jquery.js"></script>
	<script src="<?php echo base_url('assets/js');?>/jquery-ui.min.js"></script>
	<script src="<?php echo base_url('assets/js');?>/jquery-ui.js"></script>
	<script src="<?php echo base_url('assets/js');?>/bootstrap.js"></script>
	<link rel="stylesheet" href="<?php echo base_url('assets/css');?>/w3-4.css">
	<link rel="stylesheet" href="<?php echo base_url('assets/css');?>/w3-theme-green.css"> 
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster&effect=shadow-multiple">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Allerta+Stencil">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
</head>
<body>
	<div id="loadingDiv" style="display:none"></div>
	<div class="w3-cell-row"  style="padding-top:24px"></div>
	<div class="w3-container-fluid">
		<div class="w3-container" align="center">
			<div class="alert alert-danger">
			  <strong>Perhatian!</strong> Halaman ini masih dalam tahap pengembangan <a href="#" class="alert-link">Team IT PA Semarang</a>.
			</div>
		</div>
		<div class="w3-container" align="center">
			<div class="jumbotron">
			<h3>Buat & Kirim QR by Nomor Perkara:</h3>
			<table width='50%'  style="border-width: 0px; backgroud-color: none;">
				<tr>
				<td width="40%">Nomor Perkara:</td><td><input type="text" id="numperk"></input></td>
				</tr>
				<tr>
				<td>Kirim QR ke:</td><td><input type="text" id="nohp"></input></td>
				</tr>
			</table>
			<button class="btn btn-sm w3-green" onclick="genqr()"> CetakQR</button>
			<br>
			<br>
			<h3>Cek Decrypt</h3>
			<input type="text" id="decstr"></input><button class="btn btn-sm w3-green" onclick="decst();"> cek</button>

			</div>
		</div>
		<br><br>
	</div>







</body>
<!--   Core JS Files   -->
<script src="<?php echo base_url(); ?>assets/js/jquery-3.1.0.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js" type="text/javascript"></script>

<script>
	function genqr(){
		var data = new FormData();
		data.append('noperk', document.getElementById('numperk').value);

		var xmlhttp = new XMLHttpRequest();   // new HttpRequest instance 
		xmlhttp.open("POST", "<?php echo base_url(); ?>qr_c/genqr");
	      xmlhttp.onreadystatechange = function(){
	          if(xmlhttp.readyState == XMLHttpRequest.DONE && xmlhttp.status == 200){
	          	cetakqr(xmlhttp.responseText);
	          	kirimqr(xmlhttp.responseText);
	          }
	      };		
		xmlhttp.send(data);
	}

	function kirimqr(perkid){
		var nohp = document.getElementById('nohp').value;
		var xmlhttp = new XMLHttpRequest();   // new HttpRequest instance 
		xmlhttp.open("POST", "<?php echo base_url(); ?>kirim_c/kirim_media");
		xmlhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");

		xmlhttp.send(JSON.stringify(
			{
			outbox_id: 0,
		   	penerima	: nohp,
		   	pesan: perkid,
		   	fname: '<?php echo base_url();?>assets/qr/qr'+perkid+'.png'
			}
		));
	}	



	function decst(){
		var data = new FormData();
		data.append('str', document.getElementById('decstr').value);

		var xmlhttp = new XMLHttpRequest();   // new HttpRequest instance 
		xmlhttp.open("POST", "<?php echo base_url(); ?>qr_c/decqr");
		xmlhttp.send(data);
	}

	function cetakqr(vperkid){
		// var pid = vperkid;
		var data = new FormData();
		data.append('perkara_id', vperkid);
		var xmlhttp = new XMLHttpRequest();   // new HttpRequest instance 
		xmlhttp.open("POST", "<?php echo base_url(); ?>qr_c/cetak_qr");
		xmlhttp.send(data);
	}
</script>
</html>