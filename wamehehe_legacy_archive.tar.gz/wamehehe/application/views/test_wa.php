<div class="w3-container-fluid">
	<div class="w3-container" align="center">
		<div class="alert alert-danger">
		  <strong>Perhatian!</strong> Halaman ini masih dalam tahap pengembangan <a href="#" class="alert-link">Team IT PA Semarang</a>.
		</div>
	</div>
	<div class="w3-container" align="center">
		ID WAPI: <?php 
			if(isset($id)){
				echo $id;		
			}
			echo "<br>";
		?>
		<br>
						<form method="POST" action="<?php echo base_url('kirim_c/kirim_wa_test');?>">
						<p>Silahkan isikan <strong>nomor tujuan</strong> dan <strong>isi pesan</strong> yang akan dikirimkan</p><br>
						<table style="border-width: none;">	
						<tr>
							<td align="left">Penerima: </td>
							<td><input type="number" id="penerima" name="penerima" value="081317361689"></td>
						</tr><tr>	
							<td align="left">Pesan: </td>
							<td><input type="text" id="pesan" name="pesan"></td>
						</tr><tr>
							<td align="center" colspan="2">
								<input class="btn btn-sm btn-primary" type="submit" name="aksi" value="Kirim">
							</td>
						</tr>
						</table>
						</form>
						<hr>
						<a class="btn btn-sm w3-green" onclick="history.back()"><i class="fa fa-arrow-circle-left" aria-hidden="true"></i> kembali</a><br>



	</div>
	<div class="w3-container">
		<?php 
			if(isset($penerima)){
				echo $penerima."<br>";
			}
			if(isset($pesan)){
				echo $pesan;
			}
		?>

	</div>


</div>
<script type="text/javascript">

</script>