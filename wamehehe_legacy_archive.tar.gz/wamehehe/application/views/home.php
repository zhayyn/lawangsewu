
<div class="w3-container-fluid">
	<div class="w3-container" align="center">
		<div class="alert alert-danger">
		  <strong>Perhatian!</strong> Halaman ini masih dalam tahap pengembangan <a href="#" class="alert-link">Team IT PA Semarang</a>.
		</div>
	</div>
	<div class="w3-container" align="center">
		<div class="jumbotron">
			<p><b>Pengguna WA Konsultasi, Pengaduan dan Umum Sekretariat</b></p>
			<table class="table table-sm" style="width : 80%;">
				<thead>
					<tr>
						<th align="left">ID</th>
						<th align="right">TOTAL</th>
						<th align="right">BELUM_DIJAWAB</th>
						<th align="right">BELUM_DIKIRIM</th>
						<th align="right">SELESAI</th>
					</tr>
				</thead>
				<tbody>
				<?php
					$j1 = 0;
					$j2 = 0;
					$j3 = 0;
					$j4 = 0;
					if($stat_kosuladu){
						foreach ($stat_kosuladu as $j) {			
				?>
					<tr>
						<td align="left"><?php echo $j->id;?></td>
						<td align="right"><?php echo $j->tot;?></td>
						<td align="right"><?php echo $j->belum_dijawab;?></td>
						<td align="right"><?php echo $j->belum_dikirim;?></td>
						<td align="right"><?php echo $j->selesai;?></td>
					</tr>
				<?php 
							$j1 = $j1 + $j->tot;
							$j2 = $j2 + $j->belum_dijawab;
							$j3 = $j3 + $j->belum_dikirim;
							$j4 = $j4 + $j->selesai;						
						}
						echo "<tr>
								<td colspan='1'><b>TOTAL</b></td>
								<td colspan='1' align='right'><b>".$j1."</b></td>
								<td colspan='1' align='right'><b>".$j2."</b></td>
								<td colspan='1' align='right'><b>".$j3."</b></td>
								<td colspan='1' align='right'><b>".$j4."</b></td>
						</tr>";
					}else{
						echo "<tr><td colspan='5'>KOSONG</td></tr>";
					}
				?>
				</tbody>
			</table>
			<p><b>Pengguna WA Informasi</b></p>
			<table class="table table-sm" style="width : 80%;">
				<thead>
					<tr>
						<th align="left">NO</th>
						<th align="left">KET</th>
						<th align="right">JML</th>
					</tr>
				</thead>
				<tbody>
				<?php
					$j1 = 0; $nn = 1;
					if($stat_interaktif){
						foreach ($stat_interaktif as $j) {			
				?>
					<tr>
						<td align="left"><?php echo $nn++;?></td>
						<td align="left"><b><?php echo $j->keterangan;?></b></td>
						<td align="right"><?php echo $j->jml;?></td>
					</tr>
				<?php 
							$j1 = $j1 + $j->jml;						
						}
						echo "<tr>
								<td colspan='2'><b>TOTAL</b></td>
								<td colspan='1' align='right'><b>".$j1."</b></td>
						</tr>";
					}else{
						echo "<tr><td colspan='3'>KOSONG</td></tr>";
					}
				?>
				</tbody>				
			</table>
			<p><b>Status Notifikasi</b></p>
			<table class="table table-sm" style="width : 80%;">
				<thead>
					<tr>
						<th align="left">NO</th>
						<th align="left">KET</th>
						<th align="right">JML</th>
					</tr>
				</thead>
				<tbody>
				<?php
					$jx = 0; $nn = 1;
					if($stat_notif){
						foreach ($stat_notif as $j) {			
				?>
					<tr>
						<td align="left"><?php echo $nn++;?></td>
						<td align="left"><b><?php echo $j->keterangan;?></b></td>
						<td align="right"><?php echo $j->jml;?></td>
					</tr>
				<?php 
							$jx = $jx + $j->jml;						
						}
						echo "<tr>
								<td colspan='2'><b>TOTAL</b></td>
								<td colspan='1' align='right'><b>".$jx."</b></td>
						</tr>";
					}else{
						echo "<tr><td colspan='3'>KOSONG</td></tr>";
					}
				?>
				</tbody>				
			</table>
			<br>

			<?php 

				echo 'Jumlah Total Pengguna WA Informasi PA Semarang Th.'.date('Y').' : <h1>'.$tot_unique_num.'</h1><br>';


				if($lvluser == 1){
			?>
				<hr>
				Untuk memulai service WA silahkan buat session baru dengan klik tombol <strong>Buat Session Baru</strong> dibawah ini.<br><br>
				<a class="btn btn-sm w3-green" href="<?php echo base_url('wame_c/buat_sesi');?>"><i class="fa fa-sign-in" aria-hidden="true"></i> Buat Session Baru</a>	
			<?php 
				}
			?>
			

		</div>
	</div>
	<br><br>
</div>