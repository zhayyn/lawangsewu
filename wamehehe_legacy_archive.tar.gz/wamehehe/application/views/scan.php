
<div class="w3-container-fluid">
	<div class="w3-container" align="center">
		<div class="alert alert-danger">
		  <strong>Perhatian!</strong> Halaman ini masih dalam tahap pengembangan <a href="#" class="alert-link">Team IT PA Semarang</a>.
		</div>
	</div>
	<div class="w3-container" align="center">
		ID WAPI: <?php 
			if(isset($id)){
				echo $id;		
			}
			echo "<br>";
			if(isset($qr)){
				echo $qr;
			}
		?>
		<div class="alert alert-info">
		  <strong>Pastikan!</strong> setelah Anda melakukan scan, tunggu hingga logo WA <strong>bergoyang</strong>, jika tidak goyang maka WA belum aktif. Dan jika sudah selesai, 
		  Anda bisa akhiri dengan menghapus session WA dengan tombol dibawah ini<br>
		  <strong>Terimakasih</strong>
		</div>
		<?php 
			if(isset($id)){
				?>
				<a class='btn btn-sm w3-blue' href="<?php echo base_url("wame_c/main/sesi");?>"><i class="fa fa-arrow-circle-left" aria-hidden="true"></i> kembali</a>
				<a class='btn btn-sm w3-red' href="<?php echo base_url("wame_c/hapus_sesi?id=$id");?>"><i class="fa fa-sign-out" aria-hidden="true"></i> Hapus Sesi</a>
				<a class="btn btn-sm w3-orange" href="<?php echo base_url('wame_c/main/test');?>"><i class="fa fa-commenting" aria-hidden="true"></i> Test WA</a>
				<a class="btn btn-sm w3-green" href="<?php echo base_url('ambil_c/index');?>" target="_blank"><i class="fa fa-cogs" aria-hidden="true"></i> Service Ambil Data</a>				
				<a class="btn btn-sm w3-green" href="<?php echo base_url('kirim_c/index');?>" target="_blank"><i class="fa fa-cogs" aria-hidden="true"></i> Service Kirim Pesan</a>

			<?php 
			}
		?>		
		<br><br>
	</div>


</div>

<script type="text/javascript">
	// function kirim_pesan(){
	// 	// const url = 'http://wa-api.pa-semarang.go.id/send-message';
	// 	// const data = {id: '<?php echo $id?>', number: '082134390000', message: 'iki pesenanmu cuk pesan' };

	// 	var xhr = new XMLHttpRequest();
	// 	var url = "https://wa-api.pa-semarang.go.id/send-message";
	// 	xhr.open("POST", url, true);
	// 	xhr.setRequestHeader("Content-Type", "application/json");
	// 	xhr.onreadystatechange = function () {
	// 	    if (xhr.readyState === 4 && xhr.status === 200) {
	// 	        var json = JSON.parse(xhr.responseText);
	// 	        console.log(json.success + ", " + json.message);
	// 	    }
	// 	};
	// 	var data = JSON.stringify({"id": "<?php echo $id;?>", "number": "082134390000", "message" : "iki pke e XHR cuk"});
	// 	xhr.send(data);


	// }

</script>