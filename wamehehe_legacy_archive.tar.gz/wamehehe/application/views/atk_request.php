<?php
  ini_set('display_errors', '0');
  ini_set('display_startup_errors', '0');
  error_reporting(E_ALL);  
?>
<html>
<head>
	<title>ATK REQUEST</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=no">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <link rel="icon" href="./favicon.ico">
  <link href="<?php echo base_url('assets/css');?>/jquery-ui.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url('assets/css');?>/bootstrap.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url('assets/font-awesome-4.7.0/css');?>/font-awesome.min.css" rel="stylesheet" type="text/css">
  <script src="<?php echo base_url('assets/js');?>/jquery.js"></script>
  <script src="<?php echo base_url('assets/js');?>/jquery-ui.min.js"></script>
  <script src="<?php echo base_url('assets/js');?>/jquery-ui.js"></script>
  <script src="<?php echo base_url('assets/js');?>/bootstrap.js"></script>
  <link rel="stylesheet" href="<?php echo base_url('assets/css');?>/w3-4.css">
  <link rel="stylesheet" href="<?php echo base_url('assets/css');?>/w3-theme-green.css"> 
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster&effect=shadow-multiple">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Allerta+Stencil">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">

  <style type="text/css">
    body  {
      /*background-image: url("assets/images/steel.gif");*/
      /*background-color: #cccccc;*/
      font-family: Roboto, sans-serif;
    }  
    h1, h2, h3, h4, h5, h6  {
      font-family: Roboto, sans-serif;
    }  
    .w3-lobster {
      font-family: "Lobster", Sans-serif;  
    }
    .w3-allerta {
      /*font-family: "Allerta Stencil", Sans-serif;*/
      font-family: Roboto, sans-serif;
    }  
    .w3-sofia {
      font-family: Sofia, sans-serif;
    }   


  /* Full-width input fields */
  textarea, select, input[type=date], input[type=text], input[type=email], input[type=password] {
    width: 100%;
    padding: 8px 12px;
    margin: 4px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
  }

  /* Set a style for all buttons */
  button {
    background-color: #04AA6D;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
  }

  button:hover {
    opacity: 0.8;
  }

  /* Extra styles for the cancel button */
  .cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
  }

  /* Center the image and position the close button */
  .imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
    position: relative;
  }

  img.avatar {
    width: 40%;
    border-radius: 50%;
  }

  .container {
    padding: 8px;
  }

  span.psw {
    float: right;
    padding-top: 16px;
  }

  /* The Modal (background) */
  .modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    padding-top: 0;
  }

    .modal-backdrop {
       position: relative;
       z-index: -1
    }

  /* Modal Content/Box */
  .modal-content {
    background-color: #fefefe;
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    border: 1px solid #888;
    width: 80%; /* Could be more or less, depending on screen size */
  }

  /* The Close Button (x) */
  .close {
    position: absolute;
    right: 25px;
    top: 0;
    color: #000;
    font-size: 35px;
    font-weight: bold;
  }

  .close:hover,
  .close:focus {
    color: red;
    cursor: pointer;
  }

  /* Add Zoom Animation */
  .animate {
    -webkit-animation: animatezoom 0.6s;
    animation: animatezoom 0.6s
  }

  @-webkit-keyframes animatezoom {
    from {-webkit-transform: scale(0)} 
    to {-webkit-transform: scale(1)}
  }
    
  @keyframes animatezoom {
    from {transform: scale(0)} 
    to {transform: scale(1)}
  }

  /* Change styles for span and cancel button on extra small screens */
  @media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
  }

    .accordion {
      background-color: #eee;
      color: #444;
      cursor: pointer;
      padding: 12px;
      width: 100%;
      border: none;
      text-align: left;
      outline: none;
      font-size: 15px;
      transition: 0.4s;
    }
    
    .active, .accordion:hover {
      background-color: #ccc;
    }
    
    .accordion:after {
      content: '\002B';
      color: #777;
      font-weight: bold;
      float: right;
      margin-left: 5px;
    }
    
    .active:after {
      content: "\2212";
    }
    
    .panel {
      padding: 0 8px;
      background-color: white;
      max-height: 0;
      overflow: hidden;
      transition: max-height 0.2s ease-out;
    }
    .w3-tag{
        font-size: 0.8em;
    }
    .w3-panel{
        font-size: 0.8em;
    }
</style> 
</head>
<body>
    <div class="w3-top w3-row w3-card-2 w3-padding w3-center w3-white">
      <div class="w3-col w3-center" style="width:30px">
      </div>
      <div class="w3-rest w3-cell-middle"><span style="font-size: 18px"><i class="fa fa-cubes" aria-hidden="true"></i> Permohonan ATK Pegawai</span></div>
    </div>

    <div class="w3-container" id="utama" style="padding-top: 50px; display: block;">
        <div class="w3-panel w3-border w3-leftbar w3-green w3-round-large">
          <p>Selamat Datang <strong><?php echo $judul; ?></strong><br>
            Berikut Form Permohonan <strong>ATK</strong> Pegawai. Silahkan dilengkapi isian berikut ini.
            <br>
            <?php 
              $a = array('idpeg' => 29, 'tgl' => "2024-11-25");
              // echo base64_encode(json_encode($a));
            ?>
          </p>          
        </div>


      <!-- <div class="w3-card"> -->
        <form id='fin'>
            <input type="hidden" id="pegawai" name="pegawai" value="<?php echo $id_pegawai_login;?>" required>
            <input type="hidden" id="nama_pegawai" name="nama_pegawai" value="<?php echo $judul;?>" required>

            <div class="w3-card-2 w3-round-large">
                <div class="header w3-container w3-blue" style="top-padding: 12px;">
                    <strong><i class="fa fa-cubes"></i> Item & Kegunaan</strong>
                </div>
                <div class="w3-container">
                    Penggunaan:
                    <select class="w3-input w3-border w3-round-large" id="penggunaan" name="penggunaan" required>
                      <option value="-1">Pilih kegunaan dari item</option>
                      <option value="0">Perkara</option>
                      <option value="1">Non-Perkara</option>
                    </select>
                    <!-- <hr> -->
                    <div class="w3-tag w3-round-large w3-yellow w3-container w3-padding-4 w3-border">
                      Pilih item dari pilihan dibawah ini, masukkan jumlah, kemudian klik <strong>Masukkan ke Keranjang</strong> Ulangi untuk menambahkan item lainnya.
                    </div>
                    Pilihan Item ATK:                
                    <select class="w3-input w3-border w3-round-large" id="item" name="item" required>
                    <?php
                         // placeholder="Tuliskan nama barang yang Anda inginkan" 
                        if($atk_list_item){
                          foreach ($atk_list_item as $h) {
                              echo "<option value='".$h->item."'>".$h->item."</option>";
                          }
                        }
                    ?>  
                    </select>                
                    <!-- <input class="w3-input w3-border" type="text" list="itemx" id="item" name="item" required> -->
                    Jumlah:
                    <input class="w3-input w3-border w3-round-large" type="number" id="jml_item" name="jml_item" placeholder="Tuliskan jumlah" required>  

                    <button id="bt_add" onclick="tambah_item()" class="w3-btn w3-small w3-green w3-round-large w3-block"><i class="fa fa-plus-circle"></i> Masukkan ke Keranjang</button>
                </div>
            </div>
            <br>
            <!-- KERANJANG ITEM -->
            <div class="w3-card-4 w3-round-large">
                <div class="header w3-container w3-blue" style="top-padding: 12px;">
                    <strong><i class="fa fa-shopping-cart"></i> Keranjang</strong>
                </div>
                <div class="w3-container">
                    <p><strong>Daftar Barang yang diminta:</strong></p>
                    <div class="w3-bar">
                      <button id="bt_refresh" onclick="refresh_item()" class="w3-bar-item w3-button w3-small w3-blue w3-round-large"><i class="fa fa-refresh"></i> Refresh</button>
                      <button id="bt_clear" onclick="bersihkan()" class="w3-bar-item w3-button w3-small w3-red w3-round-large"><i class="fa fa-trash"></i> Kosongkan</button>
                    </div>              
                    
                    <table class="w3-table w3-border w3-striped" id="table_item">
                      <thead>
                        <th width="5%">No</th>
                        <th width="80%">NAMA</th>
                        <th width="10%">JML</th>
                        <th width="5%">AKSI</th>
                      </thead>
                      <tbody id="tbitem"></tbody>
                    </table>
                    <span id="tbinfo"></span>
                </div>
                <hr>  
                <div class="w3-container w3-center">
                    <label for="cek"><i class="fa fa-exclamation-circle" aria-hidden="true"></i> <strong>Saya setuju</strong></label>
                        <input type="checkbox" onclick="tampil_simpan()" id="cek" name="cek" required="">
                    <br>
                    <div id="divsimpan" align="center" style="display:none;">
                      <br>
                      <button type="button" class="w3-btn w3-green w3-round-large w3-block" id="btsimpan" name="btsimpan" onclick="kirim_request()"><i class="fa fa-paper-plane" aria-hidden="true"></i> Kirim</button>
                      <br><br>
                    </div>
                </div>   

            </div>


        </form>
      <!-- </div> -->
      <div class="w3-container">
      </div>
    </div>
    <div id="req_fail" class="w3-container"></div>
    <div id="req_ok" class="w3-container"></div>

  
</body> 

<script src="<?php echo base_url()?>/assets/plugin/jquery/jquery.js"></script>
<script src="<?php echo base_url()?>/assets/plugin/jquery-ui/jquery-ui.min.js"></script>
<script src="<?php echo base_url()?>/assets/plugin/jquery-ui/datepicker-id.js"></script>
<script type="text/javascript">

  function refresh_item(){
      document.getElementById('cek').checked = false;
      document.getElementById('divsimpan').style.display="none";

      $.ajax({
          type: "POST",
          url: "https://sinofita.pa-semarang.go.id/atk/refresh_item",
          dataType: 'json',
          data: {},
          cache:false,
          beforeSend: function() {
              $('#bt_refresh').html('<span id="iconstop" class="fa fa-play"></span>  Ambil data...');
              $('#iconstop').removeClass('fa fa-play').addClass('fa fa-spinner fa-spin');
              $('#bt_refresh').removeClass('w3-green').addClass('w3-red');
          },                
          success: function(data) {
              var event_data = '';
              var i = 1;
              $.each(data, function(index, value){
                event_data += '<tr><td>'+i+'</td><td><b>'+
                      value.name+'</b><br>';
                event_data += '</td><td>'+value.qty+
                      '</td><td><button id="bt_delete" onclick="hapus_item('+"'"+value.id+"'"+')" class="w3-button w3-red w3-tiny w3-round"><i class="fa fa-times-circle" aria-hidden="true"></i> Hapus</button></td></tr>';

                i++;
              });  
                  document.getElementById('tbitem').innerHTML="";
                  $("#tbitem").append(event_data);   
                  document.getElementById('tbinfo').textContent = 'Total item = '+ (i-1);

            $('#bt_refresh').html('<span id="iconstop" class="fa fa-refresh"></span>  Refresh');
            $('#iconstop').removeClass('fa fa-spinner fa-spin').addClass('fa fa-refresh');
            $('#bt_refresh').removeClass('w3-red').addClass('w3-green');
          },
          error: function() {
            $('#bt_refresh').html('<span id="iconstop" class="fa fa-floppy-o"></span>  Refresh');
            $('#iconstop').removeClass('fa fa-spinner fa-spin').addClass('fa fa-refresh');
            $('#bt_refresh').removeClass('w3-red').addClass('w3-green'); 
          }
      });     
  }

  function bersihkan(){
      document.getElementById('cek').checked = false;
      document.getElementById('divsimpan').style.display="none";

      $.ajax({
          type: "POST",
          url: "https://sinofita.pa-semarang.go.id/atk/bersihkan",
          dataType: 'json',
          data: {},
          cache:false,
          beforeSend: function() {
              $('#bt_clear').html('<span id="iconclear" class="fa fa-play"></span>  Kosongkan...');
              $('#iconclear').removeClass('fa fa-play').addClass('fa fa-spinner fa-spin');
              $('#bt_clear').removeClass('w3-green').addClass('w3-red');
          },                
          success: function(data) {
            
            $('#bt_clear').html('<span id="iconclear" class="fa fa-trash-o"></span>  Kosongkan');
            $('#iconclear').removeClass('fa fa-spinner fa-spin').addClass('fa fa-trash-o');
            $('#bt_clear').removeClass('w3-red').addClass('w3-red');                    

          },
          error: function() {
            $('#bt_clear').html('<span id="iconclear" class="fa fa-trash-o"></span>  Kosongkan');
            $('#iconclear').removeClass('fa fa-spinner fa-spin').addClass('fa fa-trash-o');
            $('#bt_clear').removeClass('w3-red').addClass('w3-red'); 
          }
      }); 
      bt_refresh.click();  
  }

  function hapus_item(ipid){
      $.ajax({
          type: "POST",
          url: "https://sinofita.pa-semarang.go.id/atk/hapus",
          dataType: 'json',
          data: {              
              pid : ipid
          },
          cache:false,
          beforeSend: function() {
              $('#bt_delete').html('<span id="icondel" class="fa fa-play"></span>  Menghapus...');
              $('#icondel').removeClass('fa fa-play').addClass('fa fa-spinner fa-spin');
              $('#bt_delete').removeClass('w3-green').addClass('w3-red');
          },                
          success: function(data) {            
            alert(data);
            bt_refresh.click();
            $('#bt_delete').html('<span id="icondel" class="fa fa-times-circle"></span>  Hapus');
            $('#icondel').removeClass('fa fa-spinner fa-spin').addClass('fa fa-times-circle');
            $('#bt_delete').removeClass('w3-red').addClass('w3-red');                    

          },
          error: function() {
            $('#bt_delete').html('<span id="icondel" class="fa fa-times-circle"></span>  Hapus');
            $('#icondel').removeClass('fa fa-spinner fa-spin').addClass('fa fa-times-circle');
            $('#bt_delete').removeClass('w3-red').addClass('w3-red'); 
          }
      }); 
  }

  function tambah_item(){
      var iitem = document.getElementById('item').value;
      var ijml = document.getElementById('jml_item').value;

      $.ajax({
          type: "POST",
          url: "https://sinofita.pa-semarang.go.id/atk/add",
          dataType: 'json',
          data: {
              item: iitem,
              jml: ijml
              // guna: iguna
          },
          cache:false,
          beforeSend: function() {
              $('#bt_add').html('<span id="iconadd" class="fa fa-play"></span>  Menambah...');
              $('#iconadd').removeClass('fa fa-play').addClass('fa fa-spinner fa-spin');
              $('#bt_add').removeClass('w3-green').addClass('w3-red');
          },                
          success: function(data) {
            alert(data);
            bt_refresh.click();

            $('#bt_add').html('<span id="iconadd" class="fa fa-plus-circle"></span>  Masukkan ke Keranjang');
            $('#iconadd').removeClass('fa fa-spinner fa-spin').addClass('fa fa-plus-circle');
            $('#bt_add').removeClass('w3-red').addClass('w3-green');                    

          },
          error: function() {
            $('#bt_add').html('<span id="iconadd" class="fa fa-plus-circle"></span>  Masukkan ke Keranjang');
            $('#iconadd').removeClass('fa fa-spinner fa-spin').addClass('fa fa-plus-circle');
            $('#bt_add').removeClass('w3-red').addClass('w3-green'); 
          }
      }); 
  }

  function tampil_simpan(){
     var cek = document.getElementById('cek').checked;
     if(cek){
      document.getElementById('divsimpan').style.display="block";
     }else{
      document.getElementById('divsimpan').style.display="none";
     }
  }

  function kirim_request(){
      var iid_peg = document.getElementById('pegawai').value;
      var pegawai = document.getElementById('nama_pegawai').value;
      var iguna = document.getElementById('penggunaan').value;

      var table = document.getElementById("table_item");
      var tbodyRowCount = table.tBodies[0].rows.length;
      if(iguna == -1){
          alert('kegunaan blm diisi');
          document.getElementById('cek').checked = false;
          document.getElementById('divsimpan').style.display="none";          
          document.getElementById('penggunaan').focus();
          exit;
      }

      if(tbodyRowCount > 0){
          $.ajax({
              type: "POST",
              url: "https://sinofita.pa-semarang.go.id/atk/simpan",
              dataType: 'json',
              data: {              
                  id_peg : iid_peg,
                  nm_peg: pegawai,
                  guna: iguna
              },
              cache:false,
              beforeSend: function() {
                  $('#btsimpan').html('<span id="iconstop" class="fa fa-play"></span>  Mengirim...');
                  $('#iconstop').removeClass('fa fa-play').addClass('fa fa-spinner fa-spin');
                  $('#btsimpan').removeClass('w3-green').addClass('w3-red');
              },                
              success: function(data) {
                $('#btsimpan').html('<span id="iconstop" class="fa fa-floppy-o"></span>  Kirim');
                $('#iconstop').removeClass('fa fa-spinner fa-spin').addClass('fa fa-floppy-o');
                $('#btsimpan').removeClass('w3-red').addClass('w3-green');  

                window.location.href = "https://sinofita.pa-semarang.go.id/atk/req_sukses";  
              },
              error: function() {
                $('#btsimpan').html('<span id="iconstop" class="fa fa-floppy-o"></span>  Kirim');
                $('#iconstop').removeClass('fa fa-spinner fa-spin').addClass('fa fa-floppy-o');
                $('#btsimpan').removeClass('w3-red').addClass('w3-green');  
                           
                window.location.href = "https://sinofita.pa-semarang.go.id/atk/req_sukses";
              }
          });         
      }else{
          document.getElementById('cek').checked = false;
          document.getElementById('divsimpan').style.display="none";        
          alert('Keranjang 0, isi terlebih dahulu');
      }
  }

</script>
</html>