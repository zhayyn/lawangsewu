<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blasting extends CI_Controller {
	
	function __construct() {
		parent::__construct();	
		$this->load->helper(array('form', 'url','captcha'));	

		// if($this->session->userdata('user_id')==NULL OR $this->session->userdata('user_id')=="" OR
		// 	$this->session->userdata('jenis_user') == "2"
		// 	){
		// 	redirect('wame_c/main/login');
		// }			
	}

	public function index()
	{
		// $this->mymodel->cek_tanggal();		
		$data['title']='Blasting Pesan Pegawai';
		$data['sub_title']='Blasting pesan tiap pagi buat pegawai PA Semarang';
		// $data['nama_pa'] = $this->mymodel->nama_pa();
		// $data['alamat_pa'] = $this->mymodel->alamat_pa();
		// $data['tgl_indonesia'] = $this->tanggal_indonesia();
		
		// $data['url']= base_url().'assets/img/profil.mp4';
		// $data['running_text'] = $this->mymodel->running_text();		
		//$data['content'] = $this->load->view('touch_webcam',$data2,true);
		// $this->load->view('touch2',$data);

		$skrg=abs(date("H"));
		$mulai_sidang=1;
		$akhir_sidang=13;
		// if($skrg<$mulai_sidang OR $skrg>=$akhir_sidang){
		// 	$this->load->view('touch_mobile_404',$data);
		// }else{

		// 	$this->load->view('touch_mobile',$data);
		// }
		$this->load->view('blast',$data);
	}
	
	public function get_blast(){
		return $this->wame_model->get_blasting_pegawai();
		// $nq = $q->row();
		// echo json_encode($nq);
	}

	public function show_list_blast(){
		$q = $this->wame_model->show_blasting_pegawai();
		echo json_encode($q);
	}
	
	public function get_reminder_sore(){
		$saiki = date('w', strtotime(date('Y-m-d')));
		if($saiki == 1 or $saiki ==2 or $saiki ==3 or $saiki==4 or $saiki==5){
			return $this->wame_model->get_reminder_absen_sore();
		}
	}

	public function get_reminder_pagi(){
		$saiki = date('w', strtotime(date('Y-m-d')));
		if($saiki == 1 or $saiki ==2 or $saiki ==3 or $saiki==4 or $saiki==5){
			return $this->wame_model->get_reminder_absen_pagi();
		}
	}
}
