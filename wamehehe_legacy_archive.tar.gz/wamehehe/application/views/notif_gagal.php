<!--     <div class="w3-top">
        <div class="w3-bar w3-white w3-left-align w3-card">            
            <a href="<?php echo base_url();?>wame_c/main/home" class="w3-bar-item w3-button w3-green"><i class="fa fa-home w3-margin-right"></i>Beranda</a>
            <a href="#" onclick="window.location.reload();" class="w3-bar-item w3-button w3-left"><i class="fa fa-refresh"></i> Refresh</a>
            <a href="<?php echo base_url().'wame_c/logout';?>" class="w3-bar-item w3-button w3-right"><i class="fa fa-user-circle-o w3-margin-right"></i>Logout</a>
        </div>
    </div> -->
<div class="w3-container-fluid">
	<div class="w3-container" align="center">
		<div class="alert alert-danger">
		  <strong>Perhatian!</strong> Halaman ini masih dalam tahap pengembangan <a href="#" class="alert-link">Team IT PA Semarang</a>.
		</div>
	</div>
	<div class="w3-container" align="center">
		<?php
			echo '
			<h2>Prosentase Kesuksesan Kirim Pesan Notifikasi</h2>
			<table class="table table-sm" style="width : 80%;">
				<thead>
					<tr>
						<th align="left">INFO</th>
						<th align="left">SUKSES</th>
						<th align="right">GAGAL</th>
						<th align="right">PROSENTASE</th>
					</tr>
				</thead>
				<tbody>';

				// <?php
					$jx = 0; $nn = 1;
					if($stat_proc_kirim){
						foreach ($stat_proc_kirim as $j) {			
				echo '
					<tr>
						<td align="left">'.$j->ket.'</td>
						<td align="left"><b>'.$j->tot.'</b></td>
						<td align="right">'.$j->fail.'</td>
						<td align="right">'.$j->proc.'%</td>
					</tr>';
							// $jx = $jx + $j->jml;						
						}
					}else{
						echo "<tr><td colspan='3'>KOSONG</td></tr>";
					}
				echo '
				</tbody>				
			</table>
			<p><i>"*Catatan: Kegagalan kirim dikarenakan Nomor Tidak Valid."</i></p>
			';
		?>


        <table id="tbrbi" class="table table-striped table-sm" style="font-size: 90%;">
            <thead>
                <tr>
                	<th style="vertical-align:middle" width="5%"><i>NO</i></th>
                    <th style="vertical-align:middle" width="15%"><i>PENERIMA</i></th>
                    <th style="vertical-align:middle" width="15%"><i>JENIS</i></th>
                    <th style="vertical-align:middle" width="30%"><i>BALASAN</i></th>
                    <th style="vertical-align:middle" width="10%"><i>TGL</i></th>
                    <th style="vertical-align:middle" ><i>AKSI</i></th>
                </tr>
            </thead>
            <tbody>
            <?php
            	$no = 1;
            	if($daftar_notif_gagal){
            		foreach ($daftar_notif_gagal as $h) {
            ?>
						<tr>
							<td align='center'><?php echo $no;?></td>
							<td align='left'><?php echo $h->penerima;?></td>
							<td align='left'>
							<?php
								if($h->tipe==1){
									$ket = 'Notifikasi AC';
								}else if($h->tipe==2){
									$ket = 'Notifikasi Jadwal Sidang';
								}else if($h->tipe==3){
									$ket = 'Notif Register Pendaftaran';	
								}else if($h->tipe==4){
									$ket = 'Notif Media QR Perkara';
								}else if($h->tipe==6){
									$ket = 'Notif Antrian Sidang Prioritas';
								}else{
									$ket = 'Notif Umum';
								}
								echo $ket;													
							?></td>
							<td align='left'><?php echo $h->hasil;?></td>
							<td align='left'><?php echo $h->dibuat;?></td>
							<td></td>	
						</tr>
			<?php
					$no++;
				}
			}

			?>
			</tbody>
		</table>
	</div>



</div>
<script type="text/javascript">

</script>