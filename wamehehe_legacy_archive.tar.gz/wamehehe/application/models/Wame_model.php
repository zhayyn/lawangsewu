<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Wame_model extends CI_Model{
	private $dbsipp;
	private $dbwapi;

	function __construct() {
		parent::__construct();
		$this->dbsipp = $this->load->database('dbsipp', TRUE);
		$this->dbwapi = $this->load->database('dbwapi', TRUE);
	}
	
	function validate(){
		$data = $this->session->flashdata('data');

		if($arita_user = $this->getUser_arita($data[0])){
			if($this->matchPassword_arita($data[1],$arita_user->pass)){
				$data = array(
					'full_name' 	=> $arita_user->nama,
					'nama_user' 	=> $arita_user->username,
					'user_id' 		=> $arita_user->id_user,
					'jenis_user' 	=> $arita_user->level_user,
					'bagian'		=> $arita_user->bagian
					);
				$this->session->set_userdata($data);
				return array(TRUE,'Anda sukses login', $arita_user->level_user);
			}
			else{
				return array(FALSE,'Password Salah!'.$data[0].' | '.$data[1], NULL);
			}
		}		
		else{
			return array(FALSE,'User dan Pass belum disetting!',NULL);
		}
	}

	
	// function getUser($data){
	// 	$value1 = $this->db->select(array('value','information'))->where('name','user_posbakum')->get('abt_config')->row();
 //  		$value2 = $this->db->where('name','pass_posbakum')->get('abt_config')->row('value');
	// 	if($this->encrypt->decode($data,'814sA')==$this->encrypt->decode($value1->value,'814sA')){
	// 		return array($value1->information,$value2);}
	// 	else{
	// 		return FALSE;}}

	function matchPassword($data1,$data2){
		// $data1 = $this->encrypt->decode($data1,'814sA');
		// $data2 = $this->encrypt->decode($data2,'814sA');

		if($data1==$data2){
			return TRUE;}
		else{
			return FALSE;}
	}

	function getUser_arita($data){
		// $user = $this->encrypt->decode($data,'814sA');
		$q = "SELECT * FROM wame.`users` WHERE username = '".$data."' LIMIT 1";
		return $this->db->query($q)->row();
	}

	function matchPassword_arita($pass,$data){
		// $pass = $this->encrypt->decode($pass,'814sA');
			// $password = $this->arr2md5(array($data->code_activation,$pass));
		if(md5($pass) == $data){
			return TRUE;}
		else{
			return FALSE;}
	}

	function get_all_session(){
		return $this->dbwapi->query("SELECT * FROM wa_session ORDER BY `timestamp` ASC;")->result();
	}

	function show_blasting_pegawai(){
		return $this->db->query("			
			SELECT a.*, b.nama
			FROM outbox a 
				LEFT OUTER JOIN pegawai b on b.telp= a.penerima
			WHERE a.tipe = 7 AND DATE(a.dibuat) = DATE(CURDATE())			
			GROUP BY a.id;
		")->result();		
	}

	function tambah_jenis_konsultasi($newj){
		return $this->db->query("INSERT INTO wame.req_jenis_konsul(uraian, aktif) VALUES('".$newj."',1);");
	}

	function hapus_jenis_konsultasi($pid){
		return $this->db->query("DELETE FROM wame.req_jenis_konsul WHERE id = $pid;");
	}

	function show_jenis_konsultasi(){
		return $this->db->query("
				SELECT * FROM wame.req_jenis_konsul ORDER BY uraian ASC;
			")->result();
	}

	function get_list_pegawai(){
		return $this->db->query("SELECT * FROM pegawai ORDER BY id ASC")->result();		
	}	

	function update_data_pegawai($pid, $tipe, $val){
		//BLAST PAGI
		if($tipe == 1){
			return $this->db->query("UPDATE wame.pegawai SET blast = $val WHERE id = $pid;");
		}else if($tipe == 2){
		//BLAST ABSEN PAGI REMMINDER
			return $this->db->query("UPDATE wame.pegawai SET abs_reminder_pagi = $val WHERE id = $pid;");
		}else if($tipe == 3){
		//BLAST ABSEN SORE REMMINDER
			return $this->db->query("UPDATE wame.pegawai SET abs_reminder_sore = $val WHERE id = $pid;");
		}else if($tipe == 4){
		//AKTIF
			return $this->db->query("UPDATE wame.pegawai SET aktif = $val WHERE id = $pid;");
		}else{
			return $pid;
		}
	}

	function get_blasting_absen_pagi(){
		return $this->db->query("
			INSERT INTO outbox(tipe, penerima, pesan, stat, tipe_pesan)
			SELECT 7*1 AS id, a.telp, 
				REPLACE(REPLACE(REPLACE(b.format_pesan, '#nama#', CONCAT('*',a.nama,'*')),'#hari#', CONCAT(
					CASE
						WHEN DATE_FORMAT(CURDATE(), '%w') = 0 THEN 'Senin'
						WHEN DATE_FORMAT(CURDATE(), '%w') = 1 THEN 'Selasa'
						WHEN DATE_FORMAT(CURDATE(), '%w') = 2 THEN 'Rabu'
						WHEN DATE_FORMAT(CURDATE(), '%w') = 3 THEN 'Kamis'
						WHEN DATE_FORMAT(CURDATE(), '%w') = 4 THEN 'Jumat'
						WHEN DATE_FORMAT(CURDATE(), '%w') = 5 THEN 'Sabtu'
						WHEN DATE_FORMAT(CURDATE(), '%w') = 6 THEN 'Minggu'
					END,', ',DATE_FORMAT(CURDATE(), '%d %M %Y'))), '#jk#', IF(a.jk = 1, 'Bpk.', 'Ibu')) pesan, 
				0, 1
			FROM (
				SELECT  a.id, a.nama, a.`telp`, a.jk, FLOOR(15+RAND()*(1-15)) id_pesan
				FROM pegawai a
				WHERE a.`aktif` = 1 AND a.`blast` = 1
				GROUP BY a.id
			)a 
				LEFT OUTER JOIN blast_config b ON b.`id` = 2
				LEFT OUTER JOIN blast c ON c.id = a.id_pesan
			GROUP BY a.id;
		");
	}

	function get_blast_atk_link($pid){
		return $this->db->query("
				SELECT b.`id` AS peg_id
				FROM wame.outbox a
					LEFT OUTER JOIN wame.pegawai b ON b.`telp` = a.`penerima`
				WHERE a.id = $pid
				GROUP BY a.id LIMIT 1;
			")->row()->peg_id;
	}

	function get_blasting_pegawai(){
		return $this->db->query("
			INSERT INTO outbox(tipe, penerima, pesan, stat, tipe_pesan)
			SELECT 7*1 AS id, a.telp, 
				REPLACE(REPLACE(REPLACE(b.format_pesan, '#nama#', CONCAT('*',a.nama,'*')),'#hadis#', c.pesan), '#jk#', IF(a.jk = 1, 'Bpk.', 'Ibu')) pesan, 
				0, 1
			FROM (
				SELECT  a.id, a.nama, a.`telp`, a.jk, FLOOR(15+RAND()*(1-15)) id_pesan
				FROM pegawai a
					LEFT OUTER JOIN outbox d ON d.penerima = a.telp AND d.tipe = 7 AND DATE(d.dibuat) = DATE(CURDATE())
				WHERE a.`aktif` = 1 AND a.`blast` = 1 AND d.id IS NULL
				GROUP BY a.id
			)a 
				LEFT OUTER JOIN blast_config b ON b.`id` = 1
				LEFT OUTER JOIN blast c ON c.id = a.id_pesan
			GROUP BY a.id;
		");
	}

	function get_reminder_absen_sore(){
		return $this->db->query("
				INSERT INTO outbox(tipe, penerima, pesan, stat, tipe_pesan)
				SELECT 9*1 AS id, a.telp, 
					REPLACE(
						REPLACE(
							REPLACE(b.format_pesan, '#nama#', CONCAT('*',a.nama,'*'))
						, '#jk#', IF(a.jk = 1, 'Bpk.', 'Ibu'))
					, '#hari#', tgl_indo(CURDATE(),2)) pesan, 
					0, 1
				FROM (
					SELECT  a.id, a.nama, a.`telp`, a.jk
					FROM pegawai a
						LEFT OUTER JOIN outbox d ON d.penerima = a.telp AND d.tipe = 9 AND DATE(d.dibuat) = DATE(CURDATE())
					WHERE a.`aktif` = 1 AND a.`abs_reminder_sore` = 1 AND d.id IS NULL
					GROUP BY a.id
				)a 
					LEFT OUTER JOIN blast_config b ON b.`id` = 3
				GROUP BY a.id;
			");
	}	

	function get_reminder_absen_pagi(){
		return $this->db->query("
				INSERT INTO outbox(tipe, penerima, pesan, stat, tipe_pesan)
				SELECT 8*1 AS id, a.telp, 
					REPLACE(
						REPLACE(
							REPLACE(b.format_pesan, '#nama#', CONCAT('*',a.nama,'*'))
						, '#jk#', IF(a.jk = 1, 'Bpk.', 'Ibu'))
					, '#hari#', tgl_indo(CURDATE(),2)) pesan, 
					0, 1
				FROM (
					SELECT  a.id, a.nama, a.`telp`, a.jk
					FROM pegawai a
						LEFT OUTER JOIN outbox d ON d.penerima = a.telp AND d.tipe = 8 AND DATE(d.dibuat) = DATE(CURDATE())
					WHERE a.`aktif` = 1 AND a.`abs_reminder_pagi` = 1 AND d.id IS NULL
					GROUP BY a.id
				)a 
					LEFT OUTER JOIN blast_config b ON b.`id` = 2
				GROUP BY a.id;
			");
	}

	function get_last_id_wapi(){		
		return $this->db->query("SELECT `key` AS `value` FROM `sessions` ORDER BY id DESC LIMIT 1;")->row()->value;
	}

	function getUser_sipp($data){
		$user = $this->encrypt->decode($data,'814sA');
		$this->dbsipp = $this->load->database("dbsipp",TRUE);
		$this->dbsipp->select(array('A.password','A.code_activation','A.fullname','A.userid','A.username','C.groupid','C.name'));
		$this->dbsipp->from('sys_users as A');
		$this->dbsipp->join('sys_user_group as B', 'A.userid = B.userid');
		$this->dbsipp->join('sys_groups as C', 'B.groupid = C.groupid');
		$this->dbsipp->where(array('B.groupid' => 1,'A.username' => "$user"));
		return $this->dbsipp->get()->row();		
	}
	
	function matchPassword_sipp($pass,$data){
		$pass = $this->encrypt->decode($pass,'814sA');
			$password = $this->arr2md5(array($data->code_activation,$pass));
		if($password == $data->password){
			return TRUE;}
		else{
			return FALSE;
		}
	}

	function arr2md5($arrinput){
	    $hasil='';
	    foreach($arrinput as $val){
	        if($hasil==''){
	            $hasil=md5($val);}
	        else {
	            $code=md5($val);
	            for($hit=0;$hit<min(array(strlen($code),strlen($hasil)));$hit++){
	                $hasil[$hit]=chr(ord($hasil[$hit]) ^ ord($code[$hit]));
	            }
	        }
	    }
	    return(md5($hasil));
	}
	
	public function GetKonfigurasi($name=NULL,$kolom='value'){
		if($name){
			return $this->db->query("select `$kolom` value from `abt_config` where name='$name';")->row()->value;}
		else{
			return $this->db->query("select * from `abt_config`;")->result();}
	}

	public function modul_main(){
		$this->db->close();
		return "<div class='w3-bottom'><div class='w3-bar w3-white w3-center w3-card'><font size='2'><strong>Pengadilan Agama Semarang</strong> © 2024</font></div></div>";
	}	

	public function insert_tabel($tabel,$data,$id=FALSE){
		$this->db->insert($tabel, $data);
		return TRUE;
	}	

	public function update_data($whereconditon,$tableName,$data){
		$this->db->where($whereconditon);
		$res=$this->db->update($tableName, $data);
		return $res;
	}	

	public function GetKonfigurasiSipp($key=''){
		$query = "select * from `sys_config` where name='$key'";
		return $this->dbsipp->query("$query")->row('value');
	}	

	public function truncate_tabel($table){
		$this->db->truncate($table);
		return TRUE;
	}

	public function delete_tabel($tabel,$data){
		$this->db->where($data);
		$this->db->delete($tabel);
		return TRUE;
	}

	public function GetTabel($tabel,$kolom=NULL,$where=NULL,$order=NULL,$urutan=NULL){
		if($kolom and $where){
			$this->db->where($kolom,$where);
		}
		if($order){
			$this->db->order_by($order,$urutan);
		}
		return $this->db->get($tabel)->result();
	}

	public function get_notif_gagal_kirim(){
		$q = $this->db->query("SELECT CONCAT(LEFT(penerima,6),'******') penerima, tipe, hasil, dibuat, stat, id FROM `outbox` WHERE stat in (2) ORDER BY dibuat DESC;");
		return $q->result();		
	}

	public function get_aduan(){
		$q = $this->db->query("SELECT *, CONCAT('<b>SiNofita PA Semarang</b> <i>Assalamualaikum wr. wb.</i> Berdasarkan pengaduan Anda pada ', DATE_FORMAT(dibuat,'%d-%m-%Y %h:%i:%s'), ' berikut dapat kami sampaikan:') AS prefiks FROM `aduan` WHERE stat in (0,1,3);");
		return $q->result();		
	}

	public function get_aduan_done(){
		$q = $this->db->query("SELECT *, CONCAT('<b>SiNofita PA Semarang</b> <i>Assalamualaikum wr. wb.</i> Berdasarkan pesan Anda pada ', DATE_FORMAT(dibuat,'%d-%m-%Y %h:%i:%s'), ' berikut dapat kami sampaikan:') AS prefiks FROM `aduan` WHERE stat in (2);");
		return $q->result();		
	}

	public function get_aduan_by_id($id_aduan){
		$q = $this->db->query("SELECT *, CONCAT('*SiNofita PA Semarang* _Assalamualaikum wr. wb._ Berdasarkan pengaduan Anda pada ', DATE_FORMAT(dibuat,'%d-%m-%Y %h:%i:%s'), ' berikut dapat kami sampaikan:') AS prefiks FROM `aduan` WHERE id = $id_aduan;");
		return $q;		
	}	

	public function set_stat_panggilan($pid, $pstat, $palasan){
		if($pstat == "2"){ //TOLAK PANGGILAN
			$q = $this->db->query("UPDATE wame.`req_konsul` SET stat = $pstat, alasan_tolak = '".$palasan."' WHERE id = $pid;");
		}else if($pstat == "3"){ //ZSELESAI
			$q = $this->db->query("UPDATE wame.`req_konsul` SET stat = $pstat WHERE id = $pid;");
		}

		if($q){
			echo 'OK';
		}else{
			echo 'GAGAL';
		}		
	}

	public function update_jam_panggilan($jcall, $pid){
		$q = $this->db->query("
				UPDATE wame.`req_konsul` SET jadwal_call = STR_TO_DATE('".$jcall."','%Y-%m-%d %h:%i:%s'), stat = 1 WHERE id = $pid;
			");

		if($q){
			return 'OK';
		}else{
			return 'GAGAL';
		}
	}

	public function get_live_konsulfin(){
		$q = $this->db->query("
				SELECT a.*, 
					CONCAT('*SiNofita PA Semarang* _Assalamualaikum wr. wb._ Berdasarkan permintaan Live Konsultasi Anda pada ', 
						DATE_FORMAT(a.tgl,'%d-%m-%Y %h:%i:%s'), ' berikut dapat kami sampaikan bahwa Kami akan menghubungi Anda di nomor Anda pada: ') AS prefiks, b.uraian
					FROM `req_konsul` a
						LEFT OUTER JOIN req_jenis_konsul b ON b.id = a.jenis_id
					WHERE a.stat in (2,3) 
					GROUP BY a.id;
			");
		return $q->result();			
	}

	public function get_live_konsul(){
		$q = $this->db->query("
				SELECT a.*, 
					CONCAT('*SiNofita PA Semarang* _Assalamualaikum wr. wb._ Berdasarkan permintaan Live Konsultasi Anda pada ', 
						DATE_FORMAT(a.tgl,'%d-%m-%Y %h:%i:%s'), ' berikut dapat kami sampaikan bahwa Kami akan menghubungi Anda di nomor Anda pada: ') AS prefiks, b.uraian
					FROM `req_konsul` a
						LEFT OUTER JOIN req_jenis_konsul b ON b.id = a.jenis_id
					WHERE a.stat in (0,1) 
					GROUP BY a.id;
			");
		return $q->result();			
	}

	public function get_konsul(){
		$q = $this->db->query("SELECT *, CONCAT('<b>SiNofita PA Semarang</b> <i>Assalamualaikum wr. wb.</i> Berdasarkan permintaan konsultasi Anda pada ', DATE_FORMAT(dibuat,'%d-%m-%Y %h:%i:%s'), ' berikut dapat kami sampaikan:') AS prefiks FROM `konsultasi` WHERE stat in (0,1,3) ORDER BY id DESC;");
		return $q->result();		
	}
	public function get_konsul_done(){
		$q = $this->db->query("SELECT *, CONCAT('<b>SiNofita PA Semarang</b> <i>Assalamualaikum wr. wb.</i> Berdasarkan pesan Anda pada ', DATE_FORMAT(dibuat,'%d-%m-%Y %h:%i:%s'), ' berikut dapat kami sampaikan:') AS prefiks FROM `konsultasi` WHERE stat in (2) ORDER BY id DESC;");
		return $q->result();		
	}	

	public function get_konsul_by_id($id_konsul){
		$q = $this->db->query("SELECT *, CONCAT('*SiNofita PA Semarang* _Assalamualaikum wr. wb._ Berdasarkan permintaan konsultasi Anda pada ', DATE_FORMAT(dibuat,'%d-%m-%Y %h:%i:%s'), ' berikut dapat kami sampaikan:') AS prefiks FROM `konsultasi` WHERE id = $id_konsul;");
		return $q;		
	}

	public function get_umum(){
		$q = $this->db->query("SELECT *, CONCAT('<b>SiNofita PA Semarang</b> <i>Assalamualaikum wr. wb.</i> Berdasarkan pesan Anda pada ', DATE_FORMAT(dibuat,'%d-%m-%Y %h:%i:%s'), ' berikut dapat kami sampaikan:') AS prefiks FROM `umum` WHERE stat in (0,1,3);");
		return $q->result();		
	}

	public function get_umum_done(){
		$q = $this->db->query("SELECT *, CONCAT('<b>SiNofita PA Semarang</b> <i>Assalamualaikum wr. wb.</i> Berdasarkan pesan Anda pada ', DATE_FORMAT(dibuat,'%d-%m-%Y %h:%i:%s'), ' berikut dapat kami sampaikan:') AS prefiks FROM `umum` WHERE stat in (2);");
		return $q->result();		
	}

	public function get_umum_by_id($id_umum){
		$q = $this->db->query("SELECT *, CONCAT('*SiNofita PA Semarang* _Assalamualaikum wr. wb._ Berdasarkan pesan Anda pada ', DATE_FORMAT(dibuat,'%d-%m-%Y %h:%i:%s'), ' berikut dapat kami sampaikan:') AS prefiks FROM `umum` WHERE id = $id_umum;");
		return $q;		
	}

	public function get_pegawai_list(){
		$q = $this->db->query("SELECT id, nama FROM wame.pegawai GROUP BY id ORDER BY id ASC;");
		return $q->result();		
	}

	public function get_item_list(){
		$q = $this->db->query("SELECT * FROM wame.atk_items GROUP BY id ORDER BY item ASC;");
		return $q->result();		
	}	

	function get_prefix_pesan($tabel, $id){
		if($tabel == 'aduan'){
			$str = 'pengaduan';
		}else if($tabel == 'konsultasi'){
			$str = 'permintaan konsultasi';
		}else{
			$str = 'pesan';
		}
		return $this->db->query("SELECT CONCAT('*SiNofita PA Semarang* Assalamualaikum wr. wb. Berdasarkan ".$str." Anda pada ', dibuat, ' berikut dapat kami sampaikan:') AS `value` FROM `".$tabel."` WHERE id = $id LIMIT 1;")->row()->value;
	}

	function get_konsul_balasan_by_id($id_konsul){		
		$pp = $this->get_prefix_pesan('konsultasi', $id_konsul);
		
		return $this->db->query("SELECT '".$pp."' as prefiks, `pengirim`, `pesan`,`balasan`, `fname` FROM `konsultasi` WHERE id = $id_konsul LIMIT 1;")->result();
	}	

	function get_aduan_balasan_by_id($id_aduan){
		$pp = $this->get_prefix_pesan('aduan', $id_aduan);		
		return $this->db->query("SELECT '".$pp."' as prefiks, `pengirim`,`pesan`,`balasan`, `fname` FROM `aduan` WHERE id = $id_aduan LIMIT 1;")->result();
	}

	function get_umum_balasan_by_id($id_umum){		
		// return $this->db->query("SELECT `balasan` AS `value` FROM `umum` WHERE id = $id_umum LIMIT 1;")->row()->value;
		$pp = $this->get_prefix_pesan('umum', $id_umum);
		return $this->db->query("SELECT '".$pp."' as prefiks, `pengirim`,`pesan`,`balasan`, `fname` FROM `umum` WHERE id = $id_umum LIMIT 1;")->result();
	}	

	function get_stat($id){
		if($id == 1){
			$q = $this->db->query("SELECT 1 as did, stat, CASE WHEN stat = 0 THEN 'Belum Dijawab' WHEN stat = 1 THEN 'Dijawab Belum Kirim' WHEN stat = 2 THEN 'Terkirim dan Selesai' END AS ket,  COUNT(id) jml FROM aduan GROUP BY stat");	
		}else if($id == 2){
			$q = $this->db->query("SELECT 2 as did, stat, CASE WHEN stat = 0 THEN 'Belum Dijawab' WHEN stat = 1 THEN 'Dijawab Belum Kirim' WHEN stat = 2 THEN 'Terkirim dan Selesai' END AS ket,  COUNT(id) jml FROM konsultasi GROUP BY stat");
		}else{
			$q = $this->db->query("SELECT 3 as did, stat, CASE WHEN stat = 0 THEN 'Belum Dijawab' WHEN stat = 1 THEN 'Dijawab Belum Kirim' WHEN stat = 2 THEN 'Terkirim dan Selesai' END AS ket,  COUNT(id) jml FROM umum GROUP BY stat");
		}		
		return $q->result();
	}


	public function get_pesan_keluar()
	{
		$q = $this->db->query("SELECT * FROM `outbox` where stat = '0'");
		return $q;
	}

	public function get_tot_unique_num(){
		return $this->db->query("select count(DISTINCT(a.num)) jml
			FROM(
				select pengirim as num FROM wame.aduan WHERE YEAR(dibuat) = YEAR(NOW()) group by pengirim 
				UNION ALL 
				select pengirim as num FROM wame.konsultasi WHERE YEAR(dibuat) = YEAR(NOW()) group by pengirim 
				UNION ALL 
				select pengirim as num FROM wame.umum WHERE YEAR(dibuat) = YEAR(NOW()) group by pengirim 
				UNION ALL 				
				select pengirim as num FROM wame.inbox WHERE YEAR(diterima) = YEAR(NOW()) group by pengirim 
				UNION ALL 
				select penerima as num FROM wame.outbox WHERE YEAR(dibuat) = YEAR(NOW()) GROup by penerima
			)a")->row()->jml;
	}

	public function move_to($asal, $tujuan, $curr_id){
		if($this->db->query("
				insert into wame.`".$tujuan."` (`pengirim`,`pesan`,`balasan`,`stat`,`dibuat`,`dibalas`)
				SELECT `pengirim`,`pesan`,`balasan`,`stat`,`dibuat`,`dibalas` FROM wame.`".$asal."`  WHERE `id` = $curr_id				
			")){
			if($this->db->query("DELETE FROM wame.`".$asal."` WHERE `id` = $curr_id")){
				echo 'Pindah '.$tujuan.' = OK';
			}else{
				echo 'Pindah '.$tujuan.' = GAGAL';
			}
		}else{
			echo 'Pindah '.$tujuan.' = GAGAL';
		}
	}

	public function get_items_request_by_id($rid){
		return $this->db->query("
				SELECT * FROM wame.atk_req_det WHERE req_id = $rid;
			")->result();
	}

	public function get_atk_req($stat){	
		$curr_user_bagian = $this->session->userdata('bagian');
		return $this->db->query("
				SELECT a.*, IF(a.`kegunaan` = 0, 'Perkara', 'Non-Perkara') guna, b.`nama`, b.`telp`, b.`jab`, COUNT(c.`id`) jml_item
				FROM wame.atk_req a
					LEFT OUTER JOIN pegawai b ON b.`id` = a.`id_peg`
					LEFT OUTER JOIN atk_req_det c ON c.`req_id` = a.`id`
				WHERE a.stat = ".$stat." 
					AND a.kegunaan = $curr_user_bagian
				GROUP BY a.`id`
				ORDER BY id DESC
			")->result();
	}

	public function get_pegawai_by_id($idpegawai){
		$nama = null;
		$hasil = 0;
		$nama = $this->db->query("SELECT IFNULL(nama,'') nama FROM `wame`.pegawai WHERE id = IFNULL($idpegawai,0) AND aktif = 1;")->row()->nama;
		if($nama){
			return $nama;
		}else{
			return '';
		}
		// if(strlen($nama) > 0){
		// 	echo json_encode(array('hasil' => 1, 'nama' => $nama));
		// }else{
		// 	echo json_encode(array('hasil' => 0, 'nama' => ''));
		// }
	}

	public function kirim_notif_admin_atk($idbaru){
			//KRIIM NOTIF PESAN	
		
			$this->db->query("CALL atk_notif_admin($idbaru);");
			mysqli_next_result( $this->db->conn_id);			
	}

	public function simpan_atk_request($idpeg, $peg, $guna){
		$lid = 0;
		$pesan = '';
		$lid = $this->db->query("CALL atk_req_baru($idpeg, $guna);")->row()->new_id;
		mysqli_next_result( $this->db->conn_id);
		if($lid == 0){
			$a = array(
					'new_id' => $lid,
					'hasil' => 0,
					'pesan' => 'Gagal Request ATK'
				);
		}else{
			//PROSES SIMPAN cart TO DB
			$this->load->library("cart");
			$j = 0;
			foreach($this->cart->contents() as $items){
				$this->db->query("INSERT INTO `wame`.atk_req_det(`req_id`, `item`, `jml`) VALUES($lid, '".$items['name']."',".$items['qty'].");");
				$j++;
			}
			$pesan = 'Data ID: '.$lid.' berhasil disimpan, '.$j.' item ditambahkan.';
			//HASIL
			$a = array(
					'new_id' => $lid,
					'hasil' => 1,
					'pesan' => $pesan
				);
		}

		// $hasilnya = 0;
		// try {
		//   $hasilnya = $this->kirim_notif_admin_atk($lid);
		// } catch(Exception $e) {
		//   $hasilnya = 0;
		// }		
		// echo json_encode($a);
		return $a;		
	}

	public function move_to_aduan($id_konsul){
		if($this->db->query("
				insert into wame.aduan (`pengirim`,`pesan`,`balasan`,`stat`,`dibuat`,`dibalas`)
				SELECT `pengirim`,`pesan`,`balasan`,`stat`,`dibuat`,`dibalas` FROM wame.konsultasi  WHERE `id` = $id_konsul				
			")){
			if($this->db->query("DELETE FROM wame.konsultasi WHERE `id` = $id_konsul")){
				echo 'Pindah Pengaduan = OK';
			}else{
				echo 'Pindah Pengaduan = GAGAL';
			}
		}else{
			echo 'Pindah Pengaduan = GAGAL';
		}
	}

	public function move_to_konsul($id_aduan){
		if($this->db->query("
				insert into wame.konsultasi (`pengirim`,`pesan`,`balasan`,`stat`,`dibuat`,`dibalas`)
				SELECT `pengirim`,`pesan`,`balasan`,`stat`,`dibuat`,`dibalas` FROM wame.aduan  WHERE `id` = $id_aduan				
			")){
			if($this->db->query("DELETE FROM wame.aduan WHERE `id` = $id_aduan")){
				echo 'Pindah Konsultasi = OK';
			}else{
				echo 'Pindah Konsultasi = GAGAL';
			}
		}else{
			echo 'Pindah Konsultasi = GAGAL';
		}
	}

	public function move_to_umum($id_aduan){
		if($this->db->query("
				insert into wame.umum (`pengirim`,`pesan`,`balasan`,`stat`,`dibuat`,`dibalas`)
				SELECT `pengirim`,`pesan`,`balasan`,`stat`,`dibuat`,`dibalas` FROM wame.aduan  WHERE `id` = $id_aduan				
			")){
			if($this->db->query("DELETE FROM wame.aduan WHERE `id` = $id_aduan")){
				// $this->notif_admin_informasi('<UNKNOWN>', '<RAHASIA>');
				echo 'Pindah Konsultasi = OK';
			}else{
				echo 'Pindah Konsultasi = GAGAL';
			}
		}else{
			echo 'Pindah Konsultasi = GAGAL';
		}
	}

	public function get_stat_proc_kirim(){
		$q = $this->db->query(
			"	
				SELECT a.*, ROUND((a.fail/a.tot)*100,2) proc
				FROM(
				SELECT 'Total Nomor (Unique)' AS ket,
					(SELECT COUNT(DISTINCT(a.`penerima`)) jml FROM outbox a WHERE YEAR(a.`dibuat`) = 2024) tot,
					(SELECT COUNT(DISTINCT(a.`penerima`)) jml FROM outbox a WHERE a.stat = 2 AND YEAR(a.`dibuat`) = 2024 AND a.`hasil` LIKE '%nomor tidak valid%') fail
				)a;		
			"
		);
		return $q->result();		
	}

	public function get_stat_notif(){
		$q = $this->db->query(
			"	
				SELECT
					CASE 
						WHEN a.tipe = 1 THEN 'Notifikasi AC'
						WHEN a.tipe = 2 THEN 'Notifikasi Jadwal Sidang'
						WHEN a.tipe = 3 THEN 'Notif Register Pendaftaran'
						WHEN a.tipe = 4 THEN 'Notif Media QR Perkara'
						WHEN a.tipe = 6 THEN 'Notif Antrian Sidang Prioritas'
						WHEN a.tipe = 7 THEN 'Notif Blasting Pegawai'
						ELSE 'Notifikasi Umum'
					END AS keterangan, COUNT(a.id) jml
				FROM outbox a
				WHERE YEAR(a.dibuat) = YEAR(NOW())
				GROUP BY a.`tipe`		
			"
		);
		return $q->result();
	}

	public function get_stat_interaktif(){
		$q = $this->db->query(
			"	
				SELECT a.*
				FROM(
					SELECT a.pesan, b.keterangan, COUNT(a.id) jml
					FROM inbox a
						LEFT OUTER JOIN `format` b ON b.perintah = a.pesan 
					WHERE YEAR(a.diterima) = YEAR(NOW()) AND a.tipe = 1
					GROUP BY a.pesan
				)a ORDER BY a.jml DESC			
			"
		);
		return $q->result();
	}

	public function get_stat_konsuladu(){
		$q = $this->db->query(
			"	SELECT 1 as did, 'Pengaduan' as id, 
						count(id) tot,
						IFNULL(SUM(IF(stat = 0,1,0)),0) as belum_dijawab,
						IFNULL(SUM(IF(stat = 1,1,0)),0) as belum_dikirim,
						IFNULL(SUM(IF(stat = 2,1,0)),0) as selesai
				FROM aduan WHERE year(dibuat) = year(now())
				UNION ALL

				SELECT 2 as did, 'Konsultasi' as id, 
						count(id) tot,
						IFNULL(SUM(IF(stat = 0,1,0)),0) as belum_dijawab,
						IFNULL(SUM(IF(stat = 1,1,0)),0) as belum_dikirim,
						IFNULL(SUM(IF(stat = 2,1,0)),0) as selesai
				FROM konsultasi WHERE year(dibuat) = year(now())
				UNION ALL 
				SELECT 2 as did, 'Konsultasi Langsung' as id, 
						count(id) tot,
						IFNULL(SUM(IF(stat = 0,1,0)),0) as belum_dijawab,
						IFNULL(SUM(IF(stat = 1,1,0)),0) as belum_dikirim,
						IFNULL(SUM(IF(stat in (2,3),1,0)),0) as selesai
				FROM req_konsul WHERE year(tgl) = year(now())
				UNION ALL 
				SELECT 3 as did, 'Umum Sekretariat' as id, 
						count(id) tot,
						IFNULL(SUM(IF(stat = 0,1,0)),0) as belum_dijawab,
						IFNULL(SUM(IF(stat = 1,1,0)),0) as belum_dikirim,
						IFNULL(SUM(IF(stat = 2,1,0)),0) as selesai
				FROM umum WHERE year(dibuat) = year(now())				
			"
		);
		return $q->result();
	}

	public function get_perkara_masuk(){
		$q = $this->db->query("
				select p.telepon, concat('*WA-NOTIFIKASI* PA Semarang. Assalamualaikum Wr.Wb, Ini merupakan pesan otomatis oleh sistem. Perkara ',a.jenis_perkara_text,' a/n ', a.pihak1_text,' terdaftar ',
					DATE_FORMAT(a.tanggal_pendaftaran,'%d %M %Y'),' dengan _NOMOR PERKARA_ *', a.nomor_perkara,
					'*. Untuk informasi lebih lanjut silahkan cek aplikasi LumpiaPasar di https://lumpiapasar.pasemarang.go.id') pesan,
					a.perkara_id , 3 as tipe, null as sidang_id, a.nomor_perkara
				from sipp.perkara a
				left outer join wame.outbox b on b.perkara_id = a.perkara_id and b.tipe = 3
				left outer join sipp.perkara_pihak1 c on c.perkara_id = a.perkara_id 
				left outer join sipp.pihak p on p.id = c.pihak_id 
				where b.perkara_id is null and date(a.tanggal_pendaftaran) = date(CURRENT_DATE()) and length(trim(p.telepon))>10 limit 1
			");
		return $q;
	}

	public function get_data_ac(){
		$q = $this->db->query("
			SELECT  b1.`telepon`,
				CONCAT(
				'*WA-NOTIFIKASI* PA Semarang. Assalamualaikum Wr.Wb, Ini merupakan pesan otomatis oleh sistem. Informasi telah terbit Akta Cerai untuk _Nomor Perkara_ ',
				c.`nomor_perkara`, ' dengan _Nomor Akta Cerai_ ', a.`nomor_akta_cerai`, ' pada tanggal ', DATE_FORMAT(a.`tgl_akta_cerai`,'%d %M %Y'),
				'. Mohon untuk dapat diambil di Kantor PA Semarang. Terimakasih') pesan,
				a.`perkara_id`, 1 AS tipe, null as sidang_id, c.nomor_perkara
			FROM sipp.perkara_akta_cerai a
				LEFT OUTER JOIN sipp.perkara_pihak1 b ON b.`perkara_id` = a.`perkara_id`
				LEFT OUTER JOIN sipp.pihak b1 ON b1.`id` = b.`pihak_id`
				LEFT OUTER JOIN sipp.`perkara` c ON c.`perkara_id` = a.`perkara_id`
				LEFT OUTER JOIN wame.`outbox` d ON d.`perkara_id` = a.`perkara_id` and d.tipe = 1
			WHERE a.`tgl_akta_cerai` = DATE_SUB(DATE(NOW()), INTERVAL 6 DAY)
				AND LENGTH(b1.`telepon`) > 10
				AND d.id IS NULL
			LIMIT 1
			");
		return $q;
	}

	public function get_data_jsid(){ //iki notifikasi sidang kggo pihak
		$q = $this->db->query("
			SELECT c1.telepon, CONCAT(
				'*WA-NOTIFIKASI* PA Semarang. Assalamualaikum Wr.Wb, Ini merupakan pesan otomatis oleh sistem. Informasi Jadwal Sidang ke-', a.urutan,
				' _Nomor Perkara_ ',b.nomor_perkara, ' akan dilaksanakan pada tanggal ', DATE_FORMAT(a.tanggal_sidang,'%d %M %Y'),
				'. Mohon bisa datang tepat waktu. Berdasarkan Surat Dirjen Badilag Mahkamah Agung Republik Indonesia Nomor 1812/DJA/HM.00/6/2021 tentang Peningkatan Kualitas Pelayanan, dengan ini kami sampaikan bahwa setiap Pengunjung/Tamu yang akan masuk area halaman maupun gedung Pengadilan Agama Semarang wajib diberlakukan 
*Proses Pemeriksaan (Screening) dan yang tidak berkepentingan tidak diperkenankan untuk memasuki area pengadilan (di luar pagar)*',',Terimakasih') pesan,
				a.`perkara_id`, 2 AS tipe, a.id as sidang_id, b.nomor_perkara
			FROM sipp.perkara_jadwal_sidang a
				LEFT OUTER JOIN sipp.perkara b ON b.perkara_id = a.`perkara_id`
				LEFT OUTER JOIN sipp.perkara_pihak1 c ON c.perkara_id = a.`perkara_id`
				LEFT OUTER JOIN sipp.pihak c1 ON c1.id = c.pihak_id
				LEFT OUTER JOIN wame.`outbox` d ON d.`perkara_id` = a.`perkara_id` and d.tipe = 2 and d.sidang_id = a.id
			WHERE DATE(a.`tanggal_sidang`) = DATE_ADD(DATE(NOW()), INTERVAL 1 DAY)
				AND LENGTH(c1.`telepon`) > 10
				AND d.id IS NULL 
				AND 
					(	a.`agenda` NOT LIKE '%tunda%lapor%' OR 
						a.`agenda` NOT LIKE '%coret%' OR
						a.`agenda` NOT LIKE '%gugur%' OR
						a.`agenda` NOT LIKE '%non%exec%' OR
						a.`agenda` NOT LIKE '%non%ekse%' OR
						a.`agenda` NOT LIKE '%ikrar%talak%'
					)
			LIMIT 1
			");
		return $q;
	}

	public function get_js_instrumen_notif(){
		//$this->db->query->free_result();
		$jeda = 2; //3 jam
		$q = $this->db->query("
				SELECT 	a.id, a.`perkara_id`, a.`sidang_id`, a.`tgl_sidang`, a.`dibuat`, a.`diproses`, a.`stat`, a.`keterangan`, 
						TIMESTAMPDIFF(HOUR, a.dibuat, NOW()) jam, 10 AS tipe 
				FROM wame.`tundaan_sidang` a 
				WHERE a.stat = 0 AND TIMESTAMPDIFF(HOUR, a.dibuat, NOW()) >= $jeda
				ORDER BY a.`dibuat` ASC
				LIMIT 1;				
			");
		return $q;
		$q->free_result();
	}

	public function get_biaya_psp(){
		$str_tgl = 'DATE(NOW())';
		$hsl = $this->db->query("CALL keuangan_pendukung.copy_biaya_psp(date(NOW()))");
		return $hsl;
		$hsl->free_result();
	}

	public function ins_psp_notif($a, $b, $c){
		return $this->db->query("INSERT INTO keuangan_pendukung.perkara_rek_psp_notif(`perkara_id`, `penerima`, `pesan`) VALUES(".$a.",'".$b."','".$c."')");
	}

	public function exec_notif_js($pid, $sid){
		return $this->db->query("CALL sipp.x_proses_notif_tundaan_sidang($pid, $sid);")->row()->pesan;
	}

	public function cek_qtemp($pengirim, $idwa){
			$balikan = array(
					"hasil" => 0,
					"pesan" => '<data error>'
				);

		$q = $this->db->query("SELECT pesan FROM qtemp WHERE pengirim = '".$pengirim."' AND id_wapi = '".$idwa."' ORDER BY diterima DESC LIMIT 1;");
		
		if($q->num_rows()){
		// if(strlen($data->pesan) > 0){
			$data = $q->row();
			$balikan = array(
					"hasil" => 1,
					"pesan" => $data->pesan
				);
		}else{
			$balikan = array(
					"hasil" => 0,
					"pesan" => '<data error>'
				);			
		}

		return $balikan;		
	}

	public function get_balasan2($perintah, $noperk=NULL){
		$str_sql = '';
		$hasil = 0;
		$balasan = 'PA Semarang Hebat';
		$str = '';

		$q = $this->db->query("SELECT * FROM `format` WHERE perintah = '".$perintah."' LIMIT 1");
		

		if($q->num_rows()){
			$data = $q->row();
			if($data->tipe == '1'){	
				$hasil = 1;
				$balasan = $data->balasan;
			}else{
				// $balasan = 'Maaf data tidak ditemukan '.$perintah;
				//CEK DATA IS SQL PO GAK
				$hasil = 1;
				$str_sql = $data->data_sql;			
				$r = $this->db->query(str_replace('#', '"'.$noperk.'%"' , $str_sql));
				$str = $r->row();

				if($r){
					if(strlen($str->pesan) > 10){
						$balasan = $str->pesan;	
		
					}else{
						$balasan = 'Maaf data tidak ditemukan '; //.$perintah.' -> '.$noperk.'----'.str_replace('#', '"'.$noperk.'%"' , $str_sql);
					}				
				}else{
					$balasan = 'Maaf data tidak ditemukan ';
				}

			}
		}

		$balikan = array(
				"hasil" => 1,
				"balasan" => $balasan
			);

		return $balikan;
	}

	function get_default_balas(){		
		return $this->db->query("SELECT `balasan` AS `value` FROM `format` WHERE perintah = '1' LIMIT 1;")->row()->value;
	}

	function get_daftar_prompt(){		
		return $this->db->query("SELECT `balasan` AS `value` FROM `format` WHERE perintah = '5' LIMIT 1;")->row()->value;
	}

	function get_daftar_item($id_daftar){		
		return $this->db->query("SELECT `balasan` AS `value` FROM `format` WHERE perintah = '".$id_daftar."' LIMIT 1;")->row()->value;
	}	

	function get_extra_text($perintah){	
		return $this->db->query("SELECT balasan FROM `format` WHERE perintah = '".$perintah."' LIMIT 1")->row()->balasan;
	}

	public function get_balasan($perintah, $noperk){
		$str_sql = '';
		$hasil = 0;
		$balasan = '';
		$str = '';

		$q = $this->db->query("SELECT * FROM aturan WHERE perintah = '".$perintah."' LIMIT 1");
		$data = $q->row();

		if($data->tipe == '1'){	
			$hasil = 1;
			$balasan = $data->balasan;
		}else{
			//CEK DATA IS SQL PO GAK
			$hasil = 1;
			$str_sql = $data->data_sql;			
			$r = $this->db->query(str_replace('#', '"'.$noperk.'%"' , $str_sql));
			$str = $r->row()->pesan;
			if(strlen($str) > 10){
				$balasan = $str;	
			}else{
				$balasan = 'Maaf data tidak ditemukan';
			}
		}

		$balikan = array(
				"hasil" => 1,
				"balasan" => $balasan
			);

		return $balikan;
	}

	// public function filter_data($filter){
	// 	return $this->db->query("SELECT * FROM ")
	// }

	public function simpan_data_qr2($data){
		return $this->db->query("INSERT INTO wame.qrdata2 (perkara_id, qr_data, qr_image) 
			VALUES (".$data['perkara_id'].",'".$data['qr_data']."','".$data['qr_image']."') ON DUPLICATE KEY UPDATE dibuat=NOW();");
	}

	public function simpan_data_qr($data){
		return $this->db->query("INSERT INTO wame.qrdata (perkara_id, qr_data, qr_image) 
			VALUES (".$data['perkara_id'].",'".$data['qr_data']."','".$data['qr_image']."') ON DUPLICATE KEY UPDATE dibuat=NOW();");
	}


	function get_id_by_nomor($numperk){
		return $this->db->query("SELECT `perkara_id` AS `value` FROM sipp.`perkara` WHERE nomor_perkara like '".$numperk."%' ORDER BY perkara_id DESC LIMIT 1")->row()->value;
	}

	public function notif_admin_atk($pengirim, $pesan){
		return $this->db->query("INSERT INTO wame.outbox (tipe, penerima, pesan, stat, tipe_pesan) 
				SELECT 5 AS tipe, nohp AS penerima, CONCAT('*SiNofita PA Semarang* _Assalamualaikum wr. wb._ Telah masuk *Permintaan ATK Pegawai* pada ', DATE_FORMAT(NOW(),'%d-%m-%Y %h:%i:%s'), ' Pengirim = ".$pengirim.", Item = [".$pesan.".] *Mohon untuk bisa segera ditindaklanjuti* Terimakasih') AS pesan, 0 AS stat, 1 AS tipe_pesan
				FROM users WHERE level_user = 4 AND username = 'atk' AND terima_notif = 1 LIMIT 1");		
	}

	public function notif_admin_informasi($pengirim, $pesan){
		return $this->db->query("INSERT INTO wame.outbox (tipe, penerima, pesan, stat, tipe_pesan) 
				SELECT 5 AS tipe, nohp AS penerima, CONCAT('*SiNofita PA Semarang* _Assalamualaikum wr. wb._ Telah masuk permohonan *Informasi* pada ', DATE_FORMAT(NOW(),'%d-%m-%Y %h:%i:%s'), ' Pengirim = ".$pengirim.", pesan = [".$pesan.".] *Mohon bisa segera ditindaklanjuti* Terimakasih') AS pesan, 0 AS stat, 1 AS tipe_pesan
				FROM users WHERE level_user = 4 AND terima_notif = 1 LIMIT 1");		
	}

	public function notif_admin_pengaduan($pengirim, $pesan){
		return $this->db->query("INSERT INTO wame.outbox (tipe, penerima, pesan, stat, tipe_pesan) 
				SELECT 5 AS tipe, nohp AS penerima, CONCAT('*SiNofita PA Semarang* _Assalamualaikum wr. wb._ Telah masuk *Pengaduan* pada ', DATE_FORMAT(NOW(),'%d-%m-%Y %h:%i:%s'), ' Pengirim = ".$pengirim.", pesan = [".$pesan.".] *Mohon bisa segera ditindaklanjuti* Terimakasih') AS pesan, 0 AS stat, 1 AS tipe_pesan
				FROM users WHERE level_user = 2 AND terima_notif = 1 LIMIT 1");		
	}

	public function notif_admin_konsultasi($pengirim, $pesan){
		return $this->db->query("INSERT INTO wame.outbox (tipe, penerima, pesan, stat, tipe_pesan) 
				SELECT 5 AS tipe, nohp AS penerima, CONCAT('*SiNofita PA Semarang* _Assalamualaikum wr. wb._ Telah masuk permintaan *Konsultasi* pada ', DATE_FORMAT(NOW(),'%d-%m-%Y %h:%i:%s'), ' Pengirim = ".$pengirim.", pesan = [".$pesan.".] *Mohon bisa segera ditindaklanjuti* Terimakasih') AS pesan, 0 AS stat, 1 AS tipe_pesan
				FROM users WHERE level_user = 3 AND terima_notif = 1 LIMIT 1");		
	}

}