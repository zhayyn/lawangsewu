<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pegawai extends CI_Controller {

	function __construct() {
		parent::__construct();	
		$this->load->helper(array('form', 'url','captcha'));	

		define('URL_API_SESSION','http://192.168.88.9:8088/session');
		define('URL_API_KIRIM', 'http://192.168.88.9:8088/send-message');
		define('URL_API_KIRIM_MEDIA', 'http://192.168.88.9:8088/send-media');
		define('URL_TERIMA', 'http://192.168.88.10/wame/wame_c/masuk');		
		define('ACTIVE_TOKEN', 'e1191a9cf5e26c2f8e68d45ca66a4908');	

		if($this->session->userdata('user_id')==NULL OR $this->session->userdata('user_id')=="" OR
			$this->session->userdata('jenis_user') == "2"
			){
			redirect('wame_c/main/login');
		}			
	}

	public function index() {
		$data['Judul'] = 'Pegawai';
		$data['data_pegawai'] = $this->wame_model->get_list_pegawai();
		$this->load->view('pegawai', $data);
	}

	public function update_pegawai(){
		$data = file_get_contents("php://input");
		$row = json_decode($data,true);

		$id = $row['pid'];
		$tipe = $row['tipe'];
		$val = $row['val'];

		$hasil = $this->wame_model->update_data_pegawai($id, $tipe, $val);
		echo json_encode($hasil);
	}
}