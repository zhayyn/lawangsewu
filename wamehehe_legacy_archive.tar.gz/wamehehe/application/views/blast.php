<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>BLASTING WA PEGAWAI</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=no">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="icon" href="./favicon.ico">
	<link href="<?php echo base_url('assets/css');?>/jquery-ui.css" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url('assets/css');?>/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url('assets/font-awesome-4.7.0/css');?>/font-awesome.min.css" rel="stylesheet" type="text/css">
	<script src="<?php echo base_url('assets/js');?>/jquery.js"></script>
	<script src="<?php echo base_url('assets/js');?>/jquery-ui.min.js"></script>
	<script src="<?php echo base_url('assets/js');?>/jquery-ui.js"></script>
	<script src="<?php echo base_url('assets/js');?>/bootstrap.js"></script>
	<link rel="stylesheet" href="<?php echo base_url('assets/css');?>/w3-4.css">
	<link rel="stylesheet" href="<?php echo base_url('assets/css');?>/w3-theme-green.css"> 
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster&effect=shadow-multiple">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Allerta+Stencil">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
</head>
<body>
	<div id="loadingDiv" style="display:none"></div>
	<div class="w3-cell-row"  style="padding-top:24px"></div>
	<div class="w3-container-fluid">
		<div class="w3-container" align="center">
			<div class="alert alert-danger">
			  <strong>Perhatian!</strong> Halaman ini masih dalam tahap pengembangan <a href="#" class="alert-link">Team IT PA Semarang</a>.
			</div>
		</div>
		<div class="w3-container" align="center">
			<div class="jumbotron">
				<img src="<?php echo base_url('assets/images/');?>sinofita_logo.png" width="10%" alt="bg" class="rounded">
				<p><b>BLASTING WA PEGAWAI</b> </p>
				<p> Pastikan terkoneksi dengan internet </p>
				<p> Biarkan halaman ini tetap terbuka / silahkan minimize</p>
				<p id="jam"></p>
				<p>

				<audio id="bell">
				<source src="<?php echo base_url(); ?>assets/audio/tingtong.mp3" type="audio/mpeg">
				Your browser does not support the audio element.
				</audio>
			</div>
			
			<div class="container">
			<font size="2">
				<button onclick="show_blast()"> Refresh</button>
                <table class="table table-striped table-sm">
                    <thead>
                        <tr>
                            <th style="vertical-align:middle" width="5%"><i>NO</i></th>
                            <th style="vertical-align:middle" width="10%"><i>PENERIMA</i></th>
                            <th style="vertical-align:middle" width="15%"><i>NAMA</i></th>
                            <th style="vertical-align:middle" width="50%"><i>PESAN</i></th>
                            <th style="vertical-align:middle" width="20%"><i>DIBUAT</i></th>
                        </tr>
                    </thead>
                    <tbody id="tblap1">
                    </tbody>
                </table> 			
			</div>
			</font>
		</div>
		<br><br>
	</div>

<!-- <script src="assets/plugin/jquery/jquery.js"></script>
<script src="assets/plugin/jquery-ui/jquery-ui.min.js"></script>
<script src="assets/plugin/jquery-ui/datepicker-id.js"></script> -->

</body>
<!--   Core JS Files   -->
<script src="<?php echo base_url(); ?>assets/js/jquery-3.1.0.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js" type="text/javascript"></script>


<script type="text/javascript">
	const INTERVAL_KIRIM = 10000;
	
	// var bell = document.getElementById("bell"); 
	var myVar = setInterval(my_ajax, INTERVAL_KIRIM);
	// var path = '<?php echo base_url();?>/assets/audio/';
	// var tingtong     = path + 'tingtong.mp3';
	// var sound_call = [new Audio(tingtong)];

	// function setel_bell(){
	// 	bell.play();
	// }


		function show_blast(){
			$.ajax({
				url: "blasting/show_list_blast",
				type: "GET",
				dataType: 'json',
				// contentType: "application/json",
				success: function(data)
				{
					console.log(data);				
					if(data !== null){
		                var event_data = '';
		                if(data.length > 0){                    
		                    var i = 1;
		                    var t = 0;
		                    $.each(data, function(index, value){
		                        /*console.log(value);*/
		                        event_data += '<tr>';
		                        event_data += '<td align="center">'+i+'</td>';
		                        event_data += '<td><b>'+value.penerima+'</b></td>';
		                        event_data += '<td><b>'+value.nama+'</b></td>';
		                        event_data += '<td>'+value.pesan+'</td>';
		                        event_data += '<td>'+value.dibuat+'</td></tr>';
		                        i++;
		                        // t = t+Number(value.jml);
		                    });
		                    event_data += '<tr><td colspan="4" align="center">TOTAL</td><td align="right">'+i-1+'</td></tr>';
		                }else{
		                    event_data = '<tr><td colspan="5">data kosong</td></tr>';
		                }  


		                document.getElementById('tblap1').innerHTML="";
		                $("#tblap1").append(event_data);
					}
				},
				error: function (jqXHR, textStatus, errorThrown)
				{
					console.log('Error get data from ajax');
				}
			});		
		}

	
	function my_ajax(){
		var zz = new Date();
		document.getElementById("jam").innerHTML = zz.toLocaleTimeString();

		var date = new Date();
		var hours = date.getHours();
		var minutes = date.getMinutes();
		var saiki = date.getDay();


		show_blast();

		if(saiki == 5){
			if(hours == 5 && minutes == 0 ) {
				panggil_blasting();
			}
			if(hours == 6 && minutes == 30 ) {
				panggil_reminder_pagi();
			}
			if(hours == 16 && minutes == 00 ) {
				panggil_reminder_sore();
			}
		}else if(saiki == 1 || saiki == 2 || saiki == 3 || saiki==4){
			if(hours == 5 && minutes == 0 ) {
				panggil_blasting();
			}			
			if(hours == 7 && minutes == 30 ) {
				panggil_reminder_pagi();
			}			
			if(hours == 16 && minutes == 30 ) {
				panggil_reminder_sore();
			}			
		}
	}
	
	function panggil_reminder_pagi(){
		$.ajax({
			url: "blasting/get_reminder_pagi",
			type: "GET",
			contentType: "application/json",
			dataType: "JSON",				
			success: function(data)
			{
				clearInterval(myVar);
			},
			error: function (jqXHR, textStatus, errorThrown)
			{
				console.log('Error get data from ajax');
			}
		});
	}

	function panggil_reminder_sore(){
		$.ajax({
			url: "blasting/get_reminder_sore",
			type: "GET",
			contentType: "application/json",
			dataType: "JSON",				
			success: function(data)
			{
				clearInterval(myVar);
			},
			error: function (jqXHR, textStatus, errorThrown)
			{
				console.log('Error get data from ajax');
			}
		});
	}	

	function panggil_blasting(){
		$.ajax({
			url: "blasting/get_blast",
			type: "GET",
			contentType: "application/json",
			dataType: "JSON",				
			success: function(data)
			{
				clearInterval(myVar);
			},
			error: function (jqXHR, textStatus, errorThrown)
			{
				console.log('Error get data from ajax');
			}
		});
	}
	

</script>
</html>