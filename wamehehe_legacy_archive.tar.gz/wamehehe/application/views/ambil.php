<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>WAME AMBIL</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=no">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="icon" href="./favicon.ico">
	<link href="<?php echo base_url('assets/css');?>/jquery-ui.css" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url('assets/css');?>/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url('assets/font-awesome-4.7.0/css');?>/font-awesome.min.css" rel="stylesheet" type="text/css">
	<script src="<?php echo base_url('assets/js');?>/jquery.js"></script>
	<script src="<?php echo base_url('assets/js');?>/jquery-ui.min.js"></script>
	<script src="<?php echo base_url('assets/js');?>/jquery-ui.js"></script>
	<script src="<?php echo base_url('assets/js');?>/bootstrap.js"></script>
	<link rel="stylesheet" href="<?php echo base_url('assets/css');?>/w3-4.css">
	<link rel="stylesheet" href="<?php echo base_url('assets/css');?>/w3-theme-green.css"> 
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster&effect=shadow-multiple">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Allerta+Stencil">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
</head>
<body>
	<div id="loadingDiv" style="display:none"></div>
	<div class="w3-cell-row"  style="padding-top:24px"></div>
	<div class="w3-container-fluid">
		<div class="w3-container" align="center">
			<div class="alert alert-danger">
			  <strong>Perhatian!</strong> Halaman ini masih dalam tahap pengembangan <a href="#" class="alert-link">Team IT PA Semarang</a>.
			</div>
		</div>
		<div class="w3-container" align="center">
			<div class="jumbotron">
				<img src="<?php echo base_url('assets/images/');?>gear_muter.gif" width="10%" alt="bg" class="rounded">
				<p><b>AMBIL DATA SIPP</b> </p>
				<p> Pastikan terkoneksi dengan internet </p>
				<p> Biarkan halaman ini tetap terbuka / silahkan minimize</p>
				<p id="jam"></p>
				<p>

				<audio id="bell">
				<source src="<?php echo base_url(); ?>assets/audio/ting.mp3" type="audio/mpeg">
				Your browser does not support the audio element.
				</audio>
			</div>
		</div>
		<br><br>
	</div>







</body>
<!--   Core JS Files   -->
<script src="<?php echo base_url(); ?>assets/js/jquery-3.1.0.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js" type="text/javascript"></script>

<script>
	const INTERVAL_KIRIM = 20000;
	
	var bell = document.getElementById("bell"); 
	var myVar = setInterval(my_ajax, INTERVAL_KIRIM);
	var path = '../assets/audio/';
	var tingtong     = path + 'ting.mp3';
	var sound_call = [new Audio(tingtong)];

	function setel_bell(){
		bell.play();
	}
	
	function salin_ke_outbox(data){
		data2 = data;
		if(data){
			if(data['tipe'] == 10){
				var xmlhttp = new XMLHttpRequest();   // new HttpRequest instance 
				xmlhttp.open("POST", "<?php echo base_url(); ?>ambil_c/simpan_outbox_notif_js");
				xmlhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");

				xmlhttp.send(JSON.stringify(
					{ 
						sidang_id: data['sidang_id'],
						perkara_id: data['perkara_id']
					}
				));	
			}else if(data['tipe'] == 11){
				// console.log(data['penerima']);
				var xmlhttp = new XMLHttpRequest();   // new HttpRequest instance 
				xmlhttp.open("POST", "<?php echo base_url(); ?>ambil_c/simpan_outbox_psp");
				xmlhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");

				xmlhttp.send(JSON.stringify(
					{ 
						telepon: data['telepon'], 
						perkara_id: data['perkara_id'],
						tipe: data['tipe'],
						pesan: data['pesan'],						
						nomor_perkara: data['nomor_perkara']  
					}
				));				
			}else{
				// console.log(data['penerima']);
				var xmlhttp = new XMLHttpRequest();   // new HttpRequest instance 
				xmlhttp.open("POST", "<?php echo base_url(); ?>ambil_c/simpan_outbox");
				xmlhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");

				xmlhttp.send(JSON.stringify(
					{ 
						telepon: data['telepon'], 
						perkara_id: data['perkara_id'],
						tipe: data['tipe'],
						pesan: data['pesan'],
						sidang_id: data['sidang_id'],
						nomor_perkara: data['nomor_perkara']  
					}
				));			
			}
		}

		clearTimeout(myVar);
		setel_bell();
		myVar = setInterval(my_ajax, INTERVAL_KIRIM);
	}

	
	function my_ajax(){
		var zz = new Date();
		document.getElementById("jam").innerHTML = zz.toLocaleTimeString();

		var hours = zz.getHours();
		var minutes = zz.getMinutes();
		if(hours >= 5 && hours <= 17 ) {
			$.ajax({
				url: "<?php echo base_url(); ?>ambil_c/ambil_data",
				type: "GET",
				dataType: "JSON",				
				success: function(data)
				{
					// console.log(data);				
					if(data !== null){
						clearInterval(myVar);
						salin_ke_outbox(data);
					}
				},
				error: function (jqXHR, textStatus, errorThrown)
				{
					console.log('Error get data from ajax');
				}
			});
		}
	}
	

	

</script>
</html>