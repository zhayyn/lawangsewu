<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Qr_c extends CI_Controller {
	function __construct() {
		parent::__construct();	
		$this->load->helper(array('form', 'url','captcha'));	
	}

	public function index() {
		$this->load->helper(array('url'));
		$this->load->view('test_qr');
	}

	function get_qr_bynoperk(){
		$numperk = $this->input->post('noperk');
		$perkid = $this->wame_model->get_id_by_nomor($numperk);
		
		if(strlen($perkid) > 0){
	        $this->load->library('ciqrcode'); //pemanggilan library QR CODE

	        $this->load->library('Encrypt'); 
			$x = new CI_Encrypt();
			$kunci   = "m4hk4m4h4gung"; 
			// $kunci   = "m4"; 
			$enoperk = $x->encode($perkid, $kunci);

	        $config['cacheable']    = true; //boolean, the default is true
	        $config['cachedir']             = './assets/'; //string, the default is application/cache/
	        $config['errorlog']             = './assets/'; //string, the default is application/logs/
	        $config['imagedir']             = './assets/qr/'; //direktori penyimpanan qr code
	        $config['quality']              = true; //boolean, the default is true
	        $config['size']                 = '1024'; //interger, the default is 1024
	        $config['black']                = array(224,255,255); // array, default is array(255,255,255)
	        $config['white']                = array(70,130,180); // array, default is array(0,0,0)
	        $this->ciqrcode->initialize($config);

	        $image_name='qr'.$perkid.'.png'; //buat name dari qr code sesuai dengan nim

	        $params['data'] = $enoperk; //data yang akan di jadikan QR CODE
	        $params['level'] = 'H'; //H=High
	        $params['size'] = 10;
	        $params['savename'] = FCPATH.$config['imagedir'].$image_name; //simpan image QR CODE ke folder assets/images/
	        $this->ciqrcode->generate($params); // fungsi untuk generate QR CODE

			$data_simpan = array(
				'perkara_id' => $perkid,
				'qr_data' => $enoperk,
				'qr_image' => $image_name					
			);
			$hasil = $this->wame_model->simpan_data_qr($data_simpan);

	        // $this->wame_model->simpan_mahasiswa($nim,$nama,$prodi,$image_name); //simpan ke database
	        // redirect('mahasiswa'); //redirect ke mahasiswa usai simpan data
			echo $image_name;

		}else{
			echo 'Gagal';
		}	
	}

	function get_qr_bynoperk2(){
		$numperk = $this->input->post('noperk');
		$perkid = $this->wame_model->get_id_by_nomor($numperk);
		
		if(strlen($perkid) > 0){
	        $this->load->library('ciqrcode'); //pemanggilan library QR CODE
	        // $kunci   = "m4hk4m4h4gung";

	        $this->load->library('Encrypt'); 
			$x = new CI_Encrypt();			 
			$kunci   = "m4"; 
			$enoperk = $x->encode($perkid, $kunci);

			// echo $enoperk;
			// exit;



	        $config['cacheable']    = true; //boolean, the default is true
	        $config['cachedir']             = './assets/'; //string, the default is application/cache/
	        $config['errorlog']             = './assets/'; //string, the default is application/logs/
	        $config['imagedir']             = './assets/qr/'; //direktori penyimpanan qr code
	        $config['quality']              = true; //boolean, the default is true
	        $config['black']                = array(0,0,0); // array, default is array(255,255,255)
	        $config['white']                = array(70,130,180); // array, default is array(0,0,0)
	        $this->ciqrcode->initialize($config);
	        $image_name='qr'.$perkid.'.png'; //buat name dari qr code sesuai dengan nim
	        $params['data'] = $enoperk; //data yang akan di jadikan QR CODE
	        $params['level'] = 'H'; //H=High
	        $params['size'] = 20;
	        $params['savename'] = FCPATH.$config['imagedir'].$image_name; //simpan image QR CODE ke folder assets/images/
	        $this->ciqrcode->generate($params); // fungsi untuk generate QR CODE

			$data_simpan = array(
				'perkara_id' => $perkid,
				'qr_data' => $enoperk,
				'qr_image' => $image_name					
			);
			$hasil = $this->wame_model->simpan_data_qr2($data_simpan);
			echo $enoperk;

		}else{
			echo 'Gagal';
		}	
	}	

	function genqr(){
		$numperk = $this->input->post('noperk');
		$st = $this->wame_model->get_id_by_nomor($numperk);
		if(strlen($st) > 0){
			echo $st;	
		}else{
			echo '';
		}		
	}

	function decqr(){
		// echo 'asuuuuuuuuuuuu';
		$str = $this->input->post('str');
        $this->load->library('Encrypt'); 
		$x = new CI_Encrypt();
		$kunci   = "m4hk4m4h4gung"; 
		$noperk = $x->decode($str, $kunci);		
		echo $noperk;
	}

    public function cetak_qr(){
        $perkid = $this->input->post('perkara_id');
        // $perkid = $vpid;

        $this->load->library('ciqrcode'); //pemanggilan library QR CODE

        $this->load->library('Encrypt'); 
		$x = new CI_Encrypt();
		$kunci   = "m4hk4m4h4gung"; 
		// $kunci   = "m4"; 
		$enoperk = $x->encode($perkid, $kunci);

        $config['cacheable']    = true; //boolean, the default is true
        $config['cachedir']             = './assets/'; //string, the default is application/cache/
        $config['errorlog']             = './assets/'; //string, the default is application/logs/
        $config['imagedir']             = './assets/qr/'; //direktori penyimpanan qr code
        $config['quality']              = true; //boolean, the default is true
        $config['size']                 = '1024'; //interger, the default is 1024
        $config['black']                = array(224,255,255); // array, default is array(255,255,255)
        $config['white']                = array(70,130,180); // array, default is array(0,0,0)
        $this->ciqrcode->initialize($config);

        $image_name='qr'.$perkid.'.png'; //buat name dari qr code sesuai dengan nim

        $params['data'] = $enoperk; //data yang akan di jadikan QR CODE
        $params['level'] = 'H'; //H=High
        $params['size'] = 10;
        $params['savename'] = FCPATH.$config['imagedir'].$image_name; //simpan image QR CODE ke folder assets/images/
        $this->ciqrcode->generate($params); // fungsi untuk generate QR CODE

		$data_simpan = array(
			'perkara_id' => $perkid,
			'qr_data' => $enoperk,
			'qr_image' => $image_name					
		);
		$hasil = $this->wame_model->simpan_data_qr($data_simpan);

        // $this->wame_model->simpan_mahasiswa($nim,$nama,$prodi,$image_name); //simpan ke database
        // redirect('mahasiswa'); //redirect ke mahasiswa usai simpan data
		echo $hasil;
    }	



}