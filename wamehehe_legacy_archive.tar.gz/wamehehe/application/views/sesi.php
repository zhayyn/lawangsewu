<?php header('Access-Control-Allow-Origin: *'); ?>

<div class="w3-container-fluid">
	<div class="w3-container" align="center">
		<div class="alert alert-danger">
		  <strong>Perhatian!</strong> Halaman ini masih dalam tahap pengembangan <a href="#" class="alert-link">Team IT PA Semarang</a>.
		</div>
		<div class="jumbotron">
			<img src="<?php echo base_url('assets/images/');?>bg_wame.png" width="80%" alt="bg" class="rounded">
			<h1>Selamat Datang,</h1>
			<p>Di Whatsapp API terintegrasi Pengadilan Agama Semarang</p>
		</div>		
	</div>
	<div class="w3-container" align="center">
				<a class="btn btn-sm w3-blue" href="<?php echo base_url('wame_c/main/home');?>"><i class="fa fa-home" aria-hidden="true"></i> Beranda</a>
				<!-- <a class="btn btn-sm w3-green" href="<?php echo base_url('wame_c/buat_sesi');?>"><i class="fa fa-sign-in" aria-hidden="true"></i> Buat Session Baru</a> -->
				<a class="btn btn-sm w3-green" onclick="buat_sesi()"><i class="fa fa-sign-in" aria-hidden="true"></i> Buat Session Baru</a>
				
	
		<br>
		<hr>
		<table width="100%">
			<thead>
				<tr>
					<th>No</th>
					<th>Session Data</th>
					<th>Aksi</th>
				</tr>				
			</thead>
			<tbody>
				<?php
					// $jx = 0; 
					$nn = 1;
					if($ses){
						foreach ($ses as $j) {			
				?>
					<tr>
						<td align="center"><?php echo $nn++;?></td>
						<td align="left"><b><?php echo $j->session_id.'</b><br>'.$j->url_api_hook.'<br>Created: '.$j->timestamp;?></td>
						<td align="right">
							<a class='btn btn-sm btn-primary' href="<?php echo base_url("wame_c/main/scan?id=$j->session_id");?>"><i class="fa fa-qrcode" aria-hidden="true"></i> ScarQR</a>
							<a class="btn btn-sm w3-orange" href="<?php echo base_url('wame_c/main/test');?>"><i class="fa fa-commenting" aria-hidden="true"></i> Test WA</a>
							<a class='btn btn-sm btn-danger' href="<?php echo base_url("wame_c/hapus_sesi?id=$j->session_id");?>"><i class="fa fa-sign-out" aria-hidden="true"></i> Hapus Sesi</a>
						</td>
					</tr>
				<?php 
							// $jx = $jx + $j->jml;						
						}
					}else{
						echo "<tr><td colspan='3'>KOSONG</td></tr>";
					}
				?>				
			</tbody>

		</table>



	</div>
	<div class="w3-container">
		<?php 
			if(isset($penerima)){
				echo $penerima."<br>";
			}
			if(isset($pesan)){
				echo $pesan;
			}
		?>

	</div>

<div id="modal_buat_sesi" class="modal">
    <div class="modal_dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1>Data Sesi Baru</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal_buat_sesi" onclick="document.getElementById('modal_buat_sesi').style.display='none'"></button>
            </div>
            <div class="modal-body">
                <form id="sesi_baru" method="POST" action="<?php echo base_url()?>wame_c/buat_sesi">
                    <input type="hidden" id="id_info" name="id_info">
                    <label for="url_api_hook">URL API HOOK<font color="red"><b>*</b></font></label>
					<input type="text" id="url_api_hook" name="url_api_hook" required>
					<hr>
					<input type="submit" value="Buat Sesi">
					<buton class="w3-button w3-blue" type="button" onclick="new_sesi()">Cek sesi baru</buton>
                </form>                
            </div>
            <div class="modal-footer">
                <table width="100%">
                    <tr>
                        <td width="33%"><button type="button" onclick="document.getElementById('modal_buat_sesi').style.display='none'" class="btn btn-primary"><i class="fa fa-times"> Cancel</i></button><td>
                        <td width="33%"></td>
                        <td width="33%">

                            <!-- <button type="button" onclick="buat_sesi_baru()" id="btn_dok" name="btn_dok" class="btn btn-success" value=""><i class="fa fa-floppy-o"> Simpan</i></button> -->
                        <td>    
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>


</div>
<script type="text/javascript">
	function buat_sesi(){
		document.getElementById('modal_buat_sesi').style.display='block';
	}

    function new_sesi(){
        // var myModal = new bootstrap.Modal(document.getElementById("exampleModal"), {});
        var url_hook = 'https://sinofita.pa-semarang.go.id/wame_c/masuk';

        $.ajax({
          type: "POST",
          url: "http://192.168.88.9:8088/session",
          dataType: 'json',
          data: {
                token : 'e1191a9cf5e26c2f8e68d45ca66a4908',
                url: url_hook
          },
          cache:false,               
          success: function(data){
            var event_data = '';
            var i = 1;
			alert(data.message);

          },
          error: function(data) {
            alert('error');
          }
        });         
    }

</script>