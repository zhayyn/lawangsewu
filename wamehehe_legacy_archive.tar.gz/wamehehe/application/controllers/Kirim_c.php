<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Kirim_c extends CI_Controller {
	function __construct() {
		parent::__construct();	
		$this->load->helper(array('form', 'url','captcha'));	

		define('URL_API_SESSION','http://192.168.88.9:8088/session');
		define('URL_API_KIRIM', 'http://192.168.88.9:8088/send-message');
		define('URL_API_KIRIM_MEDIA', 'http://192.168.88.9:8088/send-media');
		define('URL_TERIMA', 'http://192.168.88.10/wame/wame_c/masuk');		
		define('ACTIVE_TOKEN', 'e1191a9cf5e26c2f8e68d45ca66a4908');		
	}

	public function index() {
		$this->load->helper(array('url'));
		$data['judul'] = 'Tukang Kirim Pesanan';
		$this->load->view("kirim", $data);
	}

	public function cek_kirim()
	{
		$p = $this->wame_model->get_pesan_keluar();
		$pesan_keluar = $p->row();
		// echo json_encode($pesan_keluar);

		//SELEKSI JIKA ITU BLASTING PAGI, TAMBAHKAN LINK ATK REQUEST
		if($pesan_keluar->tipe_pesan == 1 and $pesan_keluar->tipe == 7){
			$pesan_atk = '';

			$pid = $pesan_keluar->id;
			
			$peg_id = $this->wame_model->get_blast_atk_link($pid);
			$msg_atk = array(
					'idpeg' => $peg_id,
					'tgl' => date('Y-m-d')
				);
			$msg_atk_str = base64_encode(json_encode($msg_atk));
			$msg_link = 'https://sinofita.pa-semarang.go.id/atk/permohonan?a='.$msg_atk_str;
			// $msg_link = 'INI TEST LINK REQ ATK = '.$msg_atk_str;

			$pesan_atk = str_replace("#link#", $msg_link, $pesan_keluar->pesan);
		  
			$datap = array(
					'id' => $pid,
					'penerima' => $pesan_keluar->penerima,
					'pesan' => $pesan_atk,
					'fname' => $pesan_keluar->fname,
					'tipe_pesan' => $pesan_keluar->tipe_pesan,
					'tipe' => $pesan_keluar->tipe
				);
			echo json_encode($datap);
		}else{
			echo json_encode($pesan_keluar);			
		}
	}	

	public function kirim_wa_test(){
		$url2 = URL_API_KIRIM;
		$id = $this->wame_model->get_last_id_wapi();

		$penerima = $this->input->post('penerima');
		$pesan = $this->input->post('pesan');
		$kirim2 = array(
			'token' => ACTIVE_TOKEN,
			'id'     => $id,
		   	'number'	=> $penerima,
		   	'message'=> $pesan
		);
		$options2 = array(
		  'http' => array(
		    'method'  => 'POST',
		    'content' => json_encode( $kirim2 ),
		    'header'=>  "Content-Type: application/json\r\n" .
		                "Accept: application/json\r\n"
		    )
		);
		$context2  = stream_context_create( $options2 );
		$result2 = file_get_contents( $url2, false, $context2 );
		$response = json_decode( $result2 );	

		if($response->success == TRUE){
			$data = array(
				"hasil_kode" => $response->success,
				"hasil_pesan" => $response->message
			);	
		}
		$this->main('test');
	}	

	public function kirim_media(){
		$data = file_get_contents("php://input");
		$row = json_decode($data,true);
		//xmlhttp.send(JSON.stringify({ outbox_id: data['id'], penerima: data['penerima'], pesan: data['pesan'] }));

		// if(strlen($row[outbox_id]) > 0){
			$id_outbox = $row['outbox_id']; 	
		// }else{
		// 	$id_outbox = 0; 
		// }
		
		// $tujuan = '082134390000'; // $row['penerima'];
		$tujuan = $row['penerima'];
		$caption = $row['pesan'];
		$fname = $row['fname'];

		$url2 = URL_API_KIRIM_MEDIA;
		$id = $this->wame_model->get_last_id_wapi();		

		$kirim2 = array(
			'token' => ACTIVE_TOKEN,
			'id'     => $id,
		   	'number'	=> $tujuan,
		   	'caption'=> $caption,
		   	'file'=> $fname
		);

		$options2 = array(
		  'http' => array(
		    'method'  => 'POST',
		    'content' => json_encode( $kirim2 ),
		    'header'=>  "Content-Type: application/json\r\n" .
		                "Accept: application/json\r\n"
		    )
		);
		$context2  = stream_context_create( $options2 );
		$result2 = file_get_contents( $url2, false, $context2 );
		$response = json_decode( $result2 );

		if($id_outbox > 0){
			if($response->success == TRUE){
				$data_resp = array(
					"hasil_kode" => $response->success,
					"hasil_pesan" => $response->message
				);	

				$dt['stat'] = '1';
				$dt['terkirim'] = date("Y-m-d H:i:s");
				$dt['hasil'] = $response->message;
				$where = array('id' => $id_outbox);
				$this->wame_model->update_data($where,'outbox',$dt);
			} else {
				$data_resp = array(
					"hasil_kode" => '0',
					"hasil_pesan" => 'GAGAL KIRIM'
				);	
				$dt['stat'] = '2';
				$dt['hasil'] = $response->message;
				$where = array('id' => $id_outbox);
				$this->wame_model->update_data($where,'outbox',$dt);
			}
		}
		return $response->success;
	}

	public function kirim_pesan(){

		$data = file_get_contents("php://input");
		$row = json_decode($data,true);
		//xmlhttp.send(JSON.stringify({ outbox_id: data['id'], penerima: data['penerima'], pesan: data['pesan'] }));

		$id_outbox = $row['outbox_id']; 
		$tujuan = $row['penerima'];
		$pesan = $row['pesan'];

		$url2 = URL_API_KIRIM;
		$id = $this->wame_model->get_last_id_wapi();		

		$kirim2 = array(
			'token' => ACTIVE_TOKEN,
			'id'     => $id,
		   	'number'	=> $tujuan,
		   	'message'=> $pesan
		);

		$options2 = array(
		  'http' => array(
		    'method'  => 'POST',
		    'content' => json_encode( $kirim2 ),
		    'header'=>  "Content-Type: application/json\r\n" .
		                "Accept: application/json\r\n"
		    )
		);
		$context2  = stream_context_create( $options2 );
		$result2 = file_get_contents( $url2, false, $context2 );
		$response = json_decode( $result2 );	

		if($response->success == TRUE){
			$data_resp = array(
				"hasil_kode" => $response->success,
				"hasil_pesan" => $response->message
			);	

			$dt['stat'] = '1';
			$dt['terkirim'] = date("Y-m-d H:i:s");
			$dt['hasil'] = $response->message;
			$where = array('id' => $id_outbox);
			$this->wame_model->update_data($where,'outbox',$dt);
			// echo 'Kirim SUKSES';
		} else {
			$data_resp = array(
				"hasil_kode" => '0',
				"hasil_pesan" => 'GAGAL KIRIM'
			);	
			$dt['stat'] = '2';
			$dt['hasil'] = $response->message;
			$where = array('id' => $id_outbox);
			$this->wame_model->update_data($where,'outbox',$dt);
			// echo 'Kirim GAGAL';
		}
		echo $response->success;
	}	

}