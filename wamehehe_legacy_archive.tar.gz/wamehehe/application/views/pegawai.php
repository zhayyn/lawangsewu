<html>
<head>
	<title>PEGAWAI</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=no">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <link rel="icon" href="./favicon.ico">
  <link href="<?php echo base_url('assets/css');?>/jquery-ui.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url('assets/css');?>/bootstrap.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url('assets/font-awesome-4.7.0/css');?>/font-awesome.min.css" rel="stylesheet" type="text/css">
  <script src="<?php echo base_url('assets/js');?>/jquery.js"></script>
  <script src="<?php echo base_url('assets/js');?>/jquery-ui.min.js"></script>
  <script src="<?php echo base_url('assets/js');?>/jquery-ui.js"></script>
  <script src="<?php echo base_url('assets/js');?>/bootstrap.js"></script>
  <link rel="stylesheet" href="<?php echo base_url('assets/css');?>/w3-4.css">
  <link rel="stylesheet" href="<?php echo base_url('assets/css');?>/w3-theme-green.css"> 
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster&effect=shadow-multiple">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Allerta+Stencil">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">

  <style type="text/css">
    body  {
      /*background-image: url("assets/images/steel.gif");*/
      /*background-color: #cccccc;*/
      font-family: Roboto, sans-serif;
    }  
    h1, h2, h3, h4, h5, h6  {
      font-family: Roboto, sans-serif;
    }  
    .w3-lobster {
      font-family: "Lobster", Sans-serif;  
    }
    .w3-allerta {
      /*font-family: "Allerta Stencil", Sans-serif;*/
      font-family: Roboto, sans-serif;
    }  
    .w3-sofia {
      font-family: Sofia, sans-serif;
    }   


  /* Full-width input fields */
  textarea, select, input[type=date], input[type=text], input[type=email], input[type=password] {
    width: 100%;
    padding: 8px 12px;
    margin: 4px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
  }

  /* Set a style for all buttons */
  button {
    background-color: #04AA6D;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
  }

  button:hover {
    opacity: 0.8;
  }

  /* Extra styles for the cancel button */
  .cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
  }

  /* Center the image and position the close button */
  .imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
    position: relative;
  }

  img.avatar {
    width: 40%;
    border-radius: 50%;
  }

  .container {
    padding: 8px;
  }

  span.psw {
    float: right;
    padding-top: 16px;
  }

  /* The Modal (background) */
  .modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    padding-top: 0;
  }

    .modal-backdrop {
       position: relative;
       z-index: -1
    }

  /* Modal Content/Box */
  .modal-content {
    background-color: #fefefe;
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    border: 1px solid #888;
    width: 80%; /* Could be more or less, depending on screen size */
  }

  /* The Close Button (x) */
  .close {
    position: absolute;
    right: 25px;
    top: 0;
    color: #000;
    font-size: 35px;
    font-weight: bold;
  }

  .close:hover,
  .close:focus {
    color: red;
    cursor: pointer;
  }

  /* Add Zoom Animation */
  .animate {
    -webkit-animation: animatezoom 0.6s;
    animation: animatezoom 0.6s
  }

  @-webkit-keyframes animatezoom {
    from {-webkit-transform: scale(0)} 
    to {-webkit-transform: scale(1)}
  }
    
  @keyframes animatezoom {
    from {transform: scale(0)} 
    to {transform: scale(1)}
  }

  /* Change styles for span and cancel button on extra small screens */
  @media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
  }

    .accordion {
      background-color: #eee;
      color: #444;
      cursor: pointer;
      padding: 12px;
      width: 100%;
      border: none;
      text-align: left;
      outline: none;
      font-size: 15px;
      transition: 0.4s;
    }
    
    .active, .accordion:hover {
      background-color: #ccc;
    }
    
    .accordion:after {
      content: '\002B';
      color: #777;
      font-weight: bold;
      float: right;
      margin-left: 5px;
    }
    
    .active:after {
      content: "\2212";
    }
    
    .panel {
      padding: 0 8px;
      background-color: white;
      max-height: 0;
      overflow: hidden;
      transition: max-height 0.2s ease-out;
    }

</style> 
</head>
<body>
    <div class="w3-top w3-row w3-card-2 w3-padding w3-center w3-white">
      <div class="w3-col" style="width:30px">
        <a class="w3-btn w3-tiny w3-blue w3-round-large" href="<?php echo base_url()?>/wame_c/main/home"><i class="fa fa-home"></i> Beranda</a>
      </div>
      <div class="w3-rest w3-cell-right">
        <span style="font-size: 18px"><i class="fa fa-user" aria-hidden="true"></i> PEGAWAI</span>
      </div>
    </div>

    <div class="w3-container" id="utama" style="padding-top: 60px; display: block;">
      <div class="w3-container w3-card">      
        <div class="w3-panel w3-border w3-leftbar w3-green w3-round-large">
          <p>Daftar Pegawai</p>
        </div>
        <table class="w3-table w3-border">
          <thead>
            <th width="5%">No</th>
            <th>Nama</th>
            <th width="10%">NOWA</th>
            <th width="5%">Blast</th>
            <th width="5%">ABS1</th>
            <th width="5%">ABS2</th>            
            <th width="5%">Aktif</th>
          </thead>
          <tbody>
            <?php
              $num = 1;
              if($data_pegawai){
                foreach ($data_pegawai as $h){
                  echo '<tr>';
                  echo '<td align="center">'.$num.'</td>';
                  echo '<td><b>'.$h->nama.'</b><br><i>'.$h->jab.'</i></td>';
                  echo '<td><b>'.$h->telp.'</b></td>';

                  echo '<td>';
                  if($h->blast == 1){
                    echo '<input class="w3-check w3-round w3-green" type="checkbox" checked>';
                  }else{
                    echo '<input class="w3-check w3-round w3-red" type="checkbox">';
                  }                                    
                  echo '</td>';

                  echo '<td>';
                  if($h->abs_reminder_pagi == 1){
                    echo '<input class="w3-check w3-round w3-green" type="checkbox" checked>';
                  }else{
                    echo '<input class="w3-check w3-round w3-red" type="checkbox">';
                  }                                    
                  echo '</td>';

                  echo '<td>';
                  if($h->abs_reminder_sore == 1){
                    echo '<input class="w3-check w3-round w3-green" type="checkbox" onclick="update_pegawai('.$h->id.', 3, 0)" checked>';
                  }else{
                    echo '<input class="w3-check w3-round w3-red" type="checkbox" onclick="update_pegawai('.$h->id.', 3, 1)">';
                  }                                    
                  echo '</td>';                  
                  
                  echo '<td>';
                  if($h->aktif == 1){
                    echo '<input class="w3-check w3-round w3-green" type="checkbox" onclick="update_pegawai('.$h->id.',4,0)" checked>';
                  }else{
                    echo '<input class="w3-check w3-round w3-red" type="checkbox" onclick="update_pegawai('.$h->id.',4,1)">';
                  }
                  echo '</td>';

                  echo '</tr>';                  
                  $num++;
                }
              }
            ?>            
          </tbody>
        </table>

      </div>

    </div>

    <div id="req_ok" class="w3-container w3-center" style="padding-top: 60px; display: none;">
        <div class="w3-container w3-card">
            <img src="<?php echo base_url()?>/assets/images/req_ok.png" style="width: 64px;">
            <p><strong>Permintaan Terkirim</strong><br>Silahkan Anda sabar menunggu hingga permintaan Anda terpenuhi<br>Terimakasih</p>
        </div>
    </div>
    
    <div id="req_fail" class="w3-container w3-center" style="padding-top: 60px; display: none;">
        <div class="w3-container w3-card">
            <img src="<?php echo base_url()?>/assets/images/req_fail.png" style="width: 64px;">
            <p><strong>Permintaan Gagal</strong><br>Pastikan Anda terkoneksi dengan internet<br>Silahkan Coba Lagi</p>
        </div>
    </div>    
</body> 

<script src="<?php echo base_url()?>/assets/plugin/jquery/jquery.js"></script>
<script src="<?php echo base_url()?>/assets/plugin/jquery-ui/jquery-ui.min.js"></script>
<script src="<?php echo base_url()?>/assets/plugin/jquery-ui/datepicker-id.js"></script>

<script type="text/javascript">

  function update_pegawai(xid, xtipe, nilai){
    var xhr = new XMLHttpRequest();
    var url='<?php echo base_url(); ?>pegawai/update_pegawai';
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
    xhr.onreadystatechange = function(){
        if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){
          // alert(xhr.responseText);
          location.reload();
        }
    };
    xhr.send(JSON.stringify({
        pid: xid,
        tipe: xtipe,
        val: nilai
    }));
  }

</script>
</html>