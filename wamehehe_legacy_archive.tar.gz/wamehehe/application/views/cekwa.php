<?php
	echo "<b>".$hasil_kode."</b><br>".$hasil_pesan;

?>