<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Wame_c extends CI_Controller {


	function __construct() {
		parent::__construct();	
		$this->load->helper(array('form', 'url','captcha'));	
		$this->load->library('email');

		define('URL_API_SESSION','http://192.168.88.9:8088/session');
		define('URL_API_KIRIM', 'http://192.168.88.9:8088/send-message');
		define('URL_TERIMA', 'http://192.168.88.10/wame/wame_c/masuk');
		define('URL_TERIMA2', 'https://sinofita.pa-semarang.go.id/wame_c/masuk');		
		define('ACTIVE_TOKEN', 'e1191a9cf5e26c2f8e68d45ca66a4908');

		// define('URL_API_SESSION','https://sinofita.pa-semarang.go.id/session');
		// define('URL_API_KIRIM', 'https://sinofita.pa-semarang.go.id/send-message');
		// define('URL_TERIMA', 'https://sinofita.pa-semarang.go.id/wame/wame_c/masuk');		
		// define('ACTIVE_TOKEN', 'e1191a9cf5e26c2f8e68d45ca66a4908');		

		if($this->session->userdata('user_id')==NULL OR $this->session->userdata('user_id')==""){
			// $this->login();
			// $this->main('login');
		}		
	}

	function page($string){
		if ($string == 'about'){
			$judul	 	= 'Tentang Aplikasi';
			$main 		= $this->html_about($judul);
		}
		else if($string == 'login'){
			$judul		= 'Masuk Aplikasi';
			$main 		= $this->html_login($judul);
		}	
		else if ($string == 'home'){
			$judul 		= 'Home';
			$main 		= $this->html_home($judul);
		}
		else if ($string == 'konsul'){
			$judul 		= 'Konsultasi';
			$main 		= $this->html_konsul($judul);
		}		
		else if ($string == 'scan'){
			$judul 		= 'Scan WA QR';
			$main 		= $this->html_scan($judul);
		}
		else if ($string == 'sesi'){
			$judul 		= 'Manage Sessions';
			$main 		= $this->html_sesi($judul);
		}
		else if ($string == 'test'){
			$judul 		= 'Testing WA';
			$main 		= $this->html_test($judul);
		}
		else if ($string == 'gagal'){
			$judul 		= 'Notif Gagal Kirim';
			$main 		= $this->html_gagal($judul);			
		}else{
			$judul 		= 'Home';
			$main 		= NULL;
		}			
		return array(
			"judul" => $judul,
			"main" => $main
		);
	}

	public function index() {
		$this->load->helper(array('captcha', 'url'));
		if($this->session->userdata('user_id')==NULL OR $this->session->userdata('user_id')==""){
			$this->main('login');
		}
	}

	public function main($v='') {
		$main = $this->page($v);
		$data = array(
			"modul_menu" => $this->html_menu(),
			"modul_index" => $main['main'],
			"modul_footer" => $this->wame_model->modul_main()			
		);
		$this->load->view('index',$data);
	}

	function login($err=FALSE){
		if($err==FALSE){
			$err = FALSE;}
		else{
			$err =TRUE;}			
		if($this->session->userdata('group_id')){
			redirect('');}
		else{
			$this->doLogin($err);}}

	function doLogin($err=FALSE){
		$data['error'] =$err;
		// $this->load->vars($data);
		$this->load->view('login');
		// redirect('');
	}

	public function html_konsul($judul){
		$data['judul'] = 'Halaman Konsultasi';

		return $this->load->view('konsul', $data, TRUE);
	}

	public function html_login($judul){
		$data['judul'] = 'Halaman Login';
		// $data['kunci'] = $this->encrypt->encode('js','814sA');
		return $this->load->view('login', $data, TRUE);
	}	

	function validation_credential(){
		$this->form_validation->set_rules('username','username','trim|required');
		$this->form_validation->set_rules('password','password','trim|required');
		if($this->form_validation->run()===TRUE){

			$data = array(
					$this->input->post('username'),
					$this->input->post('password')
				// 'bakri', 'js'
				// $this->encrypt->encode($this->input->post('username'),'814sA'),
				// $this->encrypt->encode($this->input->post('password'),'814sA')
			);
			
			$this->session->set_flashdata('data',$data);
			redirect('wame_c/credential');}
		else{
			redirect('wame_c?error=gagal');
		}
	}
	
	function credential(){
		// $this->load->model('validation_user');
		$validation_user = $this->wame_model->validate();
		if($validation_user[0] == TRUE){
			$data = array($validation_user[2]);			
			$this->session->set_flashdata('data',$data);
			redirect('wame_c/main/home');			

			// echo $validation_user[1];
			// if($validation_user[2] == '1'){
			// 	redirect('wame_c/main/home');
			// }else if($validation_user[2] == '2'){
			// 	redirect('pengaduan/index');
			// }else if($validation_user[2] == '3'){
			// 	redirect('konsultasi/index');
			// }else{
			// 	$this->session->sess_destroy();
			// 	redirect("wame_c?error=$validation_user[1]");				
			// }
		}else{
			$this->session->sess_destroy();
			redirect("wame_c?error=$validation_user[1]");
		}
	}
	
	public function logout(){
		$this->session->sess_destroy();
		redirect('');
	}	

	public function captcha_setting(){
		$values = array(
			'word' => '',
			'word_length' => 4,
			'img_path' => './images/',
			'img_url' => base_url() .'images/',
			'font_path' => base_url() . 'system/fonts/texb.ttf',
			'img_width' => '150',
			'img_height' => 50,
			'expiration' => 3600
		);
		$data = create_captcha($values);
		$_SESSION['captchaWord'] = $data['word'];
	}

	public function captcha_refresh(){
		$values = array(
			'word' => '',
			'word_length' => 4,
			'img_path' => './images/',
			'img_url' => base_url() .'images/',
			'font_path' => base_url() . 'system/fonts/texb.ttf',
			'img_width' => '150',
			'img_height' => 50,
			'expiration' => 3600
		);
		$data = create_captcha($values);
		$_SESSION['captchaWord'] = $data['word'];
		echo $data['image'];	
	}	

	public function html_home($judul) {
		// $dt = $this->session->flashdata('data');
		$data['lvluser'] = $this->session->userdata('jenis_user');
		$data['bagian'] = $this->session->userdata('bagian');
		$data['judul'] = 'Halaman Utama WAME';
		$data['stat_kosuladu'] = $this->wame_model->get_stat_konsuladu();
		$data['tot_unique_num'] = $this->wame_model->get_tot_unique_num();
		$data['stat_interaktif'] = $this->wame_model->get_stat_interaktif();
		$data['stat_notif'] = $this->wame_model->get_stat_notif();
		// $this->load->view("_menu", $data);
		// $this->load->view("home", $data, TRUE);
		return $this->load->view("home", $data, TRUE);
	}
	// public function html_login($judul){
	// 	$data['judul'] = 'Halaman Login';
	// 	return $this->load->view('login', $data, TRUE);
	// }

	public function html_menu() {
		$data['lvluser'] = $this->session->userdata('jenis_user');
		// $data = array(
		// 	"session_data" 	=> $this->session->userdata()		
		// );
		return $this->load->view("_menu",$data,TRUE);
		// return $this->load->view("main_menu",$data,TRUE);
	}

	public function simpan_ses($key, $val){
		$this->session->set_userdata($key, $val);
	}

	public function scan_sesi(){
		$id = $this->input->post('id');
		$data['qr'] = '<iframe src="https://wa-api.pa-semarang.go.id/qr?session='.$id.'" height="450" width="380" style="border:none;" title="Scan QR WA"></iframe>';
		$data['id'] = $id;
		return $this->load->view("scan", $data, TRUE);
	}

	public function html_scan($judul) {
		$data['judul'] = 'Halaman SCAN';
		$id = $this->wame_model->get_last_id_wapi();
		$data['qr'] = '<iframe src="https://wa-api.pa-semarang.go.id/qr?session='.$id.'" height="450" width="380" style="border:none;" title="Scan QR WA"></iframe>';
		$data['id'] = $id;
		return $this->load->view("scan", $data, TRUE);
	}	

	public function buat_sesi(){
		$url_hook_new = $this->input->post('url_api_hook');
		// define('URL_TERIMA', 'http://192.168.88.10/wame/wame_c/masuk');
		// $url_terima = 'http://192.168.88.10/wame/wame_c/masuk';	
		$url_terima = URL_TERIMA2;	

		$url = URL_API_SESSION;
		$kirim = array(
		  'token'      => ACTIVE_TOKEN,
		  'url' => $url_terima
		  // 'url' => $url_hook_new
		  // 'url'      => URL_TERIMA
		);
		$options = array(
		  'http' => array(
		    'method'  => 'POST',
		    'content' => json_encode( $kirim ),
		    'header'=>  "Content-Type: application/json\r\n" .
		                "Accept: application/json\r\n"
		    )
		);
		$context  = stream_context_create( $options );
		$result = file_get_contents( $url, false, $context );
		$response = json_decode( $result );	
		$this->session->set_flashdata('info', $response->message);
		if($response->success == TRUE || $response->success == 1 || $response->success == 'true'){
			//tampilkan iframe barcode
			$data_simpan = array(
				"token" => ACTIVE_TOKEN,
				"key" => $response->id
			);	
			// $this->wame_model->		
			$this->wame_model->insert_tabel('sessions',$data_simpan,TRUE);	
		}else{
			$data_simpan = array(
				"hasil" => 0,
				"pesan" => $response->message
			);	
			echo json_encode($data_simpan);
		}
		$this->main('scan');
	}

	public function hapus_sesi(){

		$id	= $this->input->get('id');

		if(isset($id)){
			$url = URL_API_SESSION;
			$kirim = array(
			  'token'      => ACTIVE_TOKEN,
			  'id'      => $id
			);
			$options = array(
			  'http' => array(
			    'method'  => 'DELETE',
			    'content' => json_encode( $kirim ),
			    'header'=>  "Content-Type: application/json\r\n" .
			                "Accept: application/json\r\n"
			    )
			);
			$context  = stream_context_create( $options );
			$result = file_get_contents( $url, false, $context );
			$response = json_decode( $result );	

			$data['pesan'] = '';
			if($response){
				if($response->success == TRUE){
					//hapus session tabel lokal
					$data_delete = array(
						"token" => ACTIVE_TOKEN,
						"key" => $id
					);			
					$this->wame_model->delete_tabel('sessions',$data_delete,TRUE);
					$data['pesan'] = $response->message;
				}			
			}
		}		
		$this->main('sesi');
	}	

	public function html_sesi($judul) {
		$data['judul'] = 'Halaman Sessions';
		$id = $this->wame_model->get_last_id_wapi();
		$ses = $this->wame_model->get_all_session();
		$data['id'] = $id;
		$data['ses'] = $ses;
		return $this->load->view("sesi", $data, TRUE);
	}

	public function html_test($judul) {
		$data['judul'] = 'Halaman TEST';
		$id = $this->wame_model->get_last_id_wapi();		
		$data['id'] = $id;
		return $this->load->view("test_wa", $data, TRUE);
	}	

	public function html_gagal($judul) {
		$data['judul'] = 'Daftar Notif Gagal';
		$dt = $this->wame_model->get_notif_gagal_kirim();
		$data['stat_proc_kirim'] = $this->wame_model->get_stat_proc_kirim();
		$data['daftar_notif_gagal'] = $dt;
		return $this->load->view("notif_gagal", $data, TRUE);
	}	

	public function masuk_ptsp(){
		if($_SERVER['REQUEST_METHOD'] == "POST"){
			$data = file_get_contents("php://input");
			$row = json_decode($data,true);			
			$pengirim =str_replace('@c.us','', $row['data']['number']); 
			$pesan = trim($row['data']['message']);
			
			if(strlen($pengirim) <= 16){
				$data_simpan = array(
					'pengirim' => str_replace('@c.us','', $pengirim),
					'pesan' => $pesan,
					'stat' => 0,
					'ket' => 'CHAT_PTSP',
					'tipe' => 0
				);
				$this->wame_model->insert_tabel('inbox_ptsp',$data_simpan,TRUE);
			}
			return json_encode(array('Status' => 200, 'Message' => "Success"));
		}else{
			return "Access Denied";
		}
	}	 

	public function masuk(){
		if($_SERVER['REQUEST_METHOD'] == "POST"){
			$data = file_get_contents("php://input");
			$row = json_decode($data,true);			
			$pengirim =str_replace('@c.us','', $row['data']['number']); 
			$pesan = trim($row['data']['message']);
			
			// if(strlen($pengirim) <= 16){
			if($pengirim){
				$str = '';
				$str = $this->proses_message($pengirim, $pesan);

				if(strlen($str) > 5){
					$hasil = $this->kirim_pesan($pengirim, $str);
					$hasil_code = $hasil['hasil_kode'];
				}

				$statp = 0;
				if(
					$pesan === '1' ||
					$pesan === '2' ||
					$pesan === '3' ||
					$pesan === '4' ||
					$pesan === '5' ||
					$pesan === '6' ||
					$pesan === '7' ||
					$pesan === '8' ||					
					$pesan === '9' ||
					$pesan === '10'||
					$pesan === '11'||
					$pesan === '12'||
					$pesan === '13'||
					$pesan === '14'||
					$pesan === '15'||
					$pesan === '16'
				){ $statp = 1;}else{$statp = 0;}

				$data_simpan = array(
					'pengirim' => str_replace('@c.us','', $pengirim),
					'pesan' => $pesan,
					'stat' => $hasil_code,
					'ket' => $str,
					'tipe' => $statp
				);
				$this->wame_model->insert_tabel('inbox',$data_simpan,TRUE);
			}
			return json_encode(array('Status' => 200, 'Message' => "Success"));
			// echo 200;
		}else{
			// echo 400; //
			return "Access Denied";
		}
	} 

	public function proses_message($pengirim, $msg){
		$idwa = $this->wame_model->get_last_id_wapi();
		$rw = array(
				"1","2","3","4","5","6",
				"7","8","9","10","11","12","13","14", "15", "16"
			);
		$rwx = array(
				"5","7","8","9","10","11","12","13"
			);	
		$default_balas = $this->wame_model->get_default_balas();
		$prompt = '';
		$hasil = 'Selamat siang ini dari PA Semarang';
		$msg = strtolower(trim($msg));

		//cek dulu, masuk dalam RW gak
		if (in_array($msg, $rw)){
			//klo masuk, cek dulu, jawaban langsung ato butuh inputan?
			if(
				(strcmp($msg, '1') == 0) or 
				(strcmp($msg, '2') == 0) or 
				(strcmp($msg, '3') == 0) or 
				(strcmp($msg, '4') == 0) or 
				// (strcmp($msg, '5') == 0) or 
				(strcmp($msg, '6') == 0) or
				(strcmp($msg, '14') == 0) or 
				(strcmp($msg, '15') == 0) or
				(strcmp($msg, '16') == 0)
			){ //jawaban langsung
				$balikan = $this->wame_model->get_balasan2($msg, NULL);
				if($balikan['hasil'] == 1){
					$hasil = $balikan['balasan'];
				}else{
					$hasil = 'Data tidak ditemukan';
				}				

			}else{
				//bukan jawaban langsung TAPI
				//cek dulu ada di qtemp gak, klo kosong lempar prompt
				$qt = $this->wame_model->cek_qtemp($pengirim, $idwa);
				if ($qt['hasil'] == 0){
					if($msg == '5'){						
						$prompt = $this->wame_model->get_daftar_prompt();
					}else if($msg == '12'){
						$prompt = 'Silahkan ketik aduan Anda. Pastikan informasi yang Anda diberikan sedapat mungkin memenuhi unsur *Apa*, *Dimana*, *Kapan*, *Siapa* dan *Bagaimana*:';
					}else if($msg == '13'){
						$prompt = 'Silahkan ketik permasalahan Anda. Pastikan informasi yang Anda berikan benar dan jelas';						
					}else{
						$prompt = '*Masukkan Nomor Perkara*. Contoh: _99999/pdt.g/2024_';
					}

					$data_simpan = array(
						'pengirim' => str_replace('@c.us','', $pengirim),
						'pesan' => $msg,
						'prompt' => $prompt,
						'id_wapi' => $idwa		
					);
					$this->wame_model->insert_tabel('qtemp',$data_simpan,TRUE);
					$hasil = $prompt;
				}else{
					//klo ternyata di qtemp sudah ada?
					//clear qtemp;
					$data_del = array(
						'pengirim' => $pengirim,
						'id_wapi' => $idwa		
					);					
					$this->wame_model->delete_tabel('qtemp',$data_del);
					//tampilkan default format
					$hasil = $default_balas;
				}
			}
		}
		else{
			//bukan RW, mungkin itu inputan?
			//cek qtemp sebelume ada gak
			$qt = $this->wame_model->cek_qtemp($pengirim, $idwa);
			//jika memang ada ketemu di qtemp
			if ($qt['hasil'] == 1){
				$perintah = $qt['pesan'];
				$inputan = $msg;

				//PROSES 2nd
				if(in_array($perintah, $rwx) && strlen($msg) == 0){
					if($perintah == '5'){
						$hasil = 'Pastikan ada ketik jenis perkara'.$default_balas;
					}else if($perintah == '12'){
						$hasil = 'Pastikan ada ketik isi Aduan '.$default_balas;
					}else if($perintah == '13'){
						$hasil = 'Pastikan ada ketik permasalahan Anda dengan jelas '.$default_balas;					
					}else{
						$hasil = 'Pastikan Anda telah mengisi inputan *Nomor Perkara* \n'.$default_balas;	
					}					
				} else{
					if($perintah == '5'){
						$hasil = $this->wame_model->get_daftar_item($msg);
					} else{
						$balikan = $this->wame_model->get_balasan2($perintah, $inputan);
						if($balikan['hasil'] == 1){
							// $ext = $this->db->query("SELECT balasan FROM `format` WHERE perintah = '".$perintah."' LIMIT 1");
							// $ext_str = $ext->row();
							// $balasan = $str->pesan.'\n'.$ext_str;
							$ext_str = $this->wame_model->get_extra_text($perintah);
							if ($perintah == '12'){
								//simpan pesan ke table aduan
								$data_adu = array(
									'pengirim' => str_replace('@c.us','', $pengirim),
									'pesan' => $msg,
									'stat' => 0		
								);
								$this->wame_model->insert_tabel('aduan',$data_adu,TRUE);
								//NOTIFIKASI USER
								$this->wame_model->notif_admin_pengaduan(str_replace('@c.us','', $pengirim), $msg);
								$hasil = $balikan['balasan'];

							}else if($perintah == 13){
								//simpan pesan ke table konsultasi
								$data_konsul = array(
									'pengirim' => str_replace('@c.us','', $pengirim),
									'pesan' => $msg,
									'stat' => 0		
								);
								$this->wame_model->insert_tabel('konsultasi',$data_konsul,TRUE);
								//NOTIF USER ADMIN KONSULTASI
								$this->wame_model->notif_admin_konsultasi(str_replace('@c.us','', $pengirim), $msg);
								$hasil = $balikan['balasan'];								

							} else{
								$hasil = $balikan['balasan'].' '.$ext_str;
							}
						}else{
							$hasil = 'Data tidak ditemukan';
						}
					}
				}
				$data_del = array(
					'pengirim' => $pengirim,
					'id_wapi' => $idwa		
				);
				$this->wame_model->delete_tabel('qtemp',$data_del);

			} else{//jika tidak ada di qtemp
				//tampilkan format awal
				$hasil = $default_balas;
			}
		}
		return $hasil;
	}

	public function kirim_pesan($tujuan, $pesan){

		$data = file_get_contents("php://input");
		$row = json_decode($data,true);

		$url2 = URL_API_KIRIM;
		$id = $this->wame_model->get_last_id_wapi();		

		$kirim2 = array(
			'token' => ACTIVE_TOKEN,
			'id'     => $id,
		   	'number'	=> $tujuan,
		   	'message'=> $pesan
		);

		$options2 = array(
		  'http' => array(
		    'method'  => 'POST',
		    'content' => json_encode( $kirim2 ),
		    'header'=>  "Content-Type: application/json\r\n" .
		                "Accept: application/json\r\n"
		    )
		);
		$context2  = stream_context_create( $options2 );
		$result2 = file_get_contents( $url2, false, $context2 );
		$response = json_decode( $result2 );	

		if($response->success == TRUE){
			$data_resp = array(
				"hasil_kode" => $response->success,
				"hasil_pesan" => $response->message
			);	
		} else {
			$data_resp = array(
				"hasil_kode" => '0',
				"hasil_pesan" => 'GAGAL KIRIM'
			);
		}
		return $response->success;
	}	

	public function send_pesan(){

		$data = file_get_contents("php://input");
		$row = json_decode($data,true);

		$url2 = URL_API_KIRIM;
		$id = $this->wame_model->get_last_id_wapi();		

		$kirim2 = array(
			'token' => ACTIVE_TOKEN,
			'id'     => $id,
		   	'number'	=> $row['tujuan'],
		   	'message'=> $row['pesan']
		);

		$options2 = array(
		  'http' => array(
		    'method'  => 'POST',
		    'content' => json_encode( $kirim2 ),
		    'header'=>  "Content-Type: application/json\r\n" .
		                "Accept: application/json\r\n"
		    )
		);
		$context2  = stream_context_create( $options2 );
		$result2 = file_get_contents( $url2, false, $context2 );
		$response = json_decode( $result2 );	

		if($response->success == TRUE){
			$data_resp = array(
				"hasil_kode" => $response->success,
				"hasil_pesan" => $response->message
			);	
		} else {
			$data_resp = array(
				"hasil_kode" => '0',
				"hasil_pesan" => 'GAGAL KIRIM'
			);
		}
		return 'OK';
		// return $response->success;
	}


}