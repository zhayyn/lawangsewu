<html>
<head>
	<title>ATK REQUEST</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=no">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <link rel="icon" href="./favicon.ico">
  <link href="<?php echo base_url('assets/css');?>/jquery-ui.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url('assets/css');?>/bootstrap.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url('assets/font-awesome-4.7.0/css');?>/font-awesome.min.css" rel="stylesheet" type="text/css">
  <script src="<?php echo base_url('assets/js');?>/jquery.js"></script>
  <script src="<?php echo base_url('assets/js');?>/jquery-ui.min.js"></script>
  <script src="<?php echo base_url('assets/js');?>/jquery-ui.js"></script>
  <script src="<?php echo base_url('assets/js');?>/bootstrap.js"></script>
  <link rel="stylesheet" href="<?php echo base_url('assets/css');?>/w3-4.css">
  <link rel="stylesheet" href="<?php echo base_url('assets/css');?>/w3-theme-green.css"> 
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster&effect=shadow-multiple">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Allerta+Stencil">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">

  <style type="text/css">
    body  {
      /*background-image: url("assets/images/steel.gif");*/
      /*background-color: #cccccc;*/
      font-family: Roboto, sans-serif;
    }  
    h1, h2, h3, h4, h5, h6  {
      font-family: Roboto, sans-serif;
    }  
    .w3-lobster {
      font-family: "Lobster", Sans-serif;  
    }
    .w3-allerta {
      /*font-family: "Allerta Stencil", Sans-serif;*/
      font-family: Roboto, sans-serif;
    }  
    .w3-sofia {
      font-family: Sofia, sans-serif;
    }   


  /* Full-width input fields */
  textarea, select, input[type=date], input[type=text], input[type=email], input[type=password] {
    width: 100%;
    padding: 8px 12px;
    margin: 4px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
  }

  /* Set a style for all buttons */
  button {
    background-color: #04AA6D;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
  }

  button:hover {
    opacity: 0.8;
  }

  /* Extra styles for the cancel button */
  .cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
  }

  /* Center the image and position the close button */
  .imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
    position: relative;
  }

  img.avatar {
    width: 40%;
    border-radius: 50%;
  }

  .container {
    padding: 8px;
  }

  span.psw {
    float: right;
    padding-top: 16px;
  }

  /* The Modal (background) */
  .modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    padding-top: 0;
  }

    .modal-backdrop {
       position: relative;
       z-index: -1
    }

  /* Modal Content/Box */
  .modal-content {
    background-color: #fefefe;
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    border: 1px solid #888;
    width: 80%; /* Could be more or less, depending on screen size */
  }

  /* The Close Button (x) */
  .close {
    position: absolute;
    right: 25px;
    top: 0;
    color: #000;
    font-size: 35px;
    font-weight: bold;
  }

  .close:hover,
  .close:focus {
    color: red;
    cursor: pointer;
  }

  /* Add Zoom Animation */
  .animate {
    -webkit-animation: animatezoom 0.6s;
    animation: animatezoom 0.6s
  }

  @-webkit-keyframes animatezoom {
    from {-webkit-transform: scale(0)} 
    to {-webkit-transform: scale(1)}
  }
    
  @keyframes animatezoom {
    from {transform: scale(0)} 
    to {transform: scale(1)}
  }

  /* Change styles for span and cancel button on extra small screens */
  @media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
  }

    .accordion {
      background-color: #eee;
      color: #444;
      cursor: pointer;
      padding: 12px;
      width: 100%;
      border: none;
      text-align: left;
      outline: none;
      font-size: 15px;
      transition: 0.4s;
    }
    
    .active, .accordion:hover {
      background-color: #ccc;
    }
    
    .accordion:after {
      content: '\002B';
      color: #777;
      font-weight: bold;
      float: right;
      margin-left: 5px;
    }
    
    .active:after {
      content: "\2212";
    }
    
    .panel {
      padding: 0 8px;
      background-color: white;
      max-height: 0;
      overflow: hidden;
      transition: max-height 0.2s ease-out;
    }

</style> 
</head>
<body>

    <div id="bye" class="w3-container w3-center" style="padding-top: 60px;">
        
        <div class="w3-container w3-card">            
            <h1>Permintaan ATK</h1>
            <p>Berikut ini daftar permintaan ATK</p>
            
            <div class="w3-container" style="float: left;">
                Pilihan Status:
                <div class="btn-group" role="group" aria-label="Basic example">
                    <button onclick="filter_data(0)" type="button" class="w3-btn w3-small w3-blue w3-round"><i class="fa fa-hourglass-half"></i> Antrian</button>
                    <button onclick="filter_data(1)" type="button" class="w3-btn w3-small w3-green w3-round"><i class="fa fa-check-square"></i> Dipenuhi</button>
                    <button onclick="filter_data(2)" type="button" class="w3-btn w3-small w3-red w3-round"><i class="fa fa-times-circle"></i> Dibatalkan</button>
                </div>        
            </div>
        <table class="w3-table w3-border w3-striped w3-hoverable" id="tabel_atk_req" style="width: 100%;">
          <thead>
            <tr>
              <th width="5%">No</th>
              <th width="30%">Data</th>
              <th width="15%">Tgl</th>
              <th width="10%">Keperluan</th>
              <th width="20%">Item</th>
              <th width="20%">Aksi</th>
            </tr>
          </thead>
          <tbody id="tbreq">

          </tbody>
        </table>
        <br><br>
        </div>
    </div>

  <!-- MODAL INFO REQUEST -->
    <div class="modal" id="req_stat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabe2" aria-hidden="true" style="display: none;">
        <div class="modal-dialog" role="dialog">
            <div class="modal-content"> 
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Status Permintaan</h5>
                    <button type="button" class="close" data-dismiss="modal" onclick="document.getElementById('req_stat').style.display='none'" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>                
                </div>
                <div class="modal-body">
                    Set permohonan selesai?<br>
                    <div class="form-check form-switch">
                      <input type="hidden" id="id_req">
                      <input class="form-check-input w3-large" type="checkbox" role="switch" id="selesai">
                      <label class="form-check-label" for="selesai"> Status</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="document.getElementById('req_stat').style.display='none'">Tutup</button>
                    <button onclick="simpan_status()" type="button" class="w3-btn w3-round-large w3-green btn float-end"><i class='fa fa-save'></i> Simpan</button>
                </div>
            </div>
        </div>
    </div>

	<!-- MODAL DETIL REQUEST -->
    <div class="modal" id="detail_req" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog" role="dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Detail Permintaan</h5>
                    <button type="button" class="close" data-dismiss="modal" onclick="document.getElementById('detail_req').style.display='none'" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                	<div class="w3-container">
	                    <hr>
	                    <h3><i class="fa fa-cubes"></i> Daftar Item Yang Diminta</h3>
                  		<table width="100%">
                  			<thead>
                  				<th width="5%">No</th>
                  				<th width="85%">Item</th>
                  				<th width="10%">Jumlah</th>
                  			</thead>
                  			<tbody id="tbdet">
                  			</tbody>
                  		</table>
                	</div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="document.getElementById('detail_req').style.display='none'">Tutup</button>
                </div>
            </div>
        </div>
    </div>
</body> 

<script src="<?php echo base_url()?>/assets/plugin/jquery/jquery.js"></script>
<script src="<?php echo base_url()?>/assets/plugin/jquery-ui/jquery-ui.min.js"></script>
<script src="<?php echo base_url()?>/assets/plugin/jquery-ui/datepicker-id.js"></script>
<script type="text/javascript">
  $( document ).ready(function() {
      filter_data(0);
  });
  function simpan_status(){
      const cb = document.querySelector('#selesai');
      var id = document.getElementById('id_req').value;

      var nilai = 0;
      if (cb.checked){
          nilai = 1;
      }else{
          nilai = 0;
      }

      $.ajax({
          type: "POST",
          url: '<?php echo base_url()?>atk/simpan_status',
          dataType: 'json',
          data: {
            req_id: id,
            stat: nilai
          },
          success: function(data) {
            window.location.reload();
            document.getElementById('req_stat').style.display='none';
          },
          error: function(result) {
              alert('error');
          }
      });      
      
  }

  function filter_data(val){
      $.ajax({
          type: "POST",
          url: '<?php echo base_url()?>atk/filter_data',
          dataType: 'json',
          data: {
            filter: val
          },
          success: function(data) {
              var event_data = '';
              var i = 1;
            
              $.each(data, function(index, value){
                  event_data += "<tr>";
                  event_data +=  "<td align='center'>"+i+'</td>';
                  event_data +=  "<td align='left'><b>"+value['nama']+'</b></td>';
                  event_data +=  "<td align='left'><b>"+value['tgl_request']+'</b></td>';
                  event_data +=  "<td align='left'><b>"+value['guna']+'</b></td>';
                  event_data +=  "<td>"+
                      "<a class='w3-btn w3-small w3-left w3-green' onclick='tampil_detail("+value['id']+")'><i class='fa fa-cubes'></i> Detail Item ("+value['jml_item']+")</a>"+
                      "<a class='w3-btn w3-small w3-left w3-blue disable-links' onclick='cetak("+value['id']+")'><i class='fa fa-print'></i> Cetak</a>"+
                    "</td>";
                  event_data +=  "<td align='left'>"+
                            "<a class='w3-btn w3-sm w3-small w3-left w3-green' onclick='set_status("+value['id']+","+value['stat']+")' id='btn-aksi'><i class='fa fa-check-square-o'></i> Aksi</a>"+
                            "<a class='w3-btn w3-sm w3-small w3-left w3-red disable-links' id='btn-lempar'><i class='fa fa-share-square-o'></i> Lempar</a>"+
                        "</td></tr>";
                  i++;
              });
              document.getElementById('tbreq').innerHTML="";
              $("#tbreq").append(event_data);
              // document.getElementById('detail_req').style.display="block";
          },
              error: function(result) {
              alert('error');
          }
      });    
  }

	function cetak(idreq){
      $.ajax({
          type: "POST",
          url: '<?php echo base_url()?>atk/cetak',
          dataType: 'json',
          data: {
          	req_id: idreq
          },
          success: function(data) {
      		var event_data = '';
          	var i = 1;
          	alert('OK');
           //    $.each(data, function(index, value){
           //    	// alert(value['item']);
            //     event_data += '<tr>';
            //     event_data += '<td align="center">'+i+'</td>';
            //     event_data += '<td align="left"><i class="fa fa-cube"></i> <b>'+value['item']+'</b></td>';
            //     event_data += '<td align="right"><b>'+value['jml']+'</b></td></tr>';
            //     i++;
           //    });    

            // document.getElementById('tbdet').innerHTML="";
            // $("#tbdet").append(event_data);
            // document.getElementById('detail_req').style.display="block";
          },
              error: function(result) {
              alert('error');
          }
      });
	}

  function set_status(id, stat){
      document.getElementById('id_req').value = id;
      document.getElementById('req_stat').style.display="block";
      
      if(stat == 1){
          document.getElementById('selesai').checked = true;  
      }else{
          document.getElementById('selesai').checked = false;
      }
  }


	function tampil_detail(idreq){
      $.ajax({
          type: "POST",
          url: '<?php echo base_url()?>atk/show_detail_request',
          dataType: 'json',
          data: {
          	req_id: idreq
          },
          success: function(data) {
      		var event_data = '';
          	var i = 1;

              $.each(data, function(index, value){
              	// alert(value['item']);
                event_data += '<tr>';
                event_data += '<td align="center">'+i+'</td>';
                event_data += '<td align="left"><i class="fa fa-cube"></i> <b>'+value['item']+'</b></td>';
                event_data += '<td align="right"><b>'+value['jml']+'</b></td></tr>';
                i++;
              });    

            document.getElementById('tbdet').innerHTML="";
            $("#tbdet").append(event_data);
            document.getElementById('detail_req').style.display="block";
          },
              error: function(result) {
              alert('error');
          }
      });
	}

</script>
</html>