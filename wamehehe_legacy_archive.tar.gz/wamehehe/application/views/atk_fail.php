<?php
  ini_set('display_errors', '0');
  ini_set('display_startup_errors', '0');
  error_reporting(E_ALL);  
?>
<html>
<head>
	<title>ATK REQUEST</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=no">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <link rel="icon" href="./favicon.ico">
  <link href="<?php echo base_url('assets/css');?>/jquery-ui.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url('assets/css');?>/bootstrap.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url('assets/font-awesome-4.7.0/css');?>/font-awesome.min.css" rel="stylesheet" type="text/css">
  <script src="<?php echo base_url('assets/js');?>/jquery.js"></script>
  <script src="<?php echo base_url('assets/js');?>/jquery-ui.min.js"></script>
  <script src="<?php echo base_url('assets/js');?>/jquery-ui.js"></script>
  <script src="<?php echo base_url('assets/js');?>/bootstrap.js"></script>
  <link rel="stylesheet" href="<?php echo base_url('assets/css');?>/w3-4.css">
  <link rel="stylesheet" href="<?php echo base_url('assets/css');?>/w3-theme-green.css"> 
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster&effect=shadow-multiple">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Allerta+Stencil">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">

  <style type="text/css">
    body  {
      /*background-image: url("assets/images/steel.gif");*/
      /*background-color: #cccccc;*/
      font-family: Roboto, sans-serif;
    }  
    h1, h2, h3, h4, h5, h6  {
      font-family: Roboto, sans-serif;
    }  
    .w3-lobster {
      font-family: "Lobster", Sans-serif;  
    }
    .w3-allerta {
      /*font-family: "Allerta Stencil", Sans-serif;*/
      font-family: Roboto, sans-serif;
    }  
    .w3-sofia {
      font-family: Sofia, sans-serif;
    }   


  /* Full-width input fields */
  textarea, select, input[type=date], input[type=text], input[type=email], input[type=password] {
    width: 100%;
    padding: 8px 12px;
    margin: 4px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
  }

  /* Set a style for all buttons */
  button {
    background-color: #04AA6D;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
  }

  button:hover {
    opacity: 0.8;
  }

  /* Extra styles for the cancel button */
  .cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
  }

  /* Center the image and position the close button */
  .imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
    position: relative;
  }

  img.avatar {
    width: 40%;
    border-radius: 50%;
  }

  .container {
    padding: 8px;
  }

  span.psw {
    float: right;
    padding-top: 16px;
  }

  /* The Modal (background) */
  .modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    padding-top: 0;
  }

    .modal-backdrop {
       position: relative;
       z-index: -1
    }

  /* Modal Content/Box */
  .modal-content {
    background-color: #fefefe;
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    border: 1px solid #888;
    width: 80%; /* Could be more or less, depending on screen size */
  }

  /* The Close Button (x) */
  .close {
    position: absolute;
    right: 25px;
    top: 0;
    color: #000;
    font-size: 35px;
    font-weight: bold;
  }

  .close:hover,
  .close:focus {
    color: red;
    cursor: pointer;
  }

  /* Add Zoom Animation */
  .animate {
    -webkit-animation: animatezoom 0.6s;
    animation: animatezoom 0.6s
  }

  @-webkit-keyframes animatezoom {
    from {-webkit-transform: scale(0)} 
    to {-webkit-transform: scale(1)}
  }
    
  @keyframes animatezoom {
    from {transform: scale(0)} 
    to {transform: scale(1)}
  }

  /* Change styles for span and cancel button on extra small screens */
  @media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }
    .cancelbtn {
       width: 100%;
    }
  }

    .accordion {
      background-color: #eee;
      color: #444;
      cursor: pointer;
      padding: 12px;
      width: 100%;
      border: none;
      text-align: left;
      outline: none;
      font-size: 15px;
      transition: 0.4s;
    }
    
    .active, .accordion:hover {
      background-color: #ccc;
    }
    
    .accordion:after {
      content: '\002B';
      color: #777;
      font-weight: bold;
      float: right;
      margin-left: 5px;
    }
    
    .active:after {
      content: "\2212";
    }
    
    .panel {
      padding: 0 8px;
      background-color: white;
      max-height: 0;
      overflow: hidden;
      transition: max-height 0.2s ease-out;
    }

</style> 
</head>
<body>
    <div class="w3-top w3-row w3-card-2 w3-padding w3-center w3-white">
      <div class="w3-col w3-center" style="width:30px">
      </div>
      <div class="w3-rest w3-cell-middle"><span style="font-size: 18px"><i class="fa fa-cubes" aria-hidden="true"></i> Permohonan ATK Pegawai</span></div>
    </div>
    <?php 
        if(isset($err_code)){
            if($err_code == 0 || $err_code == 1){
              ?>
                <div id="req_fail" class="w3-container w3-center" style="padding-top: 60px; display: block;">
                    <div class="w3-container w3-card">
                        <img src="<?php echo base_url()?>/assets/images/req_fail.png" style="width: 64px;">
                        <p><strong>Tautan Link Salah</strong><br>Pastikan Anda mendapatkan link terbaru<br>Silahkan Coba Lagi</p>
                    </div>
                </div>  
              <?php 
            }else if($err_code == 2){
              ?>
                <div id="req_fail" class="w3-container w3-center" style="padding-top: 60px; display: block;">
                    <div class="w3-container w3-card">
                        <img src="<?php echo base_url()?>/assets/images/req_fail.png" style="width: 64px;">
                        <p><strong>Data Pegawai tidak ditemukan</strong><br>Pastikan Anda mendapatkan link yang benar<br>Silahkan Coba Lagi</p>
                    </div>
                </div>               
              <?php
            }else if($err_code == 3){
              ?>
                <div id="req_fail" class="w3-container w3-center" style="padding-top: 60px; display: block;">
                    <div class="w3-container w3-card">
                        <img src="<?php echo base_url()?>/assets/images/req_fail.png" style="width: 64px;">
                        <p><strong>Link Kadaluwarsa</strong><br>Pastikan Anda mendapatkan link terbaru<br>Silahkan Coba Lagi</p>
                    </div>
                </div>               
              <?php              
            }else{
              ?>
                <div id="req_fail" class="w3-container w3-center" style="padding-top: 60px; display: block;">
                    <div class="w3-container w3-card">
                        <img src="<?php echo base_url()?>/assets/images/req_fail.png" style="width: 64px;">
                        <p><strong>Permintaan Gagal</strong><br>Pastikan Anda terkoneksi dengan internet<br>Silahkan Coba Lagi</p>
                    </div>
                </div>      
              <?php         
            }
        }
    ?>
    
   
</body> 

<script src="<?php echo base_url()?>/assets/plugin/jquery/jquery.js"></script>
<script src="<?php echo base_url()?>/assets/plugin/jquery-ui/jquery-ui.min.js"></script>
<script src="<?php echo base_url()?>/assets/plugin/jquery-ui/datepicker-id.js"></script>
<script type="text/javascript">

</script>
</html>