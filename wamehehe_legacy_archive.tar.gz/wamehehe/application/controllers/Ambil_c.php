<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ambil_c extends CI_Controller {
	function __construct() {
		parent::__construct();	
		$this->load->helper(array('form', 'url','captcha'));	
	}

	public function index() {
		$this->load->helper(array('url'));
		$data['judul'] = 'Tukang Ambil Data';
		$this->load->view("ambil", $data);
	}

	public function ambil_data()
	{
		$q = $this->wame_model->get_perkara_masuk();
		$data_ac = $q->row();
		if(is_null($data_ac) == TRUE){
			$p = $this->wame_model->get_data_ac();
			$data_ac = $p->row();
			if(is_null($data_ac) == TRUE){
				$q = $this->wame_model->get_data_jsid();
				$data_ac = $q->row();
				if(is_null($data_ac) == TRUE){
					$q = $this->wame_model->get_biaya_psp();
					$data_ac = $q->row();					
					// if(is_null($data_ac) == TRUE){
					// 	$q = $this->wame_model->get_js_instrumen_notif();
					// 	$data_ac = $q->row();
					// }
				}	
			}			
		}
		echo json_encode($data_ac);
	}	

	public function simpan_outbox_notif_js(){
		$data = file_get_contents("php://input");
		$row = json_decode($data,true);
		$id_sidang = $row['sidang_id'];
		$id_perkara = $row['perkara_id'];
		// $id_sidang = $this->input->post('sidang_id');
		echo $this->wame_model->exec_notif_js($id_perkara, $id_sidang);
	}

	public function simpan_outbox_psp(){
		$data = file_get_contents("php://input");
		$row = json_decode($data,true);

		if($row['pesan']){
			$this->wame_model->ins_psp_notif($row['perkara_id'],$row['telepon'],$row['pesan']);
			//$this->wame_model->query("INSERT INTO keuangan_pendukung.perkara_rek_psp_notif(`perkara_id`, `penerima`, `pesan`) VALUES('".$row['perkara_id']."','".$row['telepon']."','".$row['pesan']."')");

			$data_simpan = array(
				'penerima' => $row['telepon'],
				'perkara_id' => $row['perkara_id'],
				'pesan' => $row['pesan'],
				'tipe' => $row['tipe']
			);
			$this->wame_model->insert_tabel('outbox', $data_simpan);


			

		}
	}	

	public function simpan_outbox(){
		$data = file_get_contents("php://input");
		$row = json_decode($data,true);

		if($row['pesan']){
			$data_simpan = array(
				'penerima' => $row['telepon'],
				'perkara_id' => $row['perkara_id'],
				'pesan' => $row['pesan'],
				'tipe' => $row['tipe'],
				'sidang_id' => $row['sidang_id']
			);
			$this->wame_model->insert_tabel('outbox', $data_simpan);

			if($row['tipe'] == 3){
				$cetak = $this->cetak_qr($row['perkara_id']);
				$data_simpan = array(
					'penerima' => $row['telepon'],
					'perkara_id' => $row['perkara_id'],
					'pesan' => 'QR: *'.$row['nomor_perkara'].'* Gunakan QRcode ini ketika Anda memasuki gedung atau pada saat pengambilan nomor antrian sidang di Pengadilan Agama Semarang. Untuk info lebih lanjut, silahkan bertanya kepada Petugas. Terimakasih.',
					'tipe' => 4,
					'tipe_pesan' => 2,
					'fname' => base_url().'assets/qr/qr'.$row['perkara_id'].'.png'
				);
				$this->wame_model->insert_tabel('outbox', $data_simpan);
			}
		}
	}	

    function cetak_qr($vpid){
        // $perkid = $this->input->post('perkara_id');
        $perkid = $vpid;

        $this->load->library('ciqrcode'); //pemanggilan library QR CODE

        $this->load->library('Encrypt'); 
		$x = new CI_Encrypt();
		$kunci   = "m4hk4m4h4gung"; 
		$enoperk = $x->encode($perkid, $kunci);

        $config['cacheable']    = true; //boolean, the default is true
        $config['cachedir']             = './assets/'; //string, the default is application/cache/
        $config['errorlog']             = './assets/'; //string, the default is application/logs/
        $config['imagedir']             = './assets/qr/'; //direktori penyimpanan qr code
        $config['quality']              = true; //boolean, the default is true
        $config['size']                 = '1024'; //interger, the default is 1024
        $config['black']                = array(224,255,255); // array, default is array(255,255,255)
        $config['white']                = array(70,130,180); // array, default is array(0,0,0)
        $this->ciqrcode->initialize($config);

        $image_name='qr'.$perkid.'.png'; //buat name dari qr code sesuai dengan nim

        $params['data'] = $enoperk; //data yang akan di jadikan QR CODE
        $params['level'] = 'H'; //H=High
        $params['size'] = 10;
        $params['savename'] = FCPATH.$config['imagedir'].$image_name; //simpan image QR CODE ke folder assets/images/
        $this->ciqrcode->generate($params); // fungsi untuk generate QR CODE

		$data_simpan = array(
			'perkara_id' => $perkid,
			'qr_data' => $enoperk,
			'qr_image' => $image_name					
		);
		$hasil = $this->wame_model->simpan_data_qr($data_simpan);

        // $this->wame_model->simpan_mahasiswa($nim,$nama,$prodi,$image_name); //simpan ke database
        // redirect('mahasiswa'); //redirect ke mahasiswa usai simpan data
		echo $hasil;
    }	

}