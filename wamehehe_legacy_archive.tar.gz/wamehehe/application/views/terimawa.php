<?php
	echo "<b>".$pengirim."</b><br>".$pesan;

?>