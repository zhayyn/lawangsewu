<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>WAME PENGADUAN</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1 user-scalable=no">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="icon" href="./favicon.ico">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> -->


	<link href="<?php echo base_url('assets/font-awesome-4.7.0/css');?>/font-awesome.min.css" rel="stylesheet" type="text/css">

	<link rel="stylesheet" href="<?php echo base_url('assets/css');?>/w3-4.css">
	<link rel="stylesheet" href="<?php echo base_url('assets/css');?>/w3-theme-green.css"> 
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster&effect=shadow-multiple">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Allerta+Stencil">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
	<style type="text/css">
		/* Style the tab */
		.tab {
		  overflow: hidden;
		  border: 1px solid #ccc;
		  background-color: #f1f1f1;
		  width: 100%;
		}

		/* Style the buttons that are used to open the tab content */
		.tab button {
		  background-color: inherit;
		  float: left;
		  border: none;
		  outline: none;
		  cursor: pointer;
		  padding: 14px 16px;
		  transition: 0.3s;
		}

		/* Change background color of buttons on hover */
		.tab button:hover {
		  background-color: #ddd;
		}

		/* Create an active/current tablink class */
		.tab button.active {
		  background-color: #ccc;
		}

		/* Style the tab content */
		.tabcontent {
		  display: none;
		  padding: 6px 12px;
		  border: 1px solid #ccc;
		  border-top: none;
		  width: 100%;
		}	
	</style>	
</head>
<body>

	<div id="loadingDiv" style="display:none"></div>
	<div class="w3-cell-row"  style="padding-top:40px"></div>

	<div class="w3-container-fluid">
		<div class="w3-container" align="center">	
			<div class="w3-container-fluid">

			</div>


			<div class="container">
			<div class="panel panel-danger">
			  <div class="panel-heading">
			  	<h1>PENGADUAN</h1>
			  	<button class="btn btn-sm btn-success" onClick="window.location.reload();"> <i class="fa fa-refresh"></i> Refresh Aduan</button>
			  	
				<table class="table table-sm" style="width : 40%;">
					<thead>
						<tr>
							<th align="left">ID</th>
							<th align="right">TOTAL</th>
							<th align="right">MASUK</th>
							<th align="right">BELUM_DIJAWAB</th>
							<th align="right">BELUM_DIKIRIM</th>
							<th align="right">SELESAI</th>
						</tr>
					</thead>
					<tbody>
					<?php
						if($stat_pengaduan){
							foreach ($stat_pengaduan as $j) {	
								if($j->did == 1){	
									$m = $j->belum_dijawab + $j->belum_dikirim;
									$sl = $j->selesai;	
					?>
						<tr>
							<td align="left"><?php echo $j->id;?></td>
							<td align="right"><?php echo $j->tot;?></td>
							<td align="right"><?php echo $j->belum_dijawab + $j->belum_dikirim;?></td>
							<td align="right"><?php echo $j->belum_dijawab;?></td>
							<td align="right"><?php echo $j->belum_dikirim;?></td>
							<td align="right"><?php echo $j->selesai;?></td>
						</tr>
					<?php 					
								}
							}
						}else{
							echo "<tr><td colspan='5'>KOSONG</td></tr>";
						}
					?>
					</tbody>
				</table>
			  	<p>Berikut adalah daftar pengaduan. Silahkan klik <strong>isi Balasan</strong> untuk mengisi balasan. Jangan lupa pencet <strong>Kirim</strong> untuk mengirimkan balasan melalui Whatsapp API</p>

			  </div>
			  <div class="panel-body">

<div class="tab">
  <button class="tablinks" id="tmasuk" onclick="openCity(event, 'masuk')"><i class="fa fa-envelope-open"></i><strong> Masuk <span class="w3-badge w3-red"><?php echo $m;?></span></strong></button>
  <button class="tablinks" id="tselesai" onclick="openCity(event, 'selesai')"><i class="fa fa-check-circle" aria-hidden="true"></i><strong> Selesai <span class="w3-badge w3-green"><?php echo $sl;?></span></strong></button>
</div>

<div id="masuk" class="tabcontent">			  
                <table id="tbrbi" class="table table-striped table-sm" style="font-size: 90%;">
                    <thead>
                        <tr>
                            <th style="vertical-align:middle" width="30%"><i>ADUAN</i></th>
                            <th style="vertical-align:middle" width="30%"><i>BALASAN</i></th>
                            <th style="vertical-align:middle" width="10%"><i>AKSI</i></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    	$no = 1;
                    	if($list_aduan){
                    		foreach ($list_aduan as $h) {
                    ?>
								<tr>
									
									
									<td align='left' width="40%">										
									    <div class="panel panel-danger">
									      <div class="panel-heading"><?php echo '[#'.$no++.'] <i class="fa fa-user"></i> '.$h->pengirim.'<br><i class="fa fa-commenting"></i> <i>'.$h->dibuat.'</i>';?></div>
									      <div class="panel-body"><?php echo $h->pesan;?></div>
									    </div>
									</td>
									<td align='center' width="40%">
										<?php if($h->balasan){?>
									    <div class="panel panel-success">
									      <div class="panel-heading"><?php echo '<i class="fa fa-user"></i> Pengadilan Agama Semarang<br><i class="fa fa-commenting"></i> <i>'.$h->dibuat.'</i>';?></div>
									      <div class="panel-body" align="left"><?php 
									      	echo $h->balasan;
												      		if(isset($h->fname)){
												      			echo '<br><br><a href="'.base_url().'lampiran/'.$h->fname.'" target="_blank"><i class="fa fa-paperclip" aria-hidden="true"></i>'.$h->fname.'</a>';
												      		}									      	
									      ?></div>
									    </div>
									    <?php }else{ ?>
									    	<span>balasan kosong</span>
									    <?php }?>
									</td>
									<td align='right' width="20%">
										<?php 
											if ($h->stat == 0){
												echo '<span class="badge bg-danger">Belum Dibalas</span>';
											}else if($h->stat == 1){
												echo '<span class="badge bg-warning">Belum Dikirim</span>';
											}else if($h->stat == 2){
												echo '<span class="badge bg-success">Terbalas</span>';
											}else{
												echo '<span class="badge bg-danger">Gagal Kirim Pesan</span>';
											}											
										?>										
										<hr>
										<button class="btn btn-success btn-sm btn-block" onclick="balas(<?php echo $h->id;?>)"><i class="fa fa-pencil-square-o"></i> Isi Balasan</button>
										<button class="btn btn-danger btn-sm btn-block" onclick="kirim(<?php echo $h->id;?>)"><i class="fa fa-paper-plane-o"></i> Kirim</button>
										<hr>
										<button class="btn btn-danger btn-sm btn-block" onclick="pindah_konsul(<?php echo $h->id;?>)"><i class="fa fa-stack-overflow"></i> Lempar Konsultasi</button>
										<button class="btn btn-danger btn-sm btn-block" onclick="pindah_umum(<?php echo $h->id;?>)"><i class="fa fa-stack-overflow"></i> lempar Sekretariat</button>
										<button class="btn btn-primary btn-sm btn-block" onclick="set_selesai(<?php echo $h->id;?>)"><i class="fa fa-check-square-o"></i> Set Selesai</button>
									</td>									
								</tr>		                   
                    <?php
                    		}
                    	}else{
                    		?>
                    		<tr><td colspan="7">DATA KOSONG</td></tr>
                    	<?php 

                    	}
                    ?>
                    </tbody>
                </table>
</div>
<div id="selesai" class="tabcontent">
                <table id="tbrbi" class="table table-striped table-sm" style="font-size: 90%;">
                    <thead>
                        <tr>                            
                            <th style="vertical-align:middle" width="30%"><i>DATA</i></th>
                            <th style="vertical-align:middle" width="30%"><i>BALASAN</i></th>
                            <th style="vertical-align:middle" width="10%"><i>AKSI</i></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    	$no = 1;
                    	if($list_aduan_selesai){
                    		foreach ($list_aduan_selesai as $h) {
                    ?>
								<tr>
									<td align='left' width="40%">										
									    <div class="panel panel-default class">
									      <div class="panel-heading">
									      	<?php echo '[#'.$no++.'] <i class="fa fa-user"></i> '.$h->pengirim.
									      		'<br><i class="fa fa-commenting"></i> <i>'.$h->dibuat.'</i>';
									      	?>
									      </div>
									      <div class="panel-body"><?php echo $h->pesan;?></div>
									    </div>
									</td>
									<td align='center' width="40%">
										<?php if($h->balasan){?>
									    <div class="panel panel-default class">
									      <div class="panel-heading"><?php echo '<i class="fa fa-user"></i> Pengadilan Agama Semarang<br><i class="fa fa-commenting"></i> <i>'.$h->dibuat.'</i>';?></div>
									      <div class="panel-body" align="left"><?php 
									      		echo $h->balasan;
												      		if(isset($h->fname)){
												      			echo '<br><br><a href="'.base_url().'lampiran/'.$h->fname.'" target="_blank"><i class="fa fa-paperclip" aria-hidden="true"></i>'.$h->fname.'</a>';
												      		}										      		
									      	?></div>
									    </div>
									    <?php }else{ ?>
									    	<span>balasan kosong</span>
									    <?php }?>
									</td>

									<td align='right' width="20%">
										<?php 
											if ($h->stat == 0){
												echo '<span class="badge bg-danger">Belum Dibalas</span>';
											}else if($h->stat == 1){
												echo '<span class="badge bg-warning">Belum Dikirim</span>';
											}else if($h->stat == 2){
												echo '<span class="badge bg-success">Terbalas</span>';
											}else{
												echo '<span class="badge bg-danger">Gagal Kirim Pesan</span>';
											}
										?>
									</td>									
								</tr>		                   
                    <?php
                    		}
                    	}else{
                    		?>
                    		<tr><td colspan="7">DATA KOSONG</td></tr>
                    	<?php 

                    	}
                    ?>
                    </tbody>
                </table>
</div>

			  </div>
			</div>


 
			</div>

		</div>
		<br><br>
	</div>

<div class="container">
<div id="modal_balas" class="modal" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h1>Balas Pesan <span id="idbalas"></span></h1>
                <!-- <button type="button" class="btn-close" data-bs-dismiss="modal_balas" onclick="document.getElementById('modal_balas').style.display='none'"></button> -->
            </div>
            <div class="modal-body">
            	<p><strong>Pertanyaan:</strong></p>
				<div class="w3-panel w3-leftbar w3-sand">
				  <p class="w3-xsmall w3-serif">
				  <i><span id="pertanyaan"></span></i></p>  
				</div>
                <form method="POST" enctype="multipart/form-data" id="fbalas">
                <!-- <form id="upl_form" class="" method="post" action="#" enctype="multipart/form-data"> -->
                    <input type="hidden" id="id_aduan" name="id_aduan">
                    
                    <label for="curr_dok">Balasan: </label><br>
                    <span id="prefix" name="prefix"></span><br>
                    <textarea form="fbalas" id="balasan" style="width: 100%;" rows="5"></textarea>
                    <label for="dok_relaas">Lampirkan dokumen: </label>
                    <input type="file" id="dok_relaas" name="dok_relaas">
                </form>                
            </div>
            <div class="modal-footer">
                <table width="100%">
                    <tr>
                        <td width="33%" align="left"><button type="button" onclick="document.getElementById('modal_balas').style.display='none'" class="btn btn-primary"><i class="fa fa-times"> Cancel</i></button><td>
                        <td width="33%"></td>
                        <!--<td width="25%"><button onclick="del_peler()" type="button" id="btn_peler_del" name="btn_peler_del" class="btn btn-danger">Hapus</button><td>-->
                        <td width="33%" align="right">
                            <!-- <button type="submit">Upload</button> -->
                            <button type="button" onclick="simpan_balas()" id="btn_dok" name="btn_dok" class="btn btn-success" value=""><i class="fa fa-floppy-o"> Simpan</i></button>
                        </td>    
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
<!--   Core JS Files   -->


<script>
	
	var bell = document.getElementById("bell"); 
	// var myVar = setInterval(my_ajax, 10000);
	var path = '../assets/audio/';
	var tingtong     = path + 'deng.mp3';
	var sound_call = [new Audio(tingtong)];

	document.getElementById("tmasuk").click();

	function setel_bell(){
		bell.play();
	}

	function openCity(evt, cityName) {
	  // Declare all variables
	  var i, tabcontent, tablinks;

	  // Get all elements with class="tabcontent" and hide them
	  tabcontent = document.getElementsByClassName("tabcontent");
	  for (i = 0; i < tabcontent.length; i++) {
	    tabcontent[i].style.display = "none";
	  }

	  // Get all elements with class="tablinks" and remove the class "active"
	  tablinks = document.getElementsByClassName("tablinks");
	  for (i = 0; i < tablinks.length; i++) {
	    tablinks[i].className = tablinks[i].className.replace(" active", "");
	  }

	  // Show the current tab, and add an "active" class to the button that opened the tab
	  document.getElementById(cityName).style.display = "block";
	  evt.currentTarget.className += " active";
	}	

	function pindah_konsul(id_aduan){
		var xhr = new XMLHttpRequest();
		var url='<?php echo base_url(); ?>pengaduan/pindah_konsul';
		xhr.open("POST", url, true);
		xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
		xhr.onreadystatechange = function(){
		  if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){
		  	// document.getElementById('balasan').value = xhr.responseText;
		    alert(xhr.responseText); location.reload();parseInt()
		  }
		};
		xhr.send(JSON.stringify({ id: id_aduan}));	
	}



	function pindah_umum(id_aduan){
		var xhr = new XMLHttpRequest();
		var url='<?php echo base_url(); ?>pengaduan/pindah_umum';
		xhr.open("POST", url, true);
		xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
		xhr.onreadystatechange = function(){
		  if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){
		  	// document.getElementById('balasan').value = xhr.responseText;
		    alert(xhr.responseText); location.reload();parseInt()
		  }
		};
		xhr.send(JSON.stringify({ id: id_aduan}));	
	}	

	function balas(id_aduan){
		document.getElementById('id_aduan').value=id_aduan;		

		// document.getElementById('id_konsul').value=id_konsul;		
        $.ajax({
            type: "POST",
            url: "<?php echo base_url(); ?>pengaduan/get_adu_balas",
            dataType: 'json',
            data: {id: id_aduan},
            success: function(data) {
                $.each(data, function(index, value){  
				  	document.getElementById('pertanyaan').innerHTML = value.pesan;
				  	document.getElementById('prefix').innerHTML = value.prefiks;
				  	document.getElementById('balasan').value = value.balasan;
                });                        
            },
                error: function(result) {
                alert('error');
            }
        });
		document.getElementById('modal_balas').style.display='block';

		// document.getElementById('idbalas').innerHTML = id_aduan;

		// var xhr = new XMLHttpRequest();
		// var url='<?php echo base_url(); ?>pengaduan/get_adu_balas';
		// xhr.open("POST", url, true);
		// xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
		// xhr.onreadystatechange = function(){
		//   if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){
		//   	document.getElementById('prefix').innerHTML = prefiks;
		//   	document.getElementById('balasan').value = xhr.responseText;
		//     // alert('Permintaan Konsultasi dibalas'); location.reload();parseInt()
		//   }
		// };
		// xhr.send(JSON.stringify({ id: id_aduan}));

		// document.getElementById('modal_balas').style.display='block';
	}

	// function simpan_balas(){
	// 	var id_balas = document.getElementById('id_aduan').value;
	// 	var pesan_balas = document.getElementById('balasan').value;
	// 	//alert(id_balas+'='+pesan_balas);

	// 	var xhr = new XMLHttpRequest();
	// 	var url='<?php echo base_url(); ?>pengaduan/balas_adu';
	// 	xhr.open("POST", url, true);
	// 	xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
	// 	xhr.onreadystatechange = function(){
	// 	  if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){
	// 	    alert('aduan dibalas'); location.reload();parseInt()
	// 	  }
	// 	};
	// 	xhr.send(JSON.stringify({ id: id_balas, balasan: pesan_balas}));
	// }

    async function simpan_balas() {
		var id_balas = document.getElementById('id_aduan').value;
		var pesan_balas = document.getElementById('balasan').value;
		var att0 = document.getElementById('dok_relaas').value;        

        let formData = new FormData(); 
        // formData.append("aksi",'update_relaas');
        formData.append("id", id_balas);
        formData.append("balasan", pesan_balas);
        formData.append("lampiran", dok_relaas.files[0]);
        await fetch('<?php echo base_url(); ?>pengaduan/balas_adu',{
            method: "POST", 
            body: formData
        }); 
        alert('The file has been uploaded successfully.');

        document.getElementById('modal_balas').style.display='none';
        location.reload();
    }		

	function tampil(filter_data){
		var xhr = new XMLHttpRequest();
		var url='<?php echo base_url(); ?>pengaduan/cek_adu';
		xhr.open("POST", url, true);
		xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
		xhr.onreadystatechange = function(){
		  if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){	    
		    location.reload();parseInt()
		  }
		};
		xhr.send(JSON.stringify({ filter: filter_data}));		
	}

	function kirim(id_aduan){
		var xhr = new XMLHttpRequest();
		var url='<?php echo base_url(); ?>pengaduan/kirim_adu';
		xhr.open("POST", url, true);
		xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
		xhr.onreadystatechange = function(){
		  if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){
		  	alert('Pesan Terkirim ='+xhr.responseText)
		  	// if(xhr.responseText == '1'){
		  	// 	alert('Pesan Terkirim')
		  	// } else{
		  	// 	alert('Pesan Gagal dikirim'); 
		  	// }
		    
		    location.reload();parseInt()
		  }
		};
		xhr.send(JSON.stringify({ id: id_aduan}));
	}

	function set_selesai(id_aduan){
		var xhr = new XMLHttpRequest();
		var url='<?php echo base_url(); ?>pengaduan/set_selesai';
		xhr.open("POST", url, true);
		xhr.setRequestHeader("Content-type", "application/json;charset=UTF-8");
		xhr.onreadystatechange = function(){
		  if(xhr.readyState == XMLHttpRequest.DONE && xhr.status == 200){
		  		alert(xhr.responseText);
		    location.reload(); parseInt();
		  }
		};
		xhr.send(JSON.stringify({ id: id_aduan}));
	}
	

	

</script>
</html>